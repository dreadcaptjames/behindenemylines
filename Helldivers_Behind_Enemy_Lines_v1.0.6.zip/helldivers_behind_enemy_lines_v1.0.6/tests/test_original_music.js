const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'browser-demo/index.html'),'utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
for (const name of ['cup_of_liber_tea_combat.mp3','by_order_of_high_command_boss.mp3']) {
  const p=path.join(root,'audio',name);
  assert(fs.statSync(p).size>2_000_000,`${name} should be playable audio`);
}
function element(){return {hidden:true,value:'70',textContent:'',setAttribute(){},addEventListener(){},append(){},focus(){}};}
const elems={game:{getContext:()=>({imageSmoothingEnabled:false}),getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),addEventListener(){},focus(){}},controlsPanel:element()};
const document={getElementById:id=>elems[id]||(elems[id]=element()),createElement:()=>element()};
class Audio {constructor(src){this.src=src;this.loop=false;this.volume=0;this.currentTime=0;this.readyState=4;this.playCount=0;}play(){this.playCount++;return Promise.resolve()}cloneNode(){return this}}
class Image {set src(v){this._src=v;this.naturalWidth=64;this.naturalHeight=64}}
class Gain {constructor(){this.gain={value:0}}connect(){} }
class AudioCtx {constructor(){this.state='running';this.destination={};this.currentTime=0;} createMediaElementSource(){return {connect(){}}}createGain(){return new Gain()}resume(){return Promise.resolve()}}
const saved=new Map();const localStorage={getItem:k=>saved.has(k)?saved.get(k):null,setItem:(k,v)=>saved.set(k,String(v)),removeItem:k=>saved.delete(k)};
const env=vm.createContext({console,Math,Set,Map,Audio,Image,document,window:{AudioContext:AudioCtx,addEventListener(){}},navigator:{getGamepads:()=>[]},localStorage,requestAnimationFrame(){},performance:{now:()=>0},Date});
vm.runInContext(js,env,{filename:'browser-demo/index.html'});
const run=s=>vm.runInContext(s,env);
const near=(a,b,margin=.015)=>Math.abs(a-b)<margin;
(async()=>{
 assert(run("musicTracks.combat.src.endsWith('cup_of_liber_tea_combat.mp3')"));
 assert(run("musicTracks.boss.src.endsWith('by_order_of_high_command_boss.mp3')"));
 assert(near(run('musicMaster'),.7), 'first use should retain 70% default volume');
 run('startMusic()');
 assert(run('musicStarted'), 'music unlocked after input');
 assert(run('Object.keys(musicGains).length')===3, 'WebAudio gain mixer initializes');
 assert(run('Object.values(musicTracks).every(a=>a.playCount===1)'), 'all 3 streams unlocked on user input');
 run('reset();state="playing";enem=[];adaptiveMusic(.5)');
 assert(run('musicCue')==='ambient','exploration cue');
 assert(run('musicGains.ambient.gain.value')>0,'exploration audible');
 run('enem=[{kind:"walker",hp:2,x:p.x+90,alert:3}];adaptiveMusic(.5)');
 assert(run('musicCue')==='combat','combat cue selected');
 assert(run('musicGains.combat.gain.value')>0,'Cup plays in combat');
 run('enem=[{kind:"warden",hp:10,x:p.x+50,alert:1}];bossAwake=true;adaptiveMusic(.5)');
 assert(run('musicCue')==='boss','boss cue selected');
 assert(run('musicGains.boss.gain.value')>0,'High Command plays for bosses');
 const before=run('musicGains.boss.gain.value');
 run('state="dialogue";for(let i=0;i<120;i++)adaptiveMusic(.016)');
 assert(run('musicGains.boss.gain.value')<before,'radio ducks soundtrack');
 run('musicMaster=.3;localStorage.setItem("bel_music_master",String(musicMaster));state="playing";adaptiveMusic(.5)');
 assert(saved.get('bel_music_master')==='0.3','volume persisted');
 run('musicOn=false;for(let i=0;i<200;i++)adaptiveMusic(.016)');
 assert(near(run('musicGains.boss.gain.value'),0,.003),'mute fades to silence');
 console.log('PASS: original soundtrack cues, WebAudio iPad gains, volume persistence, dialogue ducking, mute');
})().catch(e=>{console.error(e);process.exitCode=1});
