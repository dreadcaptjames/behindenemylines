from playwright.sync_api import sync_playwright
from pathlib import Path
out=Path('/mnt/data/helldivers_behind_enemy_lines_v1.0.3')
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
    context=browser.new_context(viewport={'width':844,'height':390},device_scale_factor=1,is_mobile=True,has_touch=True)
    page=context.new_page()
    errors=[]
    page.on('pageerror',lambda error: errors.append(str(error)))
    root=Path('/mnt/data/helldivers_behind_enemy_lines_v1.0.3')
    html=(root/'browser-demo/index.html').read_text()
    css=(root/'mobile/touch-controls.css').read_text()
    js=(root/'mobile/touch-controls.js').read_text()
    html=html.replace('<head>', '<head><base href="https://game.test/browser-demo/">',1)
    def local_response(route):
        import mimetypes
        from urllib.parse import urlparse,unquote
        path=unquote(urlparse(route.request.url).path).lstrip('/')
        dest=(root/path).resolve()
        if str(dest).startswith(str(root.resolve())) and dest.is_file():
            mime=mimetypes.guess_type(str(dest))[0] or 'application/octet-stream'
            route.fulfill(status=200,body=dest.read_bytes(),content_type=mime)
        else: route.fulfill(status=404,body='not found')
    context.route('https://game.test/**',local_response)
    html=html.replace('<link rel="stylesheet" href="../mobile/touch-controls.css">','<style>'+css+'</style>')
    html=html.replace('<script src="../mobile/touch-controls.js"></script>','<script>'+js+'</script>')
    page.set_content(html,wait_until='domcontentloaded')
    page.wait_for_timeout(1250)
    print('start state:',page.evaluate('state'))
    print('touch controls visible',page.locator('#belTouchControls').is_visible())
    print('start control visible',page.locator('#tcAdvance').is_visible())
    page.screenshot(path=str(out/'TOUCH_MOBILE_TITLE.png'))
    page.locator('#tcAdvance').dispatch_event('pointerdown',{'pointerId':1,'button':0,'clientX':400,'clientY':170})
    page.wait_for_timeout(50)
    page.locator('#tcAdvance').dispatch_event('pointerup',{'pointerId':1,'button':0,'clientX':400,'clientY':170})
    print('after deploy:',page.evaluate('state'))
    for i in range(3):
        page.locator('#tcAdvance').dispatch_event('pointerdown',{'pointerId':1,'button':0})
        page.wait_for_timeout(60)
        page.locator('#tcAdvance').dispatch_event('pointerup',{'pointerId':1,'button':0})
        page.wait_for_timeout(70)
    print('post-intro:',page.evaluate('state'))
    page.wait_for_timeout(350)
    print('action controls visible',page.locator('#tcActions').is_visible(),page.locator('#tcAim').is_visible())
    print('player x before',page.evaluate('p.x'))
    right=page.locator('[data-key="arrowright"]')
    right.dispatch_event('pointerdown',{'pointerId':12,'button':0})
    page.wait_for_timeout(400)
    right.dispatch_event('pointerup',{'pointerId':12,'button':0})
    print('player x after',page.evaluate('p.x'))
    page.locator('[data-action="jump"]').dispatch_event('pointerdown',{'pointerId':13,'button':0})
    page.wait_for_timeout(80)
    print('jump state',page.evaluate('p.ground'),page.evaluate('p.vy'))
    page.locator('[data-action="jump"]').dispatch_event('pointerup',{'pointerId':13,'button':0})
    aim=page.locator('#tcAim')
    r=aim.bounding_box();cx=r['x']+r['width']/2;cy=r['y']+r['height']/2
    ammo=page.evaluate('p.ammo')
    aim.dispatch_event('pointerdown',{'pointerId':14,'button':0,'clientX':cx+45,'clientY':cy-10})
    page.wait_for_timeout(500)
    print('aim fire ammo',ammo,page.evaluate('p.ammo'),'aim',page.evaluate('({x:mouseX,y:mouseY,down:mouseDown})'))
    aim.dispatch_event('pointerup',{'pointerId':14,'button':0,'clientX':cx+45,'clientY':cy-10})
    page.wait_for_timeout(100)
    print('aim released',page.evaluate('mouseDown'))
    # Simultaneous two-thumb input: movement plus touch fire.
    page.evaluate('p.ammo=18; p.fire=0; p.x=250; p.y=228; p.ground=true')
    x0=page.evaluate('p.x')
    right.dispatch_event('pointerdown',{'pointerId':41,'button':0})
    aim.dispatch_event('pointerdown',{'pointerId':42,'button':0,'clientX':cx+48,'clientY':cy})
    page.wait_for_timeout(320)
    assert page.evaluate('p.x')>x0+10, 'two-thumb movement failed'
    assert page.evaluate('p.ammo')<18, 'two-thumb firing failed'
    right.dispatch_event('pointerup',{'pointerId':41,'button':0})
    aim.dispatch_event('pointerup',{'pointerId':42,'button':0})
    page.wait_for_timeout(70)
    assert not page.evaluate('mouseDown')
    # Enable stratagem, then enter the original directional code with the D-pad.
    page.evaluate('comms=true;stratCd=0;orbital=null')
    strat=page.locator('[data-action="stratagem"]')
    strat.dispatch_event('pointerdown',{'pointerId':50,'button':0})
    print('strat immediate',page.evaluate('({mode:stratMode,keys:Array.from(keys),pressed:Array.from(pressed),comms:comms})'))
    page.wait_for_timeout(50)
    strat.dispatch_event('pointerup',{'pointerId':50,'button':0})
    page.wait_for_timeout(70)
    print('strat diag',page.evaluate('({mode:stratMode,comms:comms,state:state,keys:Array.from(keys),stratCd:stratCd,pressed:Array.from(pressed)})'))
    assert page.evaluate('stratMode'), 'strat mode did not activate'
    for i,k in enumerate(['arrowup','arrowright','arrowdown','arrowup']):
        button=page.locator('[data-key="'+k+'"]')
        button.dispatch_event('pointerdown',{'pointerId':55+i,'button':0})
        page.wait_for_timeout(45)
        button.dispatch_event('pointerup',{'pointerId':55+i,'button':0})
        page.wait_for_timeout(55)
    assert page.evaluate('stratCd')>0, 'stratagem code not recognized'
    # Pause/resume from touch-only buttons.
    pause=page.locator('#tcTools [data-key="escape"]') if page.locator('#tcTools [data-key="escape"]').count() else page.locator('#tcTools [data-action="pause"]')
    if pause.count()==0: pause=page.locator('#tcTools button').last
    pause.dispatch_event('pointerdown',{'pointerId':70,'button':0})
    page.wait_for_timeout(60)
    pause.dispatch_event('pointerup',{'pointerId':70,'button':0})
    page.wait_for_timeout(80)
    assert page.evaluate('state')=='pause', 'touch pause failed'
    page.locator('#tcAdvance').dispatch_event('pointerdown',{'pointerId':71,'button':0})
    page.wait_for_timeout(55)
    page.locator('#tcAdvance').dispatch_event('pointerup',{'pointerId':71,'button':0})
    page.wait_for_timeout(70)
    assert page.evaluate('state')=='playing', 'touch resume failed'
    print('two-thumb, stratagem, pause/resume tests passed')
    page.screenshot(path=str(out/'TOUCH_MOBILE_GAMEPLAY.png'))
    print('errors:',errors)
    assert not errors
    assert page.evaluate('state')=='playing'
    assert page.locator('#belTouchControls').is_visible()
    context.close()
    context2=browser.new_context(viewport={'width':1280,'height':800},device_scale_factor=1)
    desktop=context2.new_page()
    desktop.set_content(html,wait_until='domcontentloaded')
    desktop.wait_for_timeout(200)
    print('desktop touch toggle count',desktop.locator('#belTouchToggle').count())
    print('desktop touch controls count',desktop.locator('#belTouchControls').count())
    assert desktop.locator('#belTouchControls').count()==0
    browser.close()
