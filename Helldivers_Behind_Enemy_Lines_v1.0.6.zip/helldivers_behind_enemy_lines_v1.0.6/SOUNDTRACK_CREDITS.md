# Original Soundtrack — Behind Enemy Lines

Both original compositions were provided by the project owner, who stated they hold the rights and authorized integration into the game.

## Cup of Liber-tea
- Source recording: `Cup-of-Liber-tea-masterforge-signature.wav`
- Source format: stereo PCM, 48,000 Hz, 24-bit, 2:26
- In-game use: nearby hostile/combat encounters
- Optimized asset: `audio/cup_of_liber_tea_combat.mp3`

## By Order of High Command
- Source recording: `By-Order-of-High-Command-masterforge-signature.wav`
- Source format: stereo PCM, 48,000 Hz, 24-bit, 3:12.72
- In-game use: Warden and Reactor Sentinel boss encounters
- Optimized asset: `audio/by_order_of_high_command_boss.mp3`

The final music credits should list the artist/composer name as requested by the rights holder (not yet provided). In-game derivatives are not a license to redistribute the original masters. The public game release includes compressed tracks only, not master WAVs.
