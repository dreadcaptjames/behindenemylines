# v1.0.6 — Test report

## Browser / source verification
- `node tests/test_headless_canvas.js` — 254/254 original visual assets, entire campaign flow, equipment, save migration, bosses, artwork/cinematics.
- `node tests/test_original_music.js` — original music source references, cue switching, Web Audio gain/mixer, dialogue ducking, mute, volume persistence.
- `node tests/test_gait_and_muzzle.js` — eight-pose locomotion and seven muzzle/aim directions.
- `python tests/test_hero_art.py` — jump/dive pose and rifle asset checks.
- `python tests/test_mobile_gestures.py` — mobile gesture protection and simultaneous touch hold controls.
- `ffprobe` — both compressed tracks decode and have expected duration/sample rate/bitrate.

## Limitations
- Actual Safari-on-iPad audio playback must still be tested on a physical device.
- Full Chromium page navigation is blocked in this environment; Canvas engine logic and mobile gesture tests passed, but live browser playback was not observed.
- The Godot companion includes the music streams but has not been run-tested inside Godot.
- The complete game ZIP is prepared for GitHub; this build has not been published to GitHub Pages yet.
