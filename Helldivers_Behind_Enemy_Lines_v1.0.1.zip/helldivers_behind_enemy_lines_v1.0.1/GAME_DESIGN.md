# Animation / readability note — v1.0.1

The Helldiver must not read as a stationary miniature. Running should have articulated leg poses and alternating contacts, with recognizable knee bends and raised recovery feet. Avoid rectangular region rotation applied to full painted sprites. Avoid cast shadows merged with a transparent character sprite. Keep enemy and world collision logic independent from animation pixels.
