"""Construct actual articulated pixel-art hero frames.

Uses the user-approved pixel character's torso/cape/weapon, isolates each into
transparent painted layers, and draws new anatomical thigh/shin/knee/boot poses.
No ground shadow is included in any rendered hero sprite.
Requires Pillow. Rerun from project root: python tools/build_hero_animations.py
"""
from PIL import Image, ImageDraw
from pathlib import Path
from math import hypot, sqrt, atan2, sin, pi

ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'art'
SOURCE=ART/'hero_idle_0_r.png'
# Keep canonical painted source untouched so regeneration is stable.
CANON=ART/'hero_source_art_r.png'
if not CANON.exists():
    CANON.write_bytes(SOURCE.read_bytes())
source=Image.open(CANON).convert('RGBA')
assert source.size==(84,72)
PX=Image.Resampling.NEAREST

DARK='#100b1c'; MID='#392c4e'; MIDHI='#5d476c'; LIT='#877295'
METAL='#6b6174'; BRIGHT='#b59dab'; GOLD='#ffca15'; GOLD_DARK='#aa6d0c';
BOOT='#2c2338'; BOOT_HI='#77647d'; OUTLINE='#0c0715'

def mask_poly(points):
    out=Image.new('L',source.size,0)
    ImageDraw.Draw(out).polygon(points,fill=255)
    return out

cape_mask=mask_poly([(32,28),(39,30),(36,42),(35,50),(29,55),(22,55),(17,52),(12,53),(14,47),(22,40),(27,34)])
gun_mask=mask_poly([(43,23),(59,22),(63,23),(69,23),(76,24),(76,38),(63,39),(59,36),(48,36),(45,34),(40,33),(39,28)])

cape=Image.new('RGBA',source.size); cape.paste(source,(0,0),cape_mask)
gun=Image.new('RGBA',source.size); gun.paste(source,(0,0),gun_mask)
body=Image.new('RGBA',source.size)
for y in range(44):
 for x in range(84):
  if cape_mask.getpixel((x,y)) or gun_mask.getpixel((x,y)): continue
  if y<39 or (34<=x<=58 and y<=43):
   body.putpixel((x,y),source.getpixel((x,y)))
# Important: do not include any of the original leg artwork or floor shadow.

def rotation(layer,angle,pivot):
    # nearest-neighbor art rotation around shoulder/attachment, not gross slab motion
    return layer.rotate(angle,resample=PX,center=pivot)

def thick_line(d, xy, width, fill):
    d.line(xy,fill=fill,width=max(1,round(width)),joint='curve')
    r=width/2
    for xx,yy in xy:
      d.ellipse((round(xx-r),round(yy-r),round(xx+r),round(yy+r)), fill=fill)

def armor_leg(frame,hip,foot,front,grounded=True,brightness=1,knee=None):
    """Draw one leg from an IK joint solution, with armor plates following anatomy."""
    h=(float(hip[0]),float(hip[1])); a=(float(foot[0]),float(foot[1]))
    dx=a[0]-h[0];dy=a[1]-h[1]
    d=max(1,hypot(dx,dy)); thigh=14.8; shin=16.2
    if d>thigh+shin-.5:
      thigh+=.5;shin+=d-(thigh+shin)+1
    n=(dx/d,dy/d)
    along=(thigh*thigh-shin*shin+d*d)/(2*d)
    side=sqrt(max(.1,thigh*thigh-along*along))
    # Knee is slightly forward from the ankle axis, matching actual running mechanics.
    # Two possible knee bend directions; choose front for stepping foot, rear for recovery.
    bend=1 if foot[0]>=hip[0]-2 else -1
    k=(h[0]+along*n[0]+side*n[1]*bend, h[1]+along*n[1]-side*n[0]*bend) if knee is None else knee
    img=Image.new('RGBA',(84,72),(0,0,0,0)); z=ImageDraw.Draw(img)
    # Rear half is cooler/darker to create depth, highlights show on the foreground leg.
    shell=MIDHI if front else MID
    high=GOLD if front else GOLD_DARK
    plate=LIT if front else MIDHI
    # tapered thigh: dark silhouette and angular armor plate
    thick_line(z,[h,k],14,OUTLINE)
    thick_line(z,[h,k],11,shell)
    thick_line(z,[(h[0]+(k[0]-h[0])*.15,h[1]+(k[1]-h[1])*.15),
                  (h[0]+(k[0]-h[0])*.69,h[1]+(k[1]-h[1])*.69)],3,plate)
    # Segmented upper thigh armor, with independent highlight plates.
    dxk=k[0]-h[0]; dyk=k[1]-h[1]
    sx=h[0]+dxk*.32; sy=h[1]+dyk*.32
    z.polygon([(sx-4,sy-3),(sx+3,sy-5),(sx+6,sy+1),(sx+1,sy+5),(sx-4,sy+3)],fill=METAL if front else MIDHI)
    z.line((sx-2,sy-3,sx+2,sy-3),fill=GOLD if front else BOOT_HI,width=2)
    # shoulder-type waist joint, industrial style
    z.ellipse((h[0]-4,h[1]-3,h[0]+4,h[1]+3),fill=OUTLINE)
    z.ellipse((h[0]-2,h[1]-2,h[0]+2,h[1]+2),fill=MIDHI if front else MID)
    z.point((int(h[0]-1),int(h[1]-1)),fill=GOLD if front else BOOT_HI)
    # knee cap + golden kneepad
    z.ellipse((k[0]-5,k[1]-5,k[0]+5,k[1]+5),fill=OUTLINE)
    z.ellipse((k[0]-4,k[1]-4,k[0]+4,k[1]+3),fill=GOLD_DARK if front else MIDHI)
    z.polygon([(k[0]-3,k[1]-3),(k[0]+1,k[1]-3),(k[0]+4,k[1]-1),(k[0]+2,k[1]+2),(k[0]-3,k[1]+1)],fill=GOLD if front else METAL)
    z.line((k[0]-3,k[1]-2,k[0]+1,k[1]-2),fill='#fff2a1' if front else '#93869e',width=1)
    # independently articulated shin
    thick_line(z,[k,a],11,OUTLINE)
    thick_line(z,[k,a],8,MID)
    px=-(a[1]-k[1])/max(1,hypot(a[0]-k[0],a[1]-k[1]))
    py=(a[0]-k[0])/max(1,hypot(a[0]-k[0],a[1]-k[1]))
    z.line((k[0]+px*3,k[1]+py*3,a[0]+px*3,a[1]+py*3),fill=high,width=2)
    z.line((k[0]-px,k[1]-py,a[0]-px,a[1]-py),fill=plate,width=2)
    # boot points forward, heel and toe have separate shapes, never any floor-shadow region
    fx,fy=a
    foot_drop=0 if fy>=66 else -1
    z.polygon([(fx-6,fy-6),(fx+3,fy-6),(fx+4,fy-2),(fx+9,fy+foot_drop),(fx+9,fy+3),(fx-6,fy+3)],fill=OUTLINE)
    z.polygon([(fx-4,fy-5),(fx+1,fy-6),(fx+3,fy-2),(fx+7,fy),(fx+7,fy+1),(fx-4,fy+1)],fill=BOOT)
    z.line((fx-3,fy-4,fx+3,fy-4),fill=BOOT_HI,width=2)
    z.line((fx+4,fy,fx+7,fy),fill=LIT if front else MIDHI,width=1)
    return img

# Eight actual gait poses: contact -> compression -> passing -> push-off, alternating feet.
# Foot recovery actually lifts from the floor; knees bend via 2-bone IK.
run_poses=[
 # (leading ankle, trailing ankle, leading knee, trailing knee, vertical bob)
 ((58,66),(34,60),(54,53),(37,51), 0),
 ((54,66),(40,55),(52,53),(42,50), 1),
 ((48,67),(49,58),(49,53),(52,51), 0),
 ((38,60),(56,66),(40,51),(53,53),-1),
 ((34,60),(58,66),(37,51),(54,53), 0),
 ((40,55),(54,66),(42,50),(52,53), 1),
 ((49,58),(48,67),(52,51),(49,53), 0),
 ((56,66),(38,60),(53,53),(40,51),-1),
]

def sprite(kind,idx):
 out=Image.new('RGBA',(84,72),(0,0,0,0))
 if kind=='run':
    a,b,knea,kneb,bob=run_poses[idx]
    cape_angle=[-7,-13,-19,-15,-6,6,13,2][idx]
    gun_angle=[-1,-3,-2,0,1,-1,0,2][idx]
    recoil=(0,0)
 elif kind=='idle':
    a,b,bob=(35,66),(57,66),[0,0,-1,0][idx]
    cape_angle=[0,-1,1,2][idx];gun_angle=[0,0,-1,0][idx];recoil=(0,0)
 elif kind=='fire':
    a,b,bob=(35,66),(57,66),0
    cape_angle=[-1,-3,1][idx];gun_angle=[-2,-6,-3][idx]
    recoil=[(-1,-1),(-3,-2),(-1,0)][idx]
 elif kind=='reload':
    a,b,bob=(35,66),(57,66),0
    cape_angle=[0,2,1][idx];gun_angle=[8,14,3][idx];recoil=[(0,1),(-2,2),(0,0)][idx]
 elif kind=='land':
    a,b,bob=(36,67),(57,67),[2,3,2,0][idx]
    cape_angle=[-5,1,7,2][idx];gun_angle=[3,2,0,0][idx];recoil=(0,0)
 elif kind=='jet':
    a,b,bob=(39,57),(56,60),[-3,-4,-3,-2][idx]
    cape_angle=[-22,-27,-19,-24][idx];gun_angle=[2,3,2,1][idx];recoil=(0,0)
 elif kind=='jump':
    a,b,bob=(40,58),(56,62),-3
    cape_angle=-15;gun_angle=1;recoil=(0,0)
 elif kind=='dive':
    a,b,bob=(29,62),(62,60),-5
    cape_angle=[-20,-33][idx];gun_angle=[-5,-10][idx];recoil=(-2,-1)
 elif kind=='hurt':
    a,b,bob=(33,66),(55,66),[0,2,0][idx]
    cape_angle=[9,-8,4][idx];gun_angle=[-8,4,-3][idx];recoil=(1,1)
 else:raise ValueError(kind)
 # keep body front/back balanced around a hip line and float the torso 1–2 px as needed
 # cape behind entire rig, then rear leg, upper body, lead leg, weapon
 rotated_cape=rotation(cape,cape_angle,(34,30))
 out.alpha_composite(rotated_cape,(0,bob))
 if kind=='run':
    if idx<4:
      back_foot=b;front_foot=a;back_knee=kneb;front_knee=knea
      back_hip=(42,40+bob);front_hip=(50,40+bob)
    else:
      back_foot=a;front_foot=b;back_knee=knea;front_knee=kneb
      back_hip=(50,40+bob);front_hip=(42,40+bob)
 else:
    back_foot=a;front_foot=b
    back_hip=(41,40+bob);front_hip=(51,40+bob)
    back_knee=None;front_knee=None
 back=armor_leg(idx,back_hip,back_foot,False,knee=back_knee)
 front=armor_leg(idx,front_hip,front_foot,True,knee=front_knee)
 out.alpha_composite(back)
 out.alpha_composite(body,(0,bob))
 out.alpha_composite(front)
 rotated_gun=rotation(gun,gun_angle,(43,28))
 out.alpha_composite(rotated_gun,recoil)
 return out

for name,count in {'idle':4,'run':8,'jump':1,'dive':2,'fire':3,'reload':3,'jet':4,'land':4,'hurt':3}.items():
 for i in range(count):
  right=sprite(name,i)
  right.save(ART/f'hero_{name}_{i}_r.png')
  right.transpose(Image.Transpose.FLIP_LEFT_RIGHT).save(ART/f'hero_{name}_{i}_l.png')

# Contact sheet for inspecting clear weight shift and leg action at native pixel scale.
frames=[Image.open(ART/f'hero_run_{i}_r.png').convert('RGBA') for i in range(8)]
sheet=Image.new('RGBA',(84*8,72),(24,17,35,255))
for n,im in enumerate(frames): sheet.alpha_composite(im,(84*n,0))
sheet.save(ROOT/'ANIMATION_STRIP.png')
frames[0].save(ROOT/'ANIMATION_FRAME.png')
# Animated preview allows visible verification without an engine runtime.
frames[0].save(ROOT/'RUN_CYCLE.gif',save_all=True,append_images=frames[1:],duration=90,loop=0,disposal=2,optimize=False)
print('Generated',sum([4,8,1,2,3,3,4,4,3])*2,'rigged character frames with no baked ground shadows')
