const fs=require('fs'),vm=require('vm'),path=require('path');
const {Canvas,Image}=require('skia-canvas');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'browser-demo/index.html'),'utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const view=new Canvas(960,540);
view.getBoundingClientRect=()=>({left:0,top:0,width:480,height:270});view.focus=()=>{};view.addEventListener=()=>{};
const make=()=>({hidden:false,innerHTML:'',append(){},setAttribute(){},addEventListener(){},focus(){},onclick:null});
const elements={game:view,controlsToggle:make(),controlsPanel:make(),bindingList:make(),controllerStatus:make(),closeBindings:make(),resetBindings:make()};elements.controlsPanel.hidden=true;
const document={getElementById:k=>elements[k]||(elements[k]=make()),createElement:tag=>make()};
class Img extends Image{set src(url){super.src=path.resolve(root,'browser-demo',url)}get naturalWidth(){return this.width}get naturalHeight(){return this.height}}
class Audio{constructor(){this._volume=0;this.loop=false;}cloneNode(){return this}play(){return Promise.resolve()}set volume(v){this._volume=v}get volume(){return this._volume}}
const items=new Map();const localStorage={getItem:k=>items.get(k)||null,setItem:(k,v)=>items.set(k,v),removeItem:k=>items.delete(k)};
const ctx=vm.createContext({console,Math,Set,Map,Audio,Image:Img,document,window:{addEventListener(){}},navigator:{getGamepads:()=>[]},localStorage,requestAnimationFrame:()=>{},performance:{now:()=>0},Date});
vm.runInContext(js,ctx,{filename:'browser-demo/index.html'});
const run=q=>vm.runInContext(q,ctx);
const assert=(a,m)=>{if(!a)throw Error('ASSERT FAILED: '+m)};
const snap=async name=>{run('tutorial=0;notifyCd=0;render()');await fs.promises.writeFile(path.join(root,name),await view.toBuffer('png'))};
(async()=>{
 await new Promise(r=>setTimeout(r,950));
 assert(run('art.automaton_emblem.naturalWidth')===128,'uploaded Automaton emblem loaded');
 console.log('Assets:',run('assets.filter(x=>art[x]?.naturalWidth).length'),run('assets.length'));
 assert(run('assets.filter(x=>art[x]?.naturalWidth).length')===run('assets.length'),'all assets loaded');
 await snap('SCREENSHOT_TITLE.png');
 run("pressed.add('enter');update(.016)");for(let i=0;i<3;i++)run("pressed.add('enter');update(.016)");assert(run('state')==='playing','new game intro');
 run("keys.add('d')");for(let i=0;i<35;i++)run('update(.016)');run("keys.delete('d')");assert(run('p.x')>140,'movement');
 run("keys.add('f')");for(let i=0;i<10;i++)run('update(.016)');run("keys.delete('f')");assert(run('p.ammo')<18,'F fire');
 await snap('SCREENSHOT_GAMEPLAY.png');
 run('p.x=1490;p.y=170;jet=true;interact()');assert(run('sector')==='sublevel','old maintenance');
 run('p.x=948;p.y=170;interact()');assert(run('breach'),'old arc cutter');run("pressed.add('enter');update(.016)");
 run('p.x=67;p.y=211;interact()');assert(run('sector')==='main','old return');
 run('p.x=596;p.y=151;interact()');assert(run('sector')==='archive','old archive');
 run('p.x=610;p.y=181;interact()');assert(run('armor'),'old armor');run("pressed.add('enter');update(.016)");
 run('sector="main";enem=roomEnemies.main;p.x=2904;p.y=228;comms=true;bossAwake=true;bossDead=false;checkpoint={sector:"main",x:2220,y:228};');
 run('kill(enem.find(e=>e.kind==="warden"))');assert(run('bossDead')&&run('state')==='dialogue','warden opens chapter 2');
 for(let i=0;i<3;i++)run("pressed.add('enter');update(.016)");assert(run('state')==='playing','warden dialogue finishes');
 run('p.x=3025;p.y=215;interact()');assert(run('sector')==='blacksite','enter blacksite');
 for(let i=0;i<3;i++)run("pressed.add('enter');update(.016)");
 run('camera=320;p.x=540;p.y=228;enem=roomEnemies.blacksite;');await snap('SCREENSHOT_BLACKSITE.png');
 run('p.x=451;p.y=172;interact()');assert(run('switchA'),'junction A');run("pressed.add('enter');update(.016)");
 run('p.x=850;p.y=168;interact()');assert(run('emp'),'EMP collected');run("pressed.add('enter');update(.016)");
 run('bullets.push({x:p.x+9,y:p.y-22,vx:40,team:1,t:2});');run('empPulse()');assert(run('pulseCd')>0,'EMP cooldown');assert(run('bullets.at(-1).t')===0,'EMP clears projectiles');
 run('p.x=1339;p.y=179;interact()');assert(run('switchB'),'junction B');run("pressed.add('enter');update(.016)");
 run('p.x=1555;p.y=220;interact()');assert(run('sector')==='reactor','reactor hatch');for(let i=0;i<1;i++)run("pressed.add('enter');update(.016)");
 run('p.x=506;p.y=170;interact()');assert(run('reactorOff'),'coolant disabled');run("pressed.add('enter');update(.016)");
 run('p.x=920;p.y=228;update(.016)');assert(run('sentinelAwake'),'sentinel awaken');run("pressed.add('enter');update(.016)");
 run('p.x=893;p.y=228;camera=700;enem=roomEnemies.reactor;');await snap('SCREENSHOT_REACTOR.png');
 const boss=run('enem.find(e=>e.kind==="sentinel")');assert(boss,'boss exists');run('kill(enem.find(e=>e.kind==="sentinel"))');assert(run('sentinelDead'),'sentinel defeated');for(let i=0;i<3;i++)run("pressed.add('enter');update(.016)");assert(run('state')==='victory','final sequence');await snap('SCREENSHOT_VICTORY.png');
 assert(run('hasSave()'),'save exists');
 run('state="title"');assert(run('continueProgress()'),'v050 resume');assert(run('emp&&switchA&&switchB&&reactorOff&&sentinelDead'),'all flags restored');assert(run('sector')==='reactor','reactor checkpoint retained');
 // Migration of a real v0.4 structured save, including access to post-warden sector.
 items.delete('behind_enemy_lines_v060');items.set('behind_enemy_lines_v040',JSON.stringify({v:3,jet:true,comms:true,breach:true,armor:true,intel:[1,3],visited:{main:true,archive:true},checkpointNum:2,stimUsed:false,deaths:0,kills:7,bossDead:true}));
 assert(run('continueProgress()'),'v040 migration');assert(run('armor&&jet&&breach'),'old unlock flags imported');assert(run('bossDead'),'old warden flag imported');assert(items.has('behind_enemy_lines_v060'),'new save written');
 run('camera=150;p.x=350;p.y=228;sector="main";enem=roomEnemies.main;mapOpen=true;');await snap('SCREENSHOT_MAP.png');
 // New v0.6.0 features: detection + wind-up, attack phase, portraits and music.
 run("reset();state='playing';p.x=535;p.y=228;p.ground=true;p.vx=0;enem=roomEnemies.main;enem[0].x=452;enem[0].cd=-.1;enem[0].telegraph=0");
 run('update(.016)'); assert(run('enem[0].telegraph')>0,'walker telegraph begins before firing');
 assert(run('bullets.filter(b=>b.team===1).length')===0,'no instant enemy bullet');
 run('enem[0].telegraph=.005;update(.016)');assert(run('bullets.filter(b=>b.team===1).length')>0,'windup resolves into a shot');
 run("sector='reactor';enem=roomEnemies.reactor;p.x=905;p.y=228;p.ground=true;p.vx=0;sentinelAwake=true;reactorOff=true;enem.at(-1).hp=10;enem.at(-1).telegraph=.005;enem.at(-1).aimX=905;enem.at(-1).aimY=200;bullets=[];");
 run('update(.016)');assert(run('bullets.filter(b=>b.team===1).length')>=5,'phase-two Sentinel fires five shots');
 run("say([['UNKNOWN TRANSMISSION','WE ARE STILL HERE.','DO NOT TRUST EXTRACTION ORDERS.']]);dialogAge=4;camera=660;");await snap('SCREENSHOT_CINEMATIC.png');
 assert(run('radioPortrait(dialog[0][0])')==='radio_survivor','survivor radio art');
 assert(run('logs.length')===8,'two extra story traces');
 assert(run('Object.keys(musicTracks).length')===3,'three adaptive music layers');
 run('state="playing";musicOn=true;musicStarted=true;adaptiveMusic(.5)');
 assert(run('musicTracks.ambient.volume')>0,'music mixer reacts to active state');
 run("say([['AUTOMATON COMMAND LINK','UNAUTHORIZED LIFEFORM DETECTED.','WARDEN UNIT: EXTERMINATION PROTOCOL.']]);dialogAge=4;");await snap('SCREENSHOT_AUTOMATON_COMMS.png');
 // v1.0.1: Helldivers-inspired unit lineup is wired to real encounter spawns,
 // not just artwork in the assets directory.
 const units=run('Array.from(new Set([...initialEnemies(),...sideEnemies(),...blacksiteEnemies(),...reactorEnemies()].map(e=>e.unit).filter(Boolean)))');
 for(const unit of ['trooper','marauder','strider','rocket_devastator','heavy_devastator','berserker','devastator'])
   assert(units.includes(unit),'campaign includes '+unit);
 assert(run('automatonUnitTypes.length')===7,'all unit variants registered');
 assert(run('art.bot_rocket_devastator_1_r.naturalWidth')===52,'rocket variant is a real sprite');
 run('bullets=[];p.x=300;p.y=228;enemyShoot({kind:"walker",unit:"rocket_devastator",x:400,y:228,dir:-1,aimX:300,aimY:200})');
 assert(run('bullets.length===1 && bullets[0].rocket===true'),'rocket Devastator uses rocket projectile');
 run('bullets=[];enemyShoot({kind:"walker",unit:"berserker",x:400,y:228,dir:-1})');
 assert(run('bullets.length')===0,'Berserker does not fire ranged shots');
 console.log('PASS: v1.0.1 Character motion correction + full campaign + art + cinematics + saves');
})().catch(e=>{console.error(e);process.exitCode=1});
