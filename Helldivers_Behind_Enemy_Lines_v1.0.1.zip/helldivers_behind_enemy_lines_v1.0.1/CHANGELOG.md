# v1.0.1 — Character Motion Correction

- Removed the body-piece rotations that left feet and torso disconnected.
- Introduced fully composed frame-specific character art with coordinated knees, ankles, and boots.
- Removed both the renderer's oval shadow and the old sprite-baked shadow from in-game player sprites.
- Running animation now advances from actual horizontal movement, not just elapsed time.
- Run animation continues while moving and firing/reloading; independent muzzle flash remains active.
- Preserved all missions, progression, emblems, and enemy content.
- Reproducible art generation: `tools/build_hero_animations.py`.
