# HELLDIVERS: BEHIND ENEMY LINES — v1.0.1

## Character animation correction — leg poses and shadow removal

This is a full project build based on v1.0.0. It specifically corrects the rigid / disjoint character animation and the tabletop-miniature shadow.

### What changed
- Replaced the old rectangular body-part animation method with **64 fully composed pixel-art sprite frames**. There are eight unique running poses (in both facing directions), plus idle, jump, dive, landing, firing, reload, jump-jet, and hurt states.
- Built leg motion from coordinated hip, knee, ankle, and foot positions. At each step the rear foot lifts and comes forward, instead of legs simply phasing sideways.
- Kept the approved armor, rifle, and cape appearance, but recomposed those elements in the animation frames with movement and recoil.
- Removed the generated ground-shadow ellipse in the browser renderer **and** removed the broad baked-in floor shadow from the new sprite frames.
- Synchronized the running frame to **resolved horizontal travel distance**; running while firing / reloading keeps the run-cycle instead of reverting to a stationary firing pose.
- Updated the Godot source to use the new sprite set and a matching distance-based running cycle. The Godot runtime has not been executed here.

### Play
Extract the ZIP and open `browser-demo/index.html`; press **Enter** to deploy.

See `RUN_CYCLE_PREVIEW.gif` for an animated preview generated directly from the playable sprite frames and `ANIMATION_KEYFRAMES.png` for the eight run keyframes.

### Controls
A / D movement • Mouse 1 fire • F keyboard fire • Space jump • Shift dive • E interact • R reload • Q Stratagem • M map • G EMP after unlock. Keybindings can be changed from the browser controls panel.

### Build verification
`node tests/test_headless_canvas.js` passed; `python tests/test_hero_art.py` passed. The browser test suite is a headless Canvas/game-logic harness, not an exhaustive manual playtest. The editable Godot project remains unverified in the engine.
