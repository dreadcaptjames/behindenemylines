# Behind Enemy Lines v1.0.12 — Phase 4: Environmental Atmosphere

## Game changes

- Introduced hand-placed, world-anchored animated ventilation fans and drive machinery across all eight sectors. The Freight Conduit and Maintenance Sublevel also gain moving conveyor-roller detail (decoration only; physics and collision are unchanged).
- Added subtle sector-specific steam emissions, coolant droplets, industrial dust and sparks, underlit service lamps, and fixed light shafts with colored status feedback.
- Environments now communicate actual story progress: machinery and warning lights change to operational colors after comms, freight, pump, reactor, Blacksite, and Shelter Twelve objectives are completed.
- Added in-world environmental storytelling details: evacuation and warning signage, storage crates, archived databanks, abandoned supply cots and a hand-painted shelter message.
- Reduced background shimmer: world-anchored placement and time-based motion always draw before platforms, interactables, enemies, bullets and the Helldiver. No foreground blocking rectangles are introduced.
- Added **Low-detail environment effects** in Options. This preference persists locally and reduces ambient particle counts, animated machinery detail, background turbines and lighting passes; existing **Reduce screen shake and damage flashes** additionally tempers motion and flicker.
- Preserved all eight areas and their objectives, jump/dive and weapon alignment, Act III save support, dual-thumb touch controls, and the continuous *Cup of Liber-tea* main soundtrack with *By Order of High Command* during major bosses.

## Technical notes

- Atmosphere is drawn directly in Canvas, using the existing art library. No new textures or external packages are needed; every fixture is culled when outside the visible camera.
- Objective progress changes only scenery state; no new collision or traversal mechanics were introduced.
- Updated the HTML document title, in-game build label, and versioned mobile stylesheet/script references to v1.0.12.

## Verification

- New `node tests/test_phase4_atmosphere.js`: all eight renderers, animated frames, stable collision-edge pixels, powered/unpowered lighting, locally saved low-detail and reduced-effects preferences — PASS.
- `python tests/test_phase4_browser.py`: Chromium desktop and iPad-size touch emulation — PASS; options and scenes load without page errors.
- Campaign, Act III traversal, Phase 1 palette/depth, Phase 2 movement/rifle, Phase 3 UI, soundtrack and focused gesture tests — PASS.
- One older extended mobile-touch test stalled and is **not** counted as passed; physical iPad Safari testing remains outstanding.
- Godot companion remains an older prototype and was not ported or engine-tested for this phase.

## Deployment

Upload the complete `Helldivers_Behind_Enemy_Lines_v1.0.12.zip` to the repository root on `main`; the existing GitHub Pages workflow deploys the latest release. This operation has not pushed files to GitHub.
