# Helldivers: Behind Enemy Lines — v1.0.8

## Act III — The Survivors Below

This is a **playable** three-area continuation of Operation Dead Signal. After defeating the Reactor Sentinel, the Helldiver discovers the freight hatch on the eastern side of the Reactor Core. The story no longer ends immediately after the boss battle.

### New areas

1. **Freight Conduit 09** (1,840 game units). Restoring Alpha and Beta freight junctions reopens the deep pumping station. The terrain has multiple gaps, elevated catwalks, a drone patrol, and full-sized Automaton infantry including a Strider and Heavy Devastator.
2. **Flooded Pumpworks** (1,540 units). Electrified flood gaps, steam, and new industrial background art create a distinct traversal space. Stabilize both pumps so the civilian shelter can receive water and life support again. Includes a Berserker, Rocket Devastator, drone, and turret.
3. **Shelter Twelve** (1,420 units). An occupied civilian refuge, not another boss arena. Clear the Automaton security force, restore local communications, reach the sealed shelter door, and uncover the truth behind Mission Control's evacuation order. Five new story dialogue pages resolve the chapter.

Six collectible black-box / survivor records are distributed throughout the three areas. Every new sector can be revisited, and new checkpoints/save flags persist across reloads. The existing v1.0.7 save file migrates automatically to the v6 save schema without erasing Act I/II progress.

### Gameplay fixes

- Made thin elevated catwalks one-way/jump-through. The player's run is no longer blocked by invisible platform side walls and their undersides do not stop a rising jump.
- Added status indicators and objectives for the new levels on the tactical HUD and sector map.
- The automatic music design remains **unchanged**: Cup of Liber-tea plays continuously during exploration and normal combat; By Order of High Command only overrides it for major boss fights.
- Kept the established iPad controls, weapon aim, movement art, enemy proportions, EMP, and orbital stratagem.

### Deployment / scope

Browser Canvas game, textures, and mobile controls are complete and tested in automated emulation. The repository's existing GitHub Pages workflow picks the highest versioned full ZIP; upload `Helldivers_Behind_Enemy_Lines_v1.0.8.zip` at the root of `main` to deploy. **This release is not yet pushed to GitHub.**

The included Godot project remains the **previous Act I/II companion** and is not an Act III feature-parity release. The new campaign content is implemented and tested in the **browser build**; porting it to Godot would be a separate milestone. Physical iPad Safari and Godot engine testing were not performed.
