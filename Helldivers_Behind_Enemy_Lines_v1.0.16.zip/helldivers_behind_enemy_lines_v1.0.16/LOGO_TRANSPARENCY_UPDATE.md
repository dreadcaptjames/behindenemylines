# v1.0.15 — Helldiver emblem transparency

- Original Helldiver Icon SVG remains intact and has an alpha-transparent background.
- `art/helldiver_logo_transparent.png` provides a high-resolution (512×512) RGBA transparent export of that original vector.
- HUD and Helldiver radio portrait no longer paint dark rectangular backplates directly behind the crest.
- Menu panel and other HUD backgrounds remain intact for legibility.
- No changes to gameplay, music, save data, or mobile controls.
