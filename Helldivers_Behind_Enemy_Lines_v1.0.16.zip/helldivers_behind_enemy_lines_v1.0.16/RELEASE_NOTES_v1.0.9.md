# Helldivers: Behind Enemy Lines — v1.0.9

## Phase 1 — Visual System Cleanup (browser build)

This update is focused on visual hierarchy across the existing eight campaign areas; **no new levels, combat mechanics, or UI layout redesign** are included.

### Changes

- Created one **8-room visual palette system** for scene atmosphere, platform tops, collision-surface metalwork, status highlights, accessible interactions, and hazards. The level color identities remain distinct while the same meaning is assigned to the same kind of object everywhere.
- Reduced environmental art overdraw and the opacity of dense midground structures. Improved visibility of the high-resolution industrial backdrop in Maintenance, Archive, Blacksite, and Reactor without letting that backdrop overlay gameplay sprites.
- Added a gradual play-plane contrast matte, always drawn *behind* the actual terrain and characters. Preserved the corrected non-occluding render order (no full-height moving foreground bars or cables).
- Reworked the platform material pass: clean continuous top contact line, quieter patterned floor faces, restrained hardware details, and clearer outlines on the 12px one-way elevated platforms.
- Added black/yellow-coral warnings at actual floor-gap edges only, instead of repeating stripes across every surface. This uses the original collision geometry and does not alter jump distances.
- In-world compact interaction beacons now use a consistent gold actionable / coral locked visual language. They remain underneath the player and enemies, not on the full-screen overlay.
- Electrified Pumpworks water uses an amber-white hazard highlight, distinct from safe cyan electronics and water machinery. Restored water is subdued.
- Unified ready/locked door and mission-node status lights using sector semantic colors.

### Preserved

All eight playable browser areas across the three acts, quest/save flags, two original compositions with continuous Cup of Liber-tea outside boss fights, Automaton proportions, weapon aim, jumps, dives, EMP, checkpoints, iPad touch controls, and downloadable Godot companion files.

### Verification

The new `tests/test_phase1_visual.js` renders all eight sectors using the actual Canvas game and asserts per-sector walkable-surface contrast/palette. The campaign, Act III movement/locks, music, rifle/animation, mobile touch and gesture tests were rerun. Physical Safari on iPad and the Godot runtime are **not** verified in this environment.

### Release scope / what's next

This is **Phase 1 of 5**. Phase 2 is character animation and sprite presentation; Phase 3 will revisit title menu, HUD and in-game navigation; Phase 4 is a more extensive environment ambient pass; Phase 5 improves touch layout.

This ZIP is sized for direct GitHub repository upload. Upload the *complete ZIP* to `dreadcaptjames/behindenemylines` at repository root on `main` to let its existing GitHub Pages workflow select this version. This document does not claim the archive has been pushed.

The Godot companion remains an earlier Act I/II prototype, not a feature-parity port of Act III or the new browser visual renderer.
