# Behind Enemy Lines v1.0.11 — Phase 3: Mission Interface

## The new user experience

- Rebuilt the title screen as a field-command terminal with clickable and keyboard/controller-navigable choices for New Deployment, Continue Checkpoint (when available), and Options & Controls.
- Added confirmation before a new deployment overwrites a saved checkpoint. Cancel leaves the save untouched.
- Rebuilt pause menu with Resume Mission, Sector Map, Options & Controls, and Return to Title. Returning to the title writes the current checkpoint state.
- Reduced the HUD to a slimmer three-zone combat ribbon: health/ammo, orbital/EMP, and sector information. The current objective now displays live progress where applicable (e.g. freight 1/2).
- Replaced the original crowded map overlay with a clearer three-act sector topology using current, visited, and incomplete area colors. The world now pauses while the map is open; M or Esc closes it.
- Redesigned in-world interaction prompts, loading notifications, boss health strips, and the game-complete actions.
- Refreshed the HTML header, game frame and an expandable keyboard field guide. A live status region provides accessible notification text.
- Options now include persistent reduced screen shake/damage flashes and persistent opening control hints, alongside the existing remappable keyboard and saved music settings.
- Updated touch layout around the new menus and checked landscape mobile behavior without reintroducing iPad native-gesture scrolling/selection.

## Preserved functionality

All eight areas, Act I–III objectives, checkpoint migration, Phase 1 environment readability, Phase 2 character animations, Automaton scale, mobile dual-thumb inputs, the continuous **Cup of Liber-tea** main theme, and **By Order of High Command** boss theme are retained.

## Verification

Passed automated Canvas campaign progression (257/257 visual assets), Act III traversal, audio-state transitions, gait/rifle alignment, Phase 1 visual hierarchy, Phase 2 sprite verification, new UX/menu/save/map regression, and browser touch gestures. Playwright Chromium exercised desktop pointer navigation and options, keyboard pause/map, and emulated mobile touch deployment, dialogue progression, and screen bounds.

Limitations: no physical iPad Safari hardware playthrough. Godot companion remains an earlier, non-Act-III prototype and was not engine-tested. No GitHub push is included in this ZIP generation.

## Deployment

Upload `Helldivers_Behind_Enemy_Lines_v1.0.11.zip` intact to the root of `dreadcaptjames/behindenemylines` and commit to `main`; the existing Pages workflow is configured to unpack the latest release. Music may begin after a user gesture due to browser autoplay policies.
