"""Playwright desktop and touch interaction smoke tests for phase 3."""
from pathlib import Path
from urllib.parse import urlparse,unquote
from playwright.sync_api import sync_playwright
import mimetypes
root=Path(__file__).resolve().parents[1]
html=(root/'browser-demo/index.html').read_text().replace('<head>','<head><base href="https://game.test/browser-demo/">',1)

def route_local(route):
    path=unquote(urlparse(route.request.url).path).lstrip('/')
    file=(root/path).resolve()
    if file.is_file() and file.is_relative_to(root):
        route.fulfill(status=200,body=file.read_bytes(),content_type=mimetypes.guess_type(file)[0] or 'application/octet-stream')
    else: route.fulfill(status=404,body='missing file')

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required'])
    desktop=browser.new_context(viewport={'width':1280,'height':840})
    desktop.route('https://game.test/**',route_local)
    page=desktop.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html,wait_until='domcontentloaded');page.wait_for_timeout(900)
    assert page.evaluate('state')=='title'
    assert page.locator('header .brand-copy strong').inner_text()=='OPERATION DEAD SIGNAL'
    assert page.locator('#controlsPanel').is_hidden()
    box=page.locator('#game').bounding_box()
    assert box
    def click_canvas(cx,cy):page.mouse.click(box['x']+cx/480*box['width'],box['y']+cy/270*box['height'])
    # Select Settings from actual game menu with mouse, test preference toggles.
    click_canvas(110,202);assert page.locator('#controlsPanel').is_visible()
    page.locator('#reduceEffects').check();assert page.evaluate('reduceEffects') is True
    page.locator('#showTutorial').uncheck();assert page.evaluate('showTutorialHints') is False
    page.locator('#closeBindings').click();assert page.locator('#controlsPanel').is_hidden()
    # Real click on New Deployment, then keyboard dialogue advance and pause.
    click_canvas(110,175);assert page.evaluate('state')=='dialogue'
    for _ in range(3):page.keyboard.press('Enter');page.wait_for_timeout(40)
    assert page.evaluate('state')=='playing'
    page.keyboard.press('Escape');page.wait_for_function('state==="pause"',timeout=3000)
    page.screenshot(path=str(root/'SCREENSHOT_PHASE3_BROWSER_PAUSE.png'))
    # Pause menu is keyboard navigable (Down selects the map); map freezes simulation.
    page.keyboard.press('ArrowDown');page.wait_for_timeout(40);page.keyboard.press('Enter')
    page.wait_for_function('mapOpen===true',timeout=3000)
    before=page.evaluate('worldTime');page.wait_for_timeout(140)
    assert abs(page.evaluate('worldTime')-before)<.001
    page.keyboard.press('Escape');page.wait_for_function('mapOpen===false',timeout=3000)
    assert not errors,f'desktop browser errors: {errors}'
    print('Desktop PASS: title mouse menu, options persistence, pause keyboard menu, frozen map, no page errors')

    touch=browser.new_context(viewport={'width':844,'height':390},screen={'width':844,'height':390},is_mobile=True,has_touch=True,device_scale_factor=1)
    touch.route('https://game.test/**',route_local)
    t=touch.new_page();mobile_errors=[];t.on('pageerror',lambda e:mobile_errors.append(str(e)))
    t.set_content(html,wait_until='domcontentloaded');t.wait_for_timeout(1100)
    assert t.evaluate('state')=='title'
    assert 'bel-touch-active' in t.locator('body').get_attribute('class'), 'mobile touch controls not activated'
    t.screenshot(path=str(root/'SCREENSHOT_PHASE3_BROWSER_IPAD_MENU.png'))
    head=t.locator('header').bounding_box();shell=t.locator('#shell').bounding_box()
    assert head and shell
    assert shell['y']+shell['height']<=391, f'game clipped by mobile viewport: {shell}'
    assert t.locator('#tcAdvance').is_visible(),'touch deployment button visible'
    t.locator('#tcAdvance').tap();t.wait_for_timeout(60)
    assert t.evaluate('state')=='dialogue','touch deploy navigates title'
    for _ in range(3):
        t.locator('#tcAdvance').tap();t.wait_for_timeout(50)
    assert t.evaluate('state')=='playing','touch dialogue advancement'
    t.screenshot(path=str(root/'SCREENSHOT_PHASE3_BROWSER_IPAD_GAMEPLAY.png'))
    # Ability to hold a dpad and jump simultaneously retained; DOM touch layout stays in viewport.
    assert t.locator('#tcDpad').is_visible() and t.locator('#tcActions').is_visible()
    assert not mobile_errors,f'mobile browser errors: {mobile_errors}'
    print('Touch PASS: phone landscape layout, deploy, dialogue, buttons, no page errors')
    browser.close()
