"""Real Chromium phase-4 smoke test: effects settings, desktop and iPad landscape."""
from pathlib import Path
from urllib.parse import urlparse,unquote
from playwright.sync_api import sync_playwright
import mimetypes
root=Path(__file__).resolve().parents[1]
html=(root/'browser-demo/index.html').read_text().replace('<head>','<head><base href="https://game.test/browser-demo/">',1)

def route_local(route):
    file=(root/unquote(urlparse(route.request.url).path).lstrip('/')).resolve()
    if file.is_file() and file.is_relative_to(root):
        route.fulfill(status=200,body=file.read_bytes(),content_type=mimetypes.guess_type(file)[0] or 'application/octet-stream')
    else:route.fulfill(status=404,body='missing file')

with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required'])
    context=browser.new_context(viewport={'width':1280,'height':840})
    context.route('https://game.test/**',route_local)
    page=context.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html,wait_until='domcontentloaded');page.wait_for_timeout(1500)
    assert page.evaluate('state')=='title'
    page.locator('#controlsToggle').click()
    assert page.locator('#lowAtmosphere').is_visible()
    page.locator('#lowAtmosphere').check()
    assert page.evaluate('lowAtmosphere') is True
    page.locator('#reduceEffects').check()
    assert page.evaluate('reduceEffects') is True
    page.locator('#closeBindings').click()
    # Exercise all eight runtime scenes with quality preference set.
    for sector in ['main','sublevel','archive','blacksite','reactor','transit','pumpworks','refuge']:
        page.evaluate("""name=>{reset();state='playing';window.roomDone=name;eval('sector='+JSON.stringify(name));
                  camera=0;enem=[];p.x=330;p.y=228;tutorial=0;clock=3.7;render()}""",sector)
        assert page.evaluate('state')=='playing'
        if sector=='pumpworks':page.screenshot(path=str(root/'SCREENSHOT_PHASE4_BROWSER_PUMPWORKS.png'))
    assert not errors,errors
    print('Desktop browser PASS: saved atmosphere setting, reduced effects, eight scenes, no page errors')
    tcontext=browser.new_context(viewport={'width':844,'height':390},screen={'width':844,'height':390},is_mobile=True,has_touch=True,device_scale_factor=1)
    tcontext.route('https://game.test/**',route_local)
    touch=tcontext.new_page();mobile_errors=[];touch.on('pageerror',lambda e:mobile_errors.append(str(e)))
    touch.set_content(html,wait_until='domcontentloaded');touch.wait_for_timeout(1300)
    assert touch.evaluate('state')=='title'
    assert touch.locator('#tcAdvance').is_visible()
    touch.locator('#tcAdvance').tap();touch.wait_for_timeout(70)
    assert touch.evaluate('state')=='dialogue'
    for _ in range(3):touch.locator('#tcAdvance').tap();touch.wait_for_timeout(60)
    assert touch.evaluate('state')=='playing'
    touch.evaluate("""() => {sector='refuge';p.x=330;p.y=228;camera=0;enem=[];tutorial=0;clock=4.1;render()}""")
    touch.screenshot(path=str(root/'SCREENSHOT_PHASE4_BROWSER_IPAD.png'))
    head=touch.locator('header').bounding_box();shell=touch.locator('#shell').bounding_box()
    assert head and shell and shell['y']+shell['height']<=391, f'game clipped: {shell}'
    assert touch.locator('#tcDpad').is_visible() and touch.locator('#tcActions').is_visible()
    assert not mobile_errors,mobile_errors
    print('iPad-size touch emulation PASS: deployment and dialogue, 8-area atmosphere renderer, viewport bounds, no page errors')
    browser.close()
