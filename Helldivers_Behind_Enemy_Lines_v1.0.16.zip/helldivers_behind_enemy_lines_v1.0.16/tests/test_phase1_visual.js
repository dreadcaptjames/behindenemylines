// v1.0.9 visual hierarchy test — render all eight actual sectors at 2× scale.
// This exercises real Canvas composition, not screenshots made from concept art.
const fs=require('fs'),vm=require('vm'),path=require('path');
const {Canvas,Image}=require('skia-canvas');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'browser-demo/index.html'),'utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const canvas=new Canvas(960,540);canvas.getBoundingClientRect=()=>({left:0,top:0,width:480,height:270});canvas.focus=()=>{};canvas.addEventListener=()=>{};
const el=()=>({hidden:false,innerHTML:'',append(){},setAttribute(){},addEventListener(){},focus(){},onclick:null});
const els={game:canvas,controlsPanel:el()};els.controlsPanel.hidden=true;
const document={getElementById:id=>els[id]||(els[id]=el()),createElement:()=>el()};
class LocalImg extends Image{set src(url){super.src=path.resolve(root,'browser-demo',url)}get naturalWidth(){return this.width}get naturalHeight(){return this.height}}
class Audio{constructor(){this.volume=0}cloneNode(){return this}play(){return Promise.resolve()}}
const store=new Map(),localStorage={getItem:key=>store.get(key)||null,setItem:(key,value)=>store.set(key,value),removeItem:key=>store.delete(key)};
const ctx=vm.createContext({console,Math,Set,Map,Audio,Image:LocalImg,document,window:{addEventListener(){}},navigator:{getGamepads:()=>[]},localStorage,requestAnimationFrame:()=>{},performance:{now:()=>0},Date});
vm.runInContext(js,ctx,{filename:'browser-demo/index.html'});
const run=s=>vm.runInContext(s,ctx),assert=(condition,msg)=>{if(!condition)throw Error(msg)};
const pixel=(x,y)=>Array.from(canvas.getContext('2d').getImageData(Math.round(x*2),Math.round(y*2),1,1).data).slice(0,3);
const channelDiff=(a,b)=>a.reduce((sum,v,i)=>sum+Math.abs(v-b[i]),0);
(async()=>{
 await new Promise(r=>setTimeout(r,950));
 assert(run('assets.filter(x=>art[x]?.naturalWidth).length===257'),'all source art loaded');
 assert(run('Object.keys(VISUAL_STYLES).length===8'),'8 themed palettes present');
 assert(run('typeof gameplayDepthMatte')==='function','play plane depth matte');
 assert(run('typeof interactionSignals')==='function','world-space interaction signals');
 assert(run('typeof foreground')==='undefined','no old occlusion pass');
 for(const sector of ['main','sublevel','archive','blacksite','reactor','transit','pumpworks','refuge']){
   run(`reset();state='playing';sector='${sector}';camera=0;enem=[];p.x=320;p.y=228;mapOpen=false;clock=1.8;notifyCd=0;tutorial=0;render()`);
   const rim=run('visualStyle().rim');
   const [r,g,b]=[1,3,5].map(n=>parseInt(rim.slice(n,n+2),16));
   const top=pixel(35,228),above=pixel(35,220);
   assert(channelDiff(top,[r,g,b])<=6,`consistent play-surface rim ${sector}: ${top} vs ${rim}`);
   assert(channelDiff(top,above)>65,`separated floor and backdrop ${sector}`);
   const out=`VISUAL_PHASE1_${sector.toUpperCase()}.png`;
   await fs.promises.writeFile(path.join(root,out),await canvas.toBuffer('png'));
   console.log(`${sector.padEnd(10)} edge #${rim.slice(1)} floor/background contrast ${channelDiff(top,above)}`);
 }
 // Ensure objective-state mapping changes live in the existing story state.
 run("sector='pumpworks';pumpA=false;pumpB=false;camera=0;");
 assert(run('visualStyle().danger')==='#ffbf54','pump hazard has dedicated amber danger code');
 assert(run('!pumpA && !pumpB'),'pump objective gates unchanged');
 assert(run('roomSolids().length===PUMP_SOLIDS.length'),'collision maps unchanged');
 console.log('PASS: v1.0.9 visual hierarchy, 8 palettes, 8 scene renders, gap/ledge distinction, original collision geometry');
})().catch(err=>{console.error(err);process.exitCode=1});
