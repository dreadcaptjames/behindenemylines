"""Real Chromium test: mouse aim stays independent while running, jumping, and shooting."""
from pathlib import Path
from urllib.parse import urlparse, unquote
from playwright.sync_api import sync_playwright
import mimetypes,math
root=Path(__file__).resolve().parents[1]
html=(root/'browser-demo/index.html').read_text().replace('<head>','<head><base href="https://game.test/browser-demo/">',1)
def serve(route):
    f=(root/unquote(urlparse(route.request.url).path).lstrip('/')).resolve()
    if f.is_file() and f.is_relative_to(root):
        route.fulfill(status=200,body=f.read_bytes(),content_type=mimetypes.guess_type(f)[0] or 'application/octet-stream')
    else:route.fulfill(status=404,body='missing')
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required'])
    context=browser.new_context(viewport={'width':1280,'height':830})
    context.route('https://game.test/**',serve)
    page=context.new_page();errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
    page.set_content(html,wait_until='domcontentloaded')
    page.wait_for_timeout(700)
    page.evaluate('reset();state="playing";enem=[];p.x=320;p.y=228;p.ground=true;p.hp=p.maxHp;p.hurt=12;bullets=[];')
    box=page.locator('#game').bounding_box(); assert box
    def move_game(x,y):page.mouse.move(box['x']+x/480*box['width'],box['y']+y/270*box['height'],steps=4)
    move_game(430,65)
    page.wait_for_timeout(90)
    assert page.evaluate('mouseAimHover && cursorAiming() && !mouseDown'), 'mouse hover must aim even before clicking'
    page.keyboard.down('d')
    before=page.evaluate('p.x')
    page.wait_for_timeout(160)
    assert page.evaluate('p.x')>before+10, 'D movement stops when hovering the mouse'
    move_game(405,45)
    page.wait_for_timeout(55)
    up=page.evaluate('({theta:rifleGeometry().theta,face:p.face,mouseDown,hover:mouseAimHover})')
    assert up['theta'] < -.30 and not up['mouseDown'],f'upward mouse aim while holding D: {up}'
    move_game(410,248)
    page.wait_for_timeout(60)
    down=page.evaluate('({theta:rifleGeometry().theta,face:p.face,mouseDown,hover:mouseAimHover})')
    assert down['theta']>.20 and down['face']==1, f'cursor aim fails while holding movement: {down}'
    # Hold movement and Space while moving mouse up-left: cursor determines aim, not movement facing.
    page.keyboard.down('Space')
    page.wait_for_timeout(70)
    move_game(60,42)
    page.wait_for_timeout(60)
    airborne=page.evaluate('({ground:p.ground,vy:p.vy,face:rifleGeometry().facing,ux:rifleGeometry().ux,uy:rifleGeometry().uy,pX:p.x})')
    assert not airborne['ground'] and airborne['vy']<0, f'jump failed with mouse hover: {airborne}'
    assert airborne['face']==-1 and airborne['ux']<-.35 and airborne['uy']<0,f'aim did not track cursor while jumping: {airborne}'
    # Fire with F while the right-hand movement key and jump remain held.
    page.evaluate('p.fire=0;p.reload=0;p.ammo=18;bullets=[]')
    page.keyboard.down('f')
    page.wait_for_timeout(45)
    fired=page.evaluate('({count:bullets.filter(x=>x.team===0).length,shots:bullets.filter(x=>x.team===0).map(x=>({vx:x.vx,vy:x.vy})),moving:keys.has("d"),jumpHeld:keys.has(" "),aiming:cursorAiming()})')
    assert fired['count']>=1 and fired['moving'] and fired['jumpHeld'] and fired['aiming'],f'move+jump+aim+shoot failed: {fired}'
    assert fired['shots'][0]['vx']<0 and fired['shots'][0]['vy']<0,f'F shot did not follow hovered cursor: {fired}'
    page.keyboard.up('f');page.keyboard.up('Space');page.keyboard.up('d')
    # Primary mouse button fires while opposite-direction movement key is held.
    page.evaluate('p.fire=0;p.reload=0;p.ammo=18;bullets=[]')
    page.keyboard.down('a')
    move_game(432,58)
    page.mouse.down();page.wait_for_timeout(55)
    click=page.evaluate('({firing:bullets.some(b=>b.team===0),held:keys.has("a"),vx:bullets.find(b=>b.team===0)?.vx,aiming:cursorAiming()})')
    assert click['firing'] and click['held'] and click['vx']>0 and click['aiming'],f'mouse click during A movement: {click}'
    page.mouse.up();page.keyboard.up('a')
    assert page.evaluate('!mouseDown && cursorAiming()'), 'releasing mouse should preserve hover aim'
    # Gamepad aim overrides passive mouse hover, and simulated touch aim still works.
    assert page.evaluate('padAim={x:-1,y:0};rifleGeometry().facing')==-1
    assert page.evaluate('padAim=null;mouseAimHover=false;mouseDown=true;mouseSeen=clock+4;mouseX=420;mouseY=115;rifleGeometry().facing')==1
    page.evaluate('mouseDown=false')
    move_game(540,280) # exit canvas so keyboard fallback works
    page.wait_for_timeout(60)
    assert not page.evaluate('mouseAimHover'), 'leaving canvas should clear passive hover aim'
    assert not errs,f'Browser JS errors: {errs}'
    print('PASS: hover-aim and independent D/A movement, simultaneous Space jump and F fire, mouse click, pad/touch priority; no JS errors')
    browser.close()
