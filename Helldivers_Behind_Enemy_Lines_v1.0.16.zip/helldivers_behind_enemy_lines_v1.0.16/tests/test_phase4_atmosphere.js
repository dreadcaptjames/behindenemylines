// v1.0.12 atmosphere integration test: real renderer, all eight areas, two animation
// times, powered/unpowered response, menu persistence and collision-safe layering.
'use strict';
const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const {Canvas,Image}=require('skia-canvas');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'browser-demo/index.html'),'utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const canvas=new Canvas(960,540);canvas.getBoundingClientRect=()=>({left:0,top:0,width:480,height:270});canvas.focus=()=>{};canvas.addEventListener=()=>{};
const el=()=>({hidden:false,innerHTML:'',checked:false,append(){},setAttribute(){},addEventListener(){},focus(){},onclick:null});
const els={game:canvas,controlsPanel:el()};els.controlsPanel.hidden=true;
const document={getElementById:id=>els[id]||(els[id]=el()),createElement:()=>el()};
class LocalImg extends Image{set src(url){super.src=path.resolve(root,'browser-demo',url)}get naturalWidth(){return this.width}get naturalHeight(){return this.height}}
class Audio{constructor(){this.volume=0}cloneNode(){return this}play(){return Promise.resolve()}}
const store=new Map(),localStorage={getItem:key=>store.get(key)||null,setItem:(key,value)=>store.set(key,value),removeItem:key=>store.delete(key)};
const ctx=vm.createContext({console,Math,Set,Map,Audio,Image:LocalImg,document,window:{addEventListener(){}},navigator:{getGamepads:()=>[]},localStorage,requestAnimationFrame:()=>{},performance:{now:()=>0},Date});
vm.runInContext(js,ctx,{filename:'browser-demo/index.html'});
const run=s=>vm.runInContext(s,ctx);
function rgb(x,y){return Array.from(canvas.getContext('2d').getImageData(x*2,y*2,1,1).data).slice(0,3)}
function diff(a,b){return a.reduce((s,v,i)=>s+Math.abs(v-b[i]),0)}
(async()=>{
 await new Promise(r=>setTimeout(r,950));
 assert.strictEqual(run('assets.filter(x=>art[x]?.naturalWidth).length'),257);
 assert.strictEqual(run('Object.keys(PHASE4_ENV).length'),8);
 assert.strictEqual(run("typeof phase4EnvironmentalStory==='function' && typeof phase4FansAndDrives==='function' && typeof phase4AirAndLights==='function'"),true);
 const sectors=['main','sublevel','archive','blacksite','reactor','transit','pumpworks','refuge'];
 let changedSectors=0;
 for(const sector of sectors){
  const pose=`reset();state='playing';sector='${sector}';camera=0;enem=[];p.x=330;p.y=228;notifyCd=0;tutorial=0;mapOpen=false;lowAtmosphere=false;reduceEffects=false;`;
  run(pose+`clock=.6;render()`);
  const before=canvas.getContext('2d').getImageData(0,100,960,290).data;
  const top1=rgb(35,228);await fs.promises.writeFile(path.join(root,`PHASE4_${sector.toUpperCase()}.png`),await canvas.toBuffer('png'));
  run('clock=4.2;render()');
  const after=canvas.getContext('2d').getImageData(0,100,960,290).data;
  let diffCount=0;
  // Sparse sample over scenic area; only scene pixels should change.
  for(let offset=0;offset<before.length;offset+=32){if(before[offset]!==after[offset]||before[offset+1]!==after[offset+1]||before[offset+2]!==after[offset+2])diffCount++}
  assert(diffCount>20,`${sector}: expected visibly animated environment, got ${diffCount} changes`);
  changedSectors++;
  const top2=rgb(35,228);
  assert(diff(top1,top2)<=2,`${sector}: walkable surface rim should not shimmer`);
  assert(run('roomSolids().length')>=3,`${sector}: no collisions`);
  console.log(sector.padEnd(10),'animated sampled pixels',diffCount);
 }
 assert.strictEqual(changedSectors,8);
 // The main scene geometry remains behind the player and cannot paint over
 // the platform edge. Environment reactions are keyed to actual objectives.
 const flags={main:'comms',sublevel:'breach',archive:'armor',blacksite:'switchA=true;switchB',reactor:'reactorOff',transit:'freightA=true;freightB',pumpworks:'pumpA=true;pumpB',refuge:'shelterSignal'};
 for(const sec of sectors){run(`reset();sector='${sec}';`);assert.strictEqual(run('environmentPowered()'),false,`unpowered ${sec}`);run(`${flags[sec]}=true`);assert.strictEqual(run('environmentPowered()'),true,`powered ${sec}`)}
 run("lowAtmosphereInput.checked=true;lowAtmosphereInput.onchange()");
 assert.strictEqual(store.get('bel_atmosphere_low'),'on');assert.strictEqual(run('lowAtmosphere'),true);
 run("reduceEffectsInput.checked=true;reduceEffectsInput.onchange()");
 assert.strictEqual(run('reduceEffects'),true);
 // Both quality preferences are respected without mutating story state.
 run("reset();state='playing';sector='pumpworks';clock=6.5;tutorial=0;lowAtmosphere=true;reduceEffects=true;render()");
 assert.strictEqual(run('pumpA'),false);
 console.log('PASS: Phase 4 all eight animated rooms, stateful lighting, world-depth order, static platform rims, quality settings and existing story flags');
})().catch(err=>{console.error(err);process.exitCode=1});
