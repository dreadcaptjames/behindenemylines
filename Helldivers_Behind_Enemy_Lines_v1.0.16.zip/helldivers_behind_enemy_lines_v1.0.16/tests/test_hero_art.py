"""Regression checks for painted character animation and removed contact shadow."""
from pathlib import Path
from PIL import Image, ImageChops
ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'art'
files=[]
for anim,count in dict(idle=4,run=8,jump=4,dive=4,fire=3,reload=3,jet=4,land=4,hurt=3).items():
    for i in range(count):
        for direction in ('r','l'):
            path=ART/f'hero_{anim}_{i}_{direction}.png'
            assert path.is_file(), path
            im=Image.open(path).convert('RGBA')
            assert im.size==(84,72),str(path)
            files.append(im)
            assert (ART/f'hero_body_{anim}_{i}_{direction}.png').is_file()
# New run frames must differ in pose, not just clock-driven cutouts.
right=[Image.open(ART/f'hero_run_{n}_r.png').convert('RGBA') for n in range(8)]
assert all(ImageChops.difference(right[n],right[(n+1)%8]).getbbox() for n in range(8))
assert len(set(im.tobytes() for im in right))==8
# Reference shadow was a 50+ pixel band at the bottom; only separated boot regions may remain.
for im in files:
    for y in (69,70):
        colored=[x for x in range(84) if im.getpixel((x,y))[3]>8]
        assert len(colored)<=36, f'Baked floor shadow survives: y={y}, pixels={len(colored)}'
        longest=max((len(run) for run in ''.join('1' if x in colored else '0' for x in range(84)).split('0')),default=0)
        assert longest<=18, f'Ground-shadow band survives: y={y}, span={longest}'
# Runtime rendering must not add a dark oval contact shadow or reassemble disjoint body slabs.
html=(ROOT/'browser-demo/index.html').read_text()
player=html.split('function player(){',1)[1].split('function drawBullets(){',1)[0]
assert 'drawSpritePart' not in player
assert '.ellipse(' not in player
assert 'heroPose()' in player and 'Math.floor((p.stride||0)*8)%8' in html
assert 'hero_body_${pose.anim}_${pose.frame}' in player
assert 'hero_gun_${p.face>0?' in player
assert 'rifleGeometry()' in player
assert 'p.stride=((p.stride||0)+Math.abs(p.x-oldX)/90)%1' in html
print('PASS: expanded painted poses, four-phase jump/dive, eight gait frames, independent rifle, no ground shadow')
