// UX/UI regression: title, pause, map, destructive confirmation, progress and preferences.
const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),vm=require('vm');
const {Canvas,Image}=require('skia-canvas');
const root=path.resolve(__dirname,'..'),html=fs.readFileSync(path.join(root,'browser-demo/index.html'),'utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const screen=new Canvas(960,540);screen.addEventListener=()=>{};screen.focus=()=>{};screen.getBoundingClientRect=()=>({left:0,top:0,width:480,height:270});
const element=()=>({hidden:true,textContent:'',checked:false,addEventListener(){},append(){},setAttribute(){},focus(){}});
const elems={game:screen,controlsPanel:element()};
const document={body:{classList:{contains:()=>false}},getElementById:id=>elems[id]||(elems[id]=element()),createElement:element};
class LocalImage extends Image{set src(u){super.src=path.resolve(root,'browser-demo',u)}get naturalWidth(){return this.width}}
class Audio{constructor(){this.volume=0;this.loop=false}play(){return Promise.resolve()}cloneNode(){return this}}
const store=new Map(),localStorage={getItem:k=>store.get(k)||null,setItem:(k,v)=>store.set(k,v),removeItem:k=>store.delete(k)};
const ctx=vm.createContext({console,Math,Map,Set,Image:LocalImage,Audio,document,window:{addEventListener(){}},navigator:{getGamepads:()=>[]},localStorage,requestAnimationFrame(){},Date});
vm.runInContext(js,ctx,{filename:'browser-demo/index.html'});const run=s=>vm.runInContext(s,ctx);
const snap=async name=>{run('render()');await fs.promises.writeFile(path.join(root,name),await screen.toBuffer('png'))};
(async()=>{
 await new Promise(r=>setTimeout(r,850));
 assert.equal(run('menuItems().length'),2,'new game and options shown without save');
 assert.equal(run('menuPickAt(35,176).action'),'new','first title button hitbox');
 assert.equal(run('menuPickAt(35,202).action'),'options','second title button hitbox');
 run('menuFocus=0;menuTouched=false;');await snap('SCREENSHOT_PHASE3_TITLE.png');
 // Save available => resume appears and new deployment requires explicit confirmation.
 run('saveProgress();state="title"');
 assert.equal(run('menuItems().length'),3,'resume shown with checkpoint');
 assert.equal(run('menuPickAt(36,203).action'),'continue');
 run('menuAction("new")');
 assert.equal(run('confirmNewMission'),true,'new mission confirmation appears');
 assert.equal(run('menuItems()[0].action'),'cancel-new');
 assert.equal(run('hasSave()'),true,'checkpoint not deleted before confirmation');
 await snap('SCREENSHOT_PHASE3_CONFIRM.png');
 run('menuAction("cancel-new")');assert.equal(run('hasSave()'),true,'cancel preserves checkpoint');
 run('menuAction("continue")');assert.equal(run('state'),'playing');
 // Mission tracker progress driven by actual flags.
 run('sector="transit";visited.transit=true;freightA=true;freightB=false;enem=[];tutorial=0;');
 assert.equal(run('missionObjective().count'),1);assert.equal(run('missionObjective().total'),2);
 await snap('SCREENSHOT_PHASE3_HUD.png');
 run('pressed.add("escape");update(.016)');assert.equal(run('state'),'pause');
 assert.equal(run('menuItems().length'),4,'pause actions');
 await snap('SCREENSHOT_PHASE3_PAUSE.png');
 run('menuFocus=1;pressed.add("enter");update(.016)');
 assert.equal(run('state'),'playing');assert.equal(run('mapOpen'),true,'pause menu launches tactical map');
 const worldBefore=run('worldTime'),xBefore=run('p.x');
 run('keys.add("d");update(.1)');
 assert.equal(run('worldTime'),worldBefore,'map freezes combat/world time');
 assert.equal(run('p.x'),xBefore,'map blocks accidental movement');
 await snap('SCREENSHOT_PHASE3_MAP.png');
 run('pressed.add("m");update(.016)');assert.equal(run('mapOpen'),false);
 run('keys.delete("d")');
 run('message("CHECKPOINT REACHED",1)');assert.equal(elems.gameStatus.textContent,'CHECKPOINT REACHED','accessible live status');
 // State flags use the persisted option values.
 assert.equal(run('reduceEffects'),false);elems.reduceEffects.checked=true;elems.reduceEffects.onchange();
 assert.equal(store.get('bel_reduce_effects'),'on');assert.equal(run('reduceEffects'),true);
 elems.showTutorial.checked=false;elems.showTutorial.onchange();assert.equal(store.get('bel_tutorial_hints'),'off');
 run('menuAction("title")');assert.equal(run('state'),'title');assert.equal(run('hasSave()'),true,'return to title writes checkpoint');
 console.log('PASS: Phase 3 main menu, save warning, settings preferences, pause, safe map, progress HUD and status narration');
})().catch(e=>{console.error(e);process.exitCode=1});
