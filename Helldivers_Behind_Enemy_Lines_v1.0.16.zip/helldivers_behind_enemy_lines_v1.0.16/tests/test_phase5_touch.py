"""Phase 5 real-browser mobile UX coverage and reference screenshots."""
from pathlib import Path
from urllib.parse import urlparse,unquote
import mimetypes
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from threading import Thread
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
html=(root/'browser-demo/index.html').read_text().replace('<head>','''<head><base href="https://game.test/browser-demo/">
<script>window.__fakeStorage={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>Object.hasOwn(window.__fakeStorage,k)?window.__fakeStorage[k]:null,setItem:(k,v)=>{window.__fakeStorage[k]=String(v)},removeItem:k=>{delete window.__fakeStorage[k]}}})</script>''',1)
def route_local(route):
    path=unquote(urlparse(route.request.url).path).lstrip('/')
    file=(root/path).resolve()
    if file.is_file() and file.is_relative_to(root):
        route.fulfill(status=200,body=file.read_bytes(),content_type=mimetypes.guess_type(file)[0] or 'application/octet-stream')
    else: route.fulfill(status=404,body='missing file')
with sync_playwright() as playwright:
    browser=playwright.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage','--autoplay-policy=no-user-gesture-required'])
    context=browser.new_context(viewport={'width':1024,'height':768},is_mobile=True,has_touch=True,device_scale_factor=1)

    context.route('https://game.test/**',route_local)
    page=context.new_page();errors=[]
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.set_content(html,wait_until='domcontentloaded')
    page.wait_for_timeout(900)
    assert page.evaluate('window.belMobilePowerSave') is False
    page.locator('#tcAdvance').tap()
    for _ in range(3):page.locator('#tcAdvance').tap();page.wait_for_timeout(45)
    assert page.evaluate('state')=='playing'
    page.wait_for_timeout(220)
    assert page.locator('#tcSettingsBtn').is_visible()
    page.screenshot(path=str(root/'SCREENSHOT_PHASE5_IPAD_DEFAULT.png'))
    default_dpad=page.locator('#tcDpad').bounding_box()
    default_aim=page.locator('#tcAim').bounding_box()
    assert default_dpad['x']<default_aim['x']
    assert default_dpad['width']>=76 and default_aim['height']>=76
    # Open controls from the touch toolbar itself, not simulated JS.
    page.locator('#tcSettingsBtn').tap()
    assert page.locator('#controlsPanel').is_visible()
    assert page.locator('#belMobileSettings').is_visible()
    page.locator('#tcHand').select_option('left')
    page.locator('#tcSize').select_option('115')
    page.locator('#tcOpacity').select_option('65')
    page.locator('#tcHaptics').check()
    page.locator('#tcSavePower').check()
    page.locator('#tcMusicLevel').evaluate("el=>{el.value='35';el.dispatchEvent(new Event('input',{bubbles:true}))}")
    assert abs(page.evaluate('musicMaster')-.35)<.0001
    prefs=page.evaluate('JSON.parse(localStorage.getItem("bel_mobile_layout_v1"))')
    assert prefs=={'hand':'left','size':115,'opacity':65,'haptics':True,'savePower':True},prefs
    assert page.evaluate('window.belMobilePowerSave') is True
    assert 'bel-touch-lefty' in page.locator('body').get_attribute('class')
    page.screenshot(path=str(root/'SCREENSHOT_PHASE5_SETTINGS.png'))
    page.locator('#tcSettingsDone').tap()
    page.wait_for_timeout(240)
    left_dpad=page.locator('#tcDpad').bounding_box()
    left_aim=page.locator('#tcAim').bounding_box()
    assert left_dpad['x']>left_aim['x'],(left_dpad,left_aim)
    assert left_dpad['width']>default_dpad['width']*1.10
    assert float(page.evaluate('getComputedStyle(document.querySelector("#tcAim")).opacity'))==.65
    shell=page.locator('#shell').bounding_box()
    assert shell['y']>=0 and shell['y']+shell['height']<769,shell
    page.screenshot(path=str(root/'SCREENSHOT_PHASE5_IPAD_LEFTY.png'))
    # A single held pointer glides right to left on the pad without lifting.
    page.evaluate('p.x=350;p.y=228;p.ground=true;p.vx=0')
    r=left_dpad;cx=r['x']+r['width']/2;cy=r['y']+r['height']/2
    right=page.locator('#tcDpad [data-key="arrowright"]')
    right.dispatch_event('pointerdown',{'pointerId':412,'button':0,'clientX':cx+r['width']*.34,'clientY':cy})
    page.wait_for_timeout(260)
    moved_right=page.evaluate('p.x')
    assert moved_right>350+5,moved_right
    right.dispatch_event('pointermove',{'pointerId':412,'button':0,'clientX':cx-r['width']*.34,'clientY':cy})
    page.wait_for_timeout(300)
    moved_left=page.evaluate('p.x')
    assert moved_left<moved_right-5,(moved_right,moved_left)
    right.dispatch_event('pointerup',{'pointerId':412,'button':0})
    page.wait_for_timeout(80)
    assert page.evaluate('!keys.has("arrowleft")&&!keys.has("arrowright")')
    # Reset settings from within options, then verify restoration.
    page.locator('#tcSettingsBtn').tap()
    page.locator('#tcResetMobile').tap()
    reset=page.evaluate('JSON.parse(localStorage.getItem("bel_mobile_layout_v1"))')
    assert reset=={'hand':'right','size':100,'opacity':90,'haptics':False,'savePower':False},reset
    assert page.evaluate('window.belMobilePowerSave') is False
    page.locator('#closeBindings').tap()
    # Local persisted preferences load on a new page instance.
    page.reload() if False else None
    assert not errors,errors
    print('PASS: landscape iPad touch UX, settings, persistence, mirroring, sizing, opacity, battery saver, drag-to-steer, reset, no errors')
    # Compact phone viewport still fits controls, and orientation advisory appears in portrait.
    phone=browser.new_context(viewport={'width':844,'height':390},is_mobile=True,has_touch=True,device_scale_factor=1)

    phone.route('https://game.test/**',route_local)
    phone_page=phone.new_page();phone_page.set_content(html,wait_until='domcontentloaded');phone_page.wait_for_timeout(500)
    phone_shell=phone_page.locator('#shell').bounding_box()
    assert phone_shell['y']+phone_shell['height']<=391,phone_shell
    assert phone_page.locator('#tcAdvance').is_visible()
    phone_page.screenshot(path=str(root/'SCREENSHOT_PHASE5_PHONE_LANDSCAPE.png'))
    phone_page.locator('#tcAdvance').tap()
    for _ in range(3):phone_page.locator('#tcAdvance').tap();phone_page.wait_for_timeout(45)
    assert phone_page.evaluate('state')=='playing'
    phone_page.wait_for_timeout(240)
    phone_page.screenshot(path=str(root/'SCREENSHOT_PHASE5_PHONE_GAMEPLAY.png'))
    print('PASS: compact phone landscape shell fits viewport')
    phone.close();context.close();browser.close()

