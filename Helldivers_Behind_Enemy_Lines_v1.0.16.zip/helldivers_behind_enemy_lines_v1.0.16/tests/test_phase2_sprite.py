"""Asset-level checks for Phase 2 character polish."""
from pathlib import Path
from PIL import Image,ImageChops
ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'art'
NEAREST=Image.Resampling.NEAREST

def sprite(anim,i,direction='r'):
    im=Image.open(ART/f'hero_body_{anim}_{i}_{direction}.png').convert('RGBA')
    assert im.size==(84,72)
    return im

for anim,count in {'idle':4,'run':8,'fire':3,'jump':4,'jet':4,'land':4,'reload':3,'hurt':3,'dive':4}.items():
    for i in range(count):
        right=sprite(anim,i)
        left=sprite(anim,i,'l')
        assert right.transpose(Image.Transpose.FLIP_LEFT_RIGHT).tobytes()==left.tobytes(),f'{anim} {i} failed mirror fidelity'
        assert right.getbbox(),f'{anim} {i} blank'
        # Godot's complete pose is present; browser carries a separate rifle.
        assert (ART/f'hero_{anim}_{i}_r.png').exists()
        assert (ART/f'hero_{anim}_{i}_l.png').exists()
run=[sprite('run',i) for i in range(8)]
assert len({im.tobytes() for im in run})==8,'run cycle repeats frames'
assert all(ImageChops.difference(run[i],run[(i+1)%8]).getbbox() for i in range(8)), 'adjacent gait frame identical'
jumps=[sprite('jump',i) for i in range(4)]
assert len({im.tobytes() for im in jumps})==4,'airborne states collapsed'
dives=[sprite('dive',i) for i in range(4)]
assert len({im.tobytes() for im in dives})==4,'dive phases collapsed'
for i in (1,2):
    im=dives[i]
    x0,y0,x1,y1=im.getbbox()
    assert x1-x0>=69 and y1-y0<=50,f'phase {i} not prone: {(x0,y0,x1,y1)}'
    # Owner's amber helmet should stay forward and ABOVE the torso, not
    # point vertically at the ground as it did in the old rotation-only dive.
    visor=[(x,y) for y in range(14,38) for x in range(59,80)
        if (lambda r,g,b,a:a>200 and r>200 and g>135 and b<150)(*im.getpixel((x,y)))]
    assert len(visor)>=6,f'phase {i} lost forward amber helmet'
    assert max(x for x,y in visor)>=66,f'phase {i} visor does not face forward'
# Pose borders have no old 50-pixel-wide elliptical floor shadow.
for im in run+jumps+dives:
    for y in (69,70):
        line=[x for x in range(84) if im.getpixel((x,y))[3]>8]
        assert len(line)<36, f'baked shadow y={y}, count={len(line)}'
print('PASS: 9 complete animations, 8 unique running poses, 4 distinct jump and dive poses, correctly oriented helmet, mirrored frames, no shadow')
