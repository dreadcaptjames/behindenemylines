// Phase 2 actual Canvas render / state machine integration test.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const {Canvas,Image}=require('skia-canvas');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'browser-demo/index.html'),'utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const screen=new Canvas(960,540);screen.focus=()=>{};screen.addEventListener=()=>{};
screen.getBoundingClientRect=()=>({left:0,top:0,width:480,height:270});
const el=()=>({hidden:true,addEventListener(){},append(){},setAttribute(){},focus(){}});
const elems={game:screen,controlsPanel:el()};
const document={body:{classList:{contains(){return false}}},getElementById:id=>elems[id]||(elems[id]=el()),createElement:el};
class LocalImage extends Image{set src(u){super.src=path.resolve(root,'browser-demo',u)}get naturalWidth(){return this.width}}
class Audio{constructor(){this.volume=0}play(){return Promise.resolve()}cloneNode(){return this}}
const storage=new Map(),localStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
const ctx=vm.createContext({console,Math,Map,Set,Image:LocalImage,Audio,document,window:{addEventListener(){}},navigator:{getGamepads:()=>[]},localStorage,requestAnimationFrame(){},Date});
vm.runInContext(js,ctx);
const run=s=>vm.runInContext(s,ctx);
const snapshot=async(file)=>{run('render()');await fs.promises.writeFile(path.join(root,file),await screen.toBuffer('png'))};
(async()=>{
 await new Promise(r=>setTimeout(r,1100));
 assert.strictEqual(run('assets.filter(a=>art[a]?.naturalWidth).length'),run('assets.length'));
 run("reset();state='playing';tutorial=0;notifyCd=0;camera=45;sector='main';enem=[];p.x=230;p.y=228;p.ground=true;clock=5;");
 const pose=()=>run('heroPose()');
 run('p.vx=143;p.stride=0;');assert.strictEqual(pose().anim,'run');assert.strictEqual(pose().frame,0);
 await snapshot('SCREENSHOT_PHASE2_RUN.png');
 const yA=run('rifleGeometry().pivotY');run('p.stride=.22');const yB=run('rifleGeometry().pivotY');
 assert.notStrictEqual(yA,yB,'gun mount not tracking torso bob');
 // Verify muzzle origin / bullet consistency while in a distinct running stance.
 run('p.stride=.22;p.fire=0;p.ammo=18;bullets=[];mouseDown=false;shoot();');
 let origin=run('bullets[0]'),gun=run('rifleGeometry()');
 assert(Math.hypot(origin.x-gun.muzzleX,origin.y-gun.muzzleY)<.01,'running shot detached from barrel');
 run('p.vx=0;p.fire=.14;p.stride=0');assert.strictEqual(pose().anim,'fire','stationary firing pose not used');
 await snapshot('SCREENSHOT_PHASE2_FIRE.png');
 run('p.fire=0;p.ground=false;p.vy=-155;p.y=187;');assert.strictEqual(pose().anim,'jump');assert.strictEqual(pose().frame,0);
 await snapshot('SCREENSHOT_PHASE2_JUMP.png');
 run('p.vy=4');assert.strictEqual(pose().frame,1,'apex');
 run('p.vy=180');assert.strictEqual(pose().frame,2,'descent');
 run('p.vy=310');assert.strictEqual(pose().frame,3,'extended descent');
 run('jet=true;p.jumps=2;');assert.strictEqual(pose().anim,'jet');
 run('jet=false;p.ground=true;p.y=228;p.land=.21;');assert.strictEqual(pose().anim,'land');
 run('p.land=0;p.ground=false;p.dash=.56;');assert.strictEqual(pose().frame,0,'dive crouch');
 run('p.dash=.43;');assert.strictEqual(pose().frame,1,'dive launch');
 run('p.dash=.24;p.y=184;');assert.strictEqual(pose().frame,2,'dive prone');
 await snapshot('SCREENSHOT_PHASE2_DIVE.png');
 run('p.dash=.04;');assert.strictEqual(pose().frame,3,'dive recovery');
 run('p.dash=0;p.ground=true;p.y=228;p.face=-1;p.vx=-143;p.stride=.50;');
 const flipped=pose();assert.strictEqual(flipped.anim,'run');
 await snapshot('SCREENSHOT_PHASE2_LEFT.png');
 console.log('PASS: hero state machine, all four airborne/dive states, weapon follows moving torso and projectile hits muzzle, real game screenshots');
})().catch(e=>{console.error(e);process.exitCode=1});
