// Deterministic movement and save tests for playable Act III gaps, hazards and locks.
const fs=require('fs'),path=require('path'),vm=require('vm'),assert=require('assert');
const {Canvas,Image}=require('skia-canvas');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'browser-demo/index.html'),'utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const view=new Canvas(960,540);view.focus=()=>{};view.addEventListener=()=>{};
const el=()=>({hidden:true,value:'70',addEventListener(){},setAttribute(){},append(){},focus(){}});
const elems={game:view,controlsPanel:el()};
const document={hidden:false,getElementById:k=>elems[k]||(elems[k]=el()),createElement:()=>el(),body:{classList:{contains:()=>false}}};
class Img extends Image{set src(s){super.src=path.resolve(root,'browser-demo',s)}get naturalWidth(){return this.width}get naturalHeight(){return this.height}}
class Audio{constructor(){this.volume=0;this.loop=false}play(){return Promise.resolve()}cloneNode(){return this}}
const store=new Map(),localStorage={setItem:(k,v)=>store.set(k,v),getItem:k=>store.get(k)||null,removeItem:k=>store.delete(k)};
const ctx=vm.createContext({console,Math,Set,Map,Audio,Image:Img,document,window:{addEventListener(){}},navigator:{getGamepads:()=>[]},localStorage,requestAnimationFrame(){},Date});
vm.runInContext(js,ctx);
const run=s=>vm.runInContext(s,ctx);
const testRoute=(room,holes,end)=>{
  const serial=JSON.stringify(holes);
  run(`reset();state='playing';sector='${room}';enem=[];p.x=90;p.y=228;p.ground=true;jet=true;
    keys.add('d');var attempts=0;var stuck=0;var oldX=p.x;
    var holesForTest=${serial};
    for(let t=0;t<1800&&p.x<${end};t++){
      if(p.ground && holesForTest.some(([start,end])=>p.x>=start-55&&p.x<end-10))pressed.add(' ');
      update(.016);
      if(Math.abs(p.x-oldX)<.01)stuck++;else stuck=0;
      oldX=p.x;
      if(stuck>70)break;
    }
    keys.delete('d');`);
  const x=run('p.x'),death=run('deaths'),stuck=run('stuck');
  assert(x>=end,`${room} playable movement: x=${x.toFixed(1)} expected ${end}, deaths=${death}, stuck=${stuck}`);
  console.log(`${room}: crossed ${holes.length} gaps and reached x=${x.toFixed(1)}`);
};
// Use plain forward+jump movement; no cheats/teleports after starting each stage.
testRoute('transit',[[440,495],[940,997],[1349,1408]],1755);
testRoute('pumpworks',[[420,485],[835,900],[1150,1210]],1445);
testRoute('refuge',[],1304);
// Locks are enforced; the previous chapter cannot be bypassed by a nearby door.
run('reset();state="playing";sector="transit";enem=roomEnemies.transit;p.x=1772;p.y=228;interact()');
assert(run('sector')==='transit','pumpworks locked before freight power');
run('freightA=true;freightB=true;interact()');
assert(run('sector')==='pumpworks','pumpworks unlocked');
run('p.x=1456;p.y=228;state="playing";interact()');
assert(run('sector')==='pumpworks','shelter requires pumps');
run('pumpA=true;pumpB=true;interact()');
assert(run('sector')==='refuge','shelter unlocked by pumps');
run('p.x=1304;p.y=228;state="playing";interact()');
assert(!run('survivorsFound'),'shelter stays sealed until comms');
run('shelterSignal=true;interact()');
assert(run('survivorsFound'),'survivor rescue occurs after comms');
// Reloading any previous v5 save maintains earlier progress and unlocks Act III route.
run('reset();state="playing";sentinelDead=true;checkpoint={sector:"reactor",x:900,y:228};saveProgress()');
assert(run('continueProgress()'),'v6 checkpoint reload');
assert(run('sector')==='reactor'&&run('sentinelDead'),'sentinel save allows onward travel');
console.log('PASS: Act III traversal, locks, survivor extraction, and chapter saves');
