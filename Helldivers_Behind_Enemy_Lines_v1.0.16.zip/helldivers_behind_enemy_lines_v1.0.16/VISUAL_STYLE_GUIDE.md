# Visual Style & Readability Guide — Phase 1

## Four visual planes, always in this order

1. **Far and mid-distance:** environmental concept backdrop, parallax structures, fog, subdued signage; may contain animation but never occludes play.
2. **Structural middle:** industrial columns, banners, ambient beacons, industrial lighting. These deliberately use lower contrast than terrain and characters.
3. **Play plane:** solid floors, thin one-way ledges, visible gap-edge warnings and *small* interaction markers. This layer is legible at game speed.
4. **Gameplay:** devices, enemies, projectiles, Helldiver, action effects, HUD. Nothing from the decorative world is painted across the Helldiver afterward.

The background matte protects separation at the foot of the screen. The upgraded floor pass uses a solid dark body, a clean highlighted walkable edge and sparse world-anchored seams. Hazard marks are concentrated at actual gaps.

## Object status colors

- **Gold:** actionable machine/objective/route, or mission-useful trim.
- **Muted coral:** locked route, hazard or denial (context and visual geometry must accompany the color).
- **Teal or green:** safe, completed, operational state.
- **Light, sector-tinted metal rim:** solid walkable surface; not a pickup or objective.

## Sector accents

| Sector | Visual character |
| --- | --- |
| Main colony | Warm pale-gold on smoky purple steel |
| Maintenance sublevel | Amber repair signage on deep maroon industrial structures |
| Hidden archive | Cool cyan light against blue-gray metal |
| Blacksite | Restrained red security warnings and worn pale steel |
| Reactor | Volcanic orange/coral metal and reactor glow |
| Freight conduit | Cyan-gray freight structures and cool titanium ledges |
| Pumpworks | Aquatic cyan machinery, strong amber/white electrified water warnings |
| Shelter Twelve | Softer green-gray utility lighting, gold active controls |

## Guardrails for later phases

Do not reintroduce foreground cables, opaque scanning bars or near-black silhouettes over the playable character. Texture noise should remain under the sharp floor contact edge. Avoid HUD redesign in a world-layer pass. Maintain the user's saved controls, iPad gesture handling, soundtrack state, level logic and testable collision coordinates.
