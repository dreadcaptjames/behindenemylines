# v1.0.14 — Third original track: Liberty Day

**Liberty Day** plays on the title/menu and rescue victory screens only, not during ordinary combat or normal room traversal. This keeps the agreed continuous campaign score intact: **Cup of Liber-tea** stays active through exploration and regular combat, while **By Order of High Command** is reserved for Warden and Sentinel bosses. Music states use soft crossfades with the user's saved volume and dialogue ducking; playback requires a user gesture on iPad Safari. The title/victory anthem restarts when those scenes are re-entered, while Cup's playhead continues after boss fights.

# v1.0.7 soundtrack policy

The main theme is **Cup of Liber-tea** from the first gameplay interaction onward. Normal enemies never initiate music switches; exploring, traveling, recovering, and fighting all share the same uninterrupted musical stream. During a major Warden or Sentinel encounter only, **By Order of High Command** crossfades in, with a 6.5-second hold at the edge of the boss zone to prevent re-triggering. The Cup of Liber-tea playhead keeps running under boss music; it does not jump back to the beginning after a fight. Dialogue lowers the music and gameplay pause silences it without resetting playback.

---

# v1.0.6 soundtrack design addendum

Dynamic score states: ambient exploration → Cup of Liber-tea during hostile pressure → By Order of High Command during the Warden/Sentinel. Short combat hold reduces music thrashing. Dialogue reduces output ~78%; audio is muted during pause/title. Use a two-second style crossfade between score states. The original WAV masters remain external to the public build.

---

# v1.0.3 — Character Mechanics

**Locomotion:** hip centers are kept near the torso. Knees articulate in a narrower range, feet alternate between planted stance and lifted recovery, and the eight-frame cycle advances by actual horizontal travel. Upper body and cape remain coherent.

**Weapon:** the rifle source pixels are preserved as a separate transparent part. Aim rotates the gun about the shoulder pivot. The visible rifle tip, muzzle flash, and fired projectile share an identical transform, avoiding screen-space guesses. All input methods use the same weapon geometry.

**Readability:** no oval cast shadow is drawn, and no wide shadow remains baked into character frames.

## v1.0.5 — Motion and enemy proportions

The character's legs must remain tucked/grounded within the armor silhouette in ascent and apex rather than the prior exaggerated V-shaped spread. Dive is a committed forward evasion: crouch, ballistic launch, extended flight, recovery. The player's horizontal/prone collision shape changes during the dive. Existing rifle alignment remains intact.

Automatons: Troopers/Marauders visually match the Helldiver; Devastators are markedly taller and bulkier; Striders are tallest among common units. Enemy art, optics, damage areas, projectile positions and melee reach are coordinated using class profiles. Drones and fixed emplacements are exempt from the humanoid scale guideline.
