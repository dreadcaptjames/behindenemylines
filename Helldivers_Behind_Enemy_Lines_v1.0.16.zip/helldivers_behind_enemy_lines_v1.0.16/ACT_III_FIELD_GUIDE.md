# FIELD GUIDE — ACT III // THE SURVIVORS BELOW

## Reaching the new chapter

Continue from your previous v1.0.7 save, or play through and defeat the Reactor Sentinel. After its post-battle dialogue, move to the far east of the Reactor Core and interact with the freight hatch (**E**, touch USE, or gamepad interact).

## The route

- **Freight Conduit 09**: Work eastward across broken tracks. Restore **Freight Node Alpha** (x 645), then **Freight Node Beta** (x 1234). Enter the pump hatch at the far east (x 1772). A shuttle hatch at the western entrance returns to the Reactor Core.
- **Flooded Pumpworks**: The standing water in the floor breaks is energized. Use platforms, timed jumps, and the previously recovered jump jets to cross. Stabilize **Pump Alpha** (x 575) and **Pump Beta** (x 1050) to discharge the flooded channels. The far-right shelter entrance is then unlocked (x 1456).
- **Shelter Twelve**: Secure the east wing. Restore **Shelter Communications** (x 932) and reach the sealed shelter entrance (x 1304). Read the local records for additional story context. The chapter concludes through dialogue; no new boss music interrupts the ongoing main theme.

You can travel back between these rooms. Entering a major sector records a checkpoint, and the game preserves restored nodes, pumps, communication uplink, and discovered intelligence.

### Controls

A/D or the on-screen D-pad to move; Space / JUMP to jump; Shift / DIVE to dive; E / USE to interact. Mouse or touch aim+fire, F to fire, R to reload; G for EMP after collecting it; M for tactical map. The mobile controls continue to prevent Safari gestures in the game surface, but physical iPad testing is recommended.
