# HELLDIVERS: BEHIND ENEMY LINES — v1.0.10

## Phase 2 of 5 — Helldiver Art & Animation

A browser-game character-art and movement-presentation pass built on the eight-sector v1.0.9 campaign. **No levels, save flags, enemy damage rules, soundtrack policy or movement physics have been changed.**

### Player appearance

- Increased the visible stride difference between the eight running keyframes. Each leg now has its own contact, compression and recovery positions; the cape moves from a shoulder-anchored fabric silhouette rather than relying only on rigid rotation.
- Rebuilt four airborne poses: rising, apex, descent and jet boost. The knees remain under the hips, the boots form a compact silhouette, and the cape bends back into the jump rather than splintering into separate blocks.
- Replaced dive artwork that rotated the entire upright character (and pointed the visor downward) with four purpose-drawn **forward-facing** states: crouch, airborne launch, true horizontal/prone travel, and recovery. Rifle detail is tucked along the arms during the dive.
- Added distinct stationary firing sprites and less jarring hit transparency; landing has a short, thin contact-plane accent instead of an oval shadow.

### Weapon attachment

The newly shared `heroPose()` function selects the visible body state and exposes its animation bob. `rifleGeometry()` uses that same bob for the independent rifle rotation, its muzzle tip, bullets and muzzle flash. The visible gun is not rendered during the dive, where the pose owns its tucked rifle.

### Testing

`tests/test_phase2_sprite.py` verifies mirrored assets, distinct eight-frame gait and four-frame dive/jump silhouettes, prone visor orientation, and no baked ground shadows. `tests/test_phase2_animation.js` renders the in-game poses, exercises movement state selection and verifies projectile/muzzle alignment while running. The full existing campaign, level geometry, music, HUD, enemies, and gesture tests were rerun. A physical iPad Safari playtest and Godot engine run remain unverified.

### Scope and regeneration

`python tools/build_phase2_character.py` regenerates the authored art from the preserved original (`art/hero_source_art_r.png`) and the first-pass procedural rig. The source keeps the earlier 84×72 sprite canvas; no new image assets are streamed at runtime. The Godot companion remains a prior Act I/II prototype, not an up-to-date Act III port.

This complete ZIP is meant to be archived in `dreadcaptjames/behindenemylines` on `main`; no GitHub push occurs as part of local packaging. Next planned **Phase 3** is the main menu, HUD and on-screen objective/interact UX overhaul.
