# Behind Enemy Lines v1.0.14 — Liberty Day Soundtrack

- Added **Liberty Day** as the main-menu and end-of-campaign anthem. It is never triggered by ordinary enemy encounters, keeping soundtrack changes intentional and infrequent.
- The main campaign still plays **Cup of Liber-tea** continuously during traversal and combat. **By Order of High Command** remains exclusive to the Warden and Reactor Sentinel fights.
- Two-second transitions use Web Audio gain nodes, compatible with the existing music toggle, iPad volume control, and speech ducking. Song playback starts after the first user gesture.
- On the first deployment, Cup of Liber-tea begins at its opening; it is not restarted by regular fights or returning from a boss. Liberty Day starts at the beginning when the title or victory screen is re-entered.
- Includes a lightweight 160 kbps MP3 derivative. The rights-holder's M4A master is not in the public game bundle.
- All previous levels, save states, animation, HUD and mobile touch preferences remain unchanged.

**Testing:** Soundtrack state transitions, gain control, audio decoding, campaign regression, and mobile controls. Physical iPad Safari remains to be tested.
