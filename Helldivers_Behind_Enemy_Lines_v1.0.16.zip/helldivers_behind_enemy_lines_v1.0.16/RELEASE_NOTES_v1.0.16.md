# Behind Enemy Lines — v1.0.16 // Independent Mouse Aiming

## Fixed
- Move the mouse over the canvas to aim **without holding a mouse button**.
- Keyboard movement (A/D or arrows), jumping (Space), and diving (Shift) no longer override cursor aiming.
- Left click continues firing, and F fires toward the current mouse cursor when it is over the game.
- Cursor direction updates each frame in world space as the camera tracks the player.
- Releasing the mouse button does not discard hover aim; moving outside the game returns to keyboard facing.
- Gamepad right-stick aim overrides passive mouse hover; the mobile virtual aim stick retains its independent aiming and firing path.
- Mouse button and keyboard are processed independently so simultaneous movement, jump, aim, and fire work together.

All eight sectors, saved progress, three-song soundtrack, touchscreen UI, and gameplay rules are otherwise unchanged.
