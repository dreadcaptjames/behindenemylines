# HELLDIVERS: BEHIND ENEMY LINES — v1.0.14

**Phase 5 — Mobile UX Refinement completes the five-phase visual and interface overhaul.** The complete eight-area browser campaign has adjustable dual-thumb controls, left-handed layout, drag-to-steer movement, optional haptic feedback where supported, saved touch size/opacity preferences, a 30 FPS battery-saver option, and a more reliable landscape interface. See [v1.0.14 release notes](RELEASE_NOTES_v1.0.14.md).

**Play:** Unzip, then open `browser-demo/index.html`; or upload this complete ZIP to the configured GitHub repository. On iPad, use landscape orientation. Tap **LAYOUT** during gameplay (or open Options) to configure the controls. The soundtrack continues playing *Cup of Liber-tea* throughout ordinary gameplay and switches to *By Order of High Command* for boss fights. Audio requires a user gesture to start on most mobile browsers.

**Scope:** Browser campaign is the primary, tested implementation. The bundled Godot companion still reflects an earlier prototype.

---

# HELLDIVERS: BEHIND ENEMY LINES — v1.0.12

**Eight connected playable browser areas across three acts.** This release completes **Phase 4 — Environmental Atmosphere**. It introduces animated wall fans, conveyor details, atmospheric steam and coolant, reactive warning/status lights, sector-specific signage and survival props, plus a persistent low-detail mode intended for mobile performance. Details: [Release notes](RELEASE_NOTES_v1.0.12.md).

**Play:** Unzip and open `browser-demo/index.html` in a modern browser, or upload the complete ZIP to the GitHub repository root for the configured GitHub Pages deployment. Use landscape orientation on iPad. The soundtrack remains *Cup of Liber-tea* continuously with *By Order of High Command* during boss battles. Browser audio begins after a user gesture on platforms that restrict autoplay.

The browser game is the full eight-area experience. The included Godot companion is an older prototype rather than a fully updated port.

---

# HELLDIVERS: BEHIND ENEMY LINES — v1.0.11

**Complete playable browser campaign: 8 connected sectors across 3 acts.** This release completes **Phase 3 — UX/UI Overhaul**: new field-command title screen, better pause and options menus, compact combat HUD, objective counts, a readable safe-to-open sector map, mouse/gamepad/touch/keyboard menu input, checkpoint-overwrite warning, and accessibility display preferences. See [v1.0.11 release notes](RELEASE_NOTES_v1.0.11.md).

Unzip and open `browser-demo/index.html` in a modern browser, or upload the ZIP to the repository root for the configured GitHub Pages workflow. The music retains **Cup of Liber-tea** as the continuous main theme and **By Order of High Command** for bosses. The touch layout is optimized for landscape. Full browser game is playable; Godot project is still an earlier prototype.

---

# HELLDIVERS: BEHIND ENEMY LINES — v1.0.10

**Playable browser campaign: 8 connected areas across 3 acts**, including Freight Conduit 09, Flooded Pumpworks and Shelter Twelve. Start or resume at `browser-demo/index.html`. See [Phase 2 character-art release notes](RELEASE_NOTES_v1.0.10.md), [visual cleanup release notes](RELEASE_NOTES_v1.0.9.md), [Phase 1 style guide](VISUAL_STYLE_GUIDE.md) and [Act III field guide](ACT_III_FIELD_GUIDE.md). The continuous original soundtrack and mobile controls are retained. Phase 1 visual cleanup separates background depth, platforms, hazards and interactive objects. Phase 2 improves the Helldiver run, jump, dive, cape, firing posture, and rifle attachment.

**Companion status:** the included Godot project is the older Act I/II prototype, not yet feature-matched to Act III.

---

# HELLDIVERS: BEHIND ENEMY LINES — v1.0.7

## Original soundtrack — continuous main theme

Two original compositions supplied by the project owner are included as browser-optimized 192 kbps MP3 files:

| Gameplay | Music | Browser filename |
| --- | --- | --- |
| Title screen and mission-complete ending | **Liberty Day** — fanfare/anthem | `audio/liberty_day_anthem.mp3` |
| Exploration, travel, and normal enemy fights | **Cup of Liber-tea** — continuous main theme | `audio/cup_of_liber_tea_combat.mp3` |
| Warden and Sentinel boss battles | **By Order of High Command** — rare boss override | `audio/by_order_of_high_command_boss.mp3` |

The main theme continues playing without restarting between encounters. Only bosses trigger crossfades, with a longer hold to prevent soundtrack changes at boss-area boundaries. Radio dialogue ducks the music; pause/background silences it, while the title and victory screen use Liberty Day as a separate anthem. The music toggle and a new volume slider save their settings locally. On iPad, a Web Audio gain mixer provides audio levels independently of Safari's hardware volume restrictions. Music starts after a user gesture due to browser autoplay rules.

The complete original compositions have not been arbitrarily shortened for a cue. A short 2.5-second seam overlap makes replay boundaries less abrupt, though this is not a tempo-matched stem arrangement. The original WAV masters are **not included in the public game ZIP**; only optimized in-game derivatives are bundled. This prevents unnecessary downloads and preserves the source masters separately.

**To play:** Extract the ZIP and open `browser-demo/index.html` on desktop; or upload the complete ZIP to the repository root so the GitHub Pages workflow publishes it. Sound starts with first gameplay interaction. The existing mobile controls and game saves are preserved.

---

# HELLDIVERS: BEHIND ENEMY LINES — v1.0.5

**Movement & Automaton Scale Pass** | Unofficial fan-made prototype.

## Changes in this release

- Four new painted jump poses, selected by ascent, apex, descent and fall velocity; jump-jet art shares the corrected, tighter leg pose.
- Tactical dive is now a proper movement sequence: crouch, launch, airborne travel and recovery, with real horizontal and vertical velocity and a lower collision silhouette while airborne.
- Bigger, class-specific Automaton bodies. Troopers and Marauders are roughly Helldiver-height; Devastators, Berserkers and Scout Striders are taller. Fixed turrets and drones deliberately retain their smaller specialist silhouettes.
- Enemy hitboxes, optics, line-of-sight checks, projectile origins and melee reach use matching scale profiles, avoiding oversized art with tiny hitboxes.
- The existing v1.0.4 atmosphere, corrected rifle muzzle alignment, iPad controls, music toggle, saves, and two-act campaign remain intact.

## Launch

Extract the ZIP, then open `browser-demo/index.html` in a modern browser. On touchscreen devices, rotate to landscape for easier two-thumb controls. Touch controls are in `mobile/`.

Keyboard: A/D move, Space jump, Shift dive, mouse aim + fire, F fire, E interact, R reload, Q stratagem, G EMP, M map.

## Testing

Verified here: browser Canvas campaign and rendering tests, state-based dive trajectory tests, four-stage airborne sprite loading, hitbox/scale tests, rifle muzzle tests, artwork checks and touch gesture tests. The Godot companion (`project.godot`) has been updated to use matching sprites, animation states and sizes, but **has not been executed in Godot** in this environment.

## Public deployment

The full release ZIP is designed for your repository `dreadcaptjames/behindenemylines`; uploading this ZIP intact to the repository root and committing to `main` makes it a deployment candidate for the configured GitHub Pages workflow. It is **not automatically uploaded or deployed** by generating this package.

This fan project is not affiliated with Arrowhead or Sony. Public use of the Helldivers setting and marks may require permission.

## New in v1.0.14

Liberty Day is now the menu and victory anthem; Cup of Liber-tea remains continuous during the full campaign, and By Order of High Command remains the boss soundtrack.
