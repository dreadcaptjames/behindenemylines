# Original Soundtrack — Behind Enemy Lines

All three original compositions were provided by the project owner, who stated they hold the rights and authorized integration into the game.

## Liberty Day
- Source recording: `Liberty-Day-masterforge-signature.m4a`
- Source format: stereo AAC, 48,000 Hz, 3:30.86
- In-game use: title/menu anthem and mission-complete/victory theme; not activated by enemy proximity
- Optimized asset: `audio/liberty_day_anthem.mp3` (160 kbps MP3, soft loop edges)

## Cup of Liber-tea
- Source recording: `Cup-of-Liber-tea-masterforge-signature.wav`
- Source format: stereo PCM, 48,000 Hz, 24-bit, 2:26
- In-game use: uninterrupted main theme for exploration, ordinary combat, and traveling
- Optimized asset: `audio/cup_of_liber_tea_combat.mp3`

## By Order of High Command
- Source recording: `By-Order-of-High-Command-masterforge-signature.wav`
- Source format: stereo PCM, 48,000 Hz, 24-bit, 3:12.72
- In-game use: Warden and Reactor Sentinel boss encounters
- Optimized asset: `audio/by_order_of_high_command_boss.mp3`

The final music credits should list the artist/composer name as requested by the rights holder (not yet provided). In-game derivatives are not a license to redistribute the original masters. The public game release includes compressed tracks only, not the original masters.
