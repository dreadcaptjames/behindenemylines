# Behind Enemy Lines v1.0.13 — Phase 5: Mobile UX Refinement

This release completes the five-part visual/UX development roadmap. The full eight-area browser campaign, assets, weapons, saves, original soundtrack, and story have been retained. The bundled Godot companion remains an earlier prototype and does not have full campaign parity.

## New mobile controls

- **Drag-to-steer D-pad:** Hold or slide on the directional pad to change movement direction without lifting your thumb. Directional buttons still enter stratagem codes normally.
- **Left-handed mode:** Swap the aim/shoot surface to the left and movement pad to the right. The jump, dive, and interact cluster moves with the aim pad.
- **Control sizes:** Compact (85%), standard (100%), or large (115%).
- **Touch-control opacity:** 65%, 80%, 90%, or 100%; pressed actions brighten for feedback.
- **Optional haptics:** A tiny vibration on input for devices that implement `navigator.vibrate`; iPad Safari may not support it, and the game continues normally without it.
- **Battery saver:** Optional ~30 FPS render/update cadence in touch mode. The game stops rendering/simulating while the page is hidden. The existing low-detail environment effects setting remains separate.
- **Improved landscape layout:** The equipment, pause, map, and layout buttons stay in a single compact header row on supported landscape viewports instead of being obscured by the game canvas.
- **Touch music volume in Options:** Soundtrack volume remains adjustable when the condensed mobile header hides its slider.
- **Quick controls setup:** In gameplay, tap **LAYOUT** to open the touch configuration. Options also contains these settings; choose **DONE · RETURN TO MISSION** to close. Settings save locally per browser/device; **RESTORE DEFAULTS** resets the mobile layout only.

## Controls and gameplay compatibility

- Run/jump/fire simultaneously with multiple thumbs; pointer capture prevents stuck buttons.
- Game surfaces continue to block double-tap zoom, selection, long-press browser menus, and scroll gestures, while the Options panel remains scrollable.
- All three acts, eight areas, checkpoints, rifle/cape animations, boss progression, and original compositions are unchanged.
- **Cup of Liber-tea** is still the continuous main soundtrack and **By Order of High Command** is still reserved for boss encounters.

## Verification

- `python tests/test_phase5_touch.py`: passed left/right layouts, sizes, opacity, battery-saver toggles, saved settings (using a test storage shim), touch volume, reset, sliding movement, and iPad/phone landscape screenshots.
- `python tests/test_mobile_gestures.py`: passed gesture blocking and simultaneous touch input.
- `python tests/test_mobile_touch.py`: passed in an isolated run (touch movement, firing, jump, stratagem, pause, and resume); it may stall under repeated headless Chromium sessions in this environment.
- Canvas campaign, Act III traversal, visual depth, animation, aiming, UI, environmental atmosphere, and original soundtrack JS regression suites passed.
- Physical iPad Safari usability, real haptic feedback, and actual battery-life impact have not been tested; the headless touch tests run in Chromium emulation.

## Play

Extract the ZIP and open `browser-demo/index.html`, or commit the complete ZIP to your GitHub repository root for GitHub Pages to publish it. Mobile layout settings and campaign saves use separate localStorage keys. For iPad, landscape orientation is strongly recommended.
