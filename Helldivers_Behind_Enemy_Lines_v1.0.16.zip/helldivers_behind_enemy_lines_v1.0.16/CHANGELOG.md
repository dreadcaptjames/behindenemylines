## v1.0.16 — Independent mouse aiming
- Fixed keyboard movement/jump interrupting mouse aim; hover-aim and firing are independent.
- Mouse cursor now controls rifle aim during locomotion and jumping, not only when clicking.
- Preserved touch-stick aiming and controller input priority.

## v1.0.14 — Liberty Day soundtrack
- Added the third original composition as title/victory anthem, with no normal-combat music switching.
- Crossfade and mobile audio mixing preserved; full campaign unchanged.

# v1.0.13 — MOBILE UX REFINEMENT // PHASE 5

Added saved mobile-control presets (left/right-handed, size, opacity), a drag-to-steer directional pad, optional input haptics, optional 30 FPS battery saver, responsive one-row landscape equipment controls, touch music volume in options, and quick return/reset buttons. Preserved double-tap zoom prevention and simultaneous touch actions. Campaign, original soundtrack and earlier four visual/UX phases remain intact. See `RELEASE_NOTES_v1.0.13.md`.

---

# v1.0.12 — ENVIRONMENTAL ATMOSPHERE // PHASE 4

Eight world-space atmosphere scenes now include ventilation fans, drive systems, coolant droplets, steam and dust, status-responsive light fixtures, and sector-specific story dressing. Low-detail environment effects can be enabled and remembered; reduced-effects also calms background motion and flickering. All original gameplay, music and mobile controls are preserved. See `RELEASE_NOTES_v1.0.12.md`.

---

# v1.0.11 — MISSION INTERFACE // PHASE 3

Rebuilt title, pause, victory, HUD, objective tracker, and sector map with consistent visual hierarchy. Added pointer/keyboard/controller navigation, saved-checkpoint reset confirmation, world-pausing map, enhanced status prompts, browser settings for reduced effects and tutorial hints, and updated touch layout. Preserves the full eight-area campaign and original soundtrack. See `RELEASE_NOTES_v1.0.11.md`.

---

# v1.0.10 — HELLDIVER ART & ANIMATION // PHASE 2

Increased readable run-cycle leg travel, added shoulder-anchored cape motion, redesigned four airborne and horizontal tactical-dive poses, kept the helmet/visor facing forward, introduced a separate standing fire pose, and made rifle/bullet/muzzle alignment follow body movement. Added asset/screenshot state regression tests. No campaign or music changes. See `RELEASE_NOTES_v1.0.10.md`.

---

# v1.0.9 — VISUAL SYSTEM CLEANUP // PHASE 1

Standardized eight sector color palettes and platform silhouettes, reduced background noise, restored concept-art legibility in old sectors, marked gap edges, standardized in-world interaction signals, and differentiated hazardous water from safe cyan elements. No game rules or soundtrack edits. See RELEASE_NOTES_v1.0.9.md and VISUAL_STYLE_GUIDE.md.

---

# v1.0.8 — ACT III // THE SURVIVORS BELOW

Added three playable environments, six story logs, Act III story/dialogue and ending, quest gates, persistent chapter state, and new backdrop art. Fixed one-way platform collision. See RELEASE_NOTES_v1.0.8.md and ACT_III_FIELD_GUIDE.md.

---

# v1.0.7 — Continuous Main Theme

- **Cup of Liber-tea** now loops throughout exploration and ordinary combat, with no transitions when enemies appear/disappear.
- **By Order of High Command** is reserved for Warden and Sentinel boss encounters. The boss cue holds for 6.5 seconds after losing proximity to avoid repeated changes near encounter boundaries.
- The main theme's playhead is never reset when entering or leaving a fight; it continues quietly behind boss music and returns smoothly.
- Radio dialogue continues to duck the active track; pause and background tabs remain silent; music volume/toggle and iPad touch audio remain intact.
- Updated the Godot companion music policy and the browser music tests. Browser media playback still requires a user gesture on iPad.

---

# v1.0.6 — Original Soundtrack Integration

- Added `Cup of Liber-tea` as the combat composition and `By Order of High Command` for the Warden/Sentinel bosses.
- Converted original stereo WAV masters into optimized, crossfade-seamed 192 kbps MP3 game assets.
- Kept the quieter existing exploration underscore, with dynamic fades between music states and radio-dialogue ducking.
- Added master music level slider (browser storage) alongside the existing music toggle.
- Added a Web Audio gain mixer for reliable iPad Safari volume control after user input.
- Updated Godot companion music source references (engine runtime unverified).
- Preserved v1.0.5 movement, dive, Automaton scale, and touch controls.

---

# v1.0.5 — Movement and Automaton Scale

- Added 4 painted jump keyframes, improved jump-jet posing, and 4 dedicated dive keyframes for right/left facings.
- Dive action now has crouch, airborne launch, travel, recovery, and matching horizontal/vertical momentum.
- Replaced the old dive's upright sprite/shifting behavior with a horizontal prone pose and dynamic collision box.
- Scaled 7 Automaton ground-unit variants and coordinated enemy hitboxes, threat detection, optics, firing positions and melee ranges.
- Kept drones and turrets smaller by design and preserved existing Hulk-class bosses.
- Preserved browser touch controls, save compatibility, two-act progression, character rifle aim and environmental depth fixes.
- Updated editable Godot companion; engine execution remains unverified.
