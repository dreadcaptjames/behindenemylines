"""Phase 2 character polish for Behind Enemy Lines.

Rerunnable painterly pixel art pass built from the original 84x72 Helldiver.
The source design/visor and colors are retained, while limb articulation, cape
follow-through and explicitly prone diving poses are authored separately.
Usage from the release root: python tools/build_hero_animations.py &&
                             python tools/build_phase2_character.py
"""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from math import sin, pi
import importlib.util

ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'art'
SIZE=(84,72)
NEAREST=Image.Resampling.NEAREST
# Import the first-pass rig. This also refreshes canonical authored base frames.
spec=importlib.util.spec_from_file_location('rig',ROOT/'tools'/'build_hero_animations.py')
rig=importlib.util.module_from_spec(spec)
spec.loader.exec_module(rig)
BASE=rig.source
BLACK=(11,7,22,255)
DARK=(31,24,45,255)
SHELL=(55,43,75,255)
SHELL_HI=(84,69,106,255)
METAL=(111,102,119,255)
LIGHT=(154,133,169,255)
GOLD=(255,199,33,255)
GOLD_HI=(255,231,105,255)
AMBER=(181,109,20,255)

# More leg travel than the prototype's almost-stationary 8-frame run cycle.
# On every contact frame one heel touches the floor and one foot recovers.
rig.run_poses[:]=[
 ((60,67),(38,67),(52,52),(41,53),0),
 ((58,68),(41,59),(51,52),(45,52),1),
 ((51,67),(47,57),(49,51),(49,48),0),
 ((43,58),(59,67),(44,49),(53,52),-1),
 ((38,67),(60,67),(41,53),(52,52),0),
 ((41,59),(58,68),(45,52),(51,52),1),
 ((47,57),(51,67),(49,48),(49,51),0),
 ((59,67),(43,58),(53,52),(44,49),-1),
]

# Replace rigid cape rotation with trailing fabric that bends progressively
# farther from the shoulder; this keeps its attachment locked to the armor.
def cape_wake(style,frame):
    style_phase={
      'run':[-9,-13,-15,-10,-5,-7,-11,-13],
      'idle':[-1,0,1,0],
      'fire':[-2,-3,-2],
      'reload':[-1,0,-1],
      'land':[-10,-4,0,-1],
      'hurt':[7,-9,2],
      'jump':[-11,-14,-12,-9],
      'jet':[-14,-19,-16,-17],
    }
    displacement=style_phase[style][frame]
    out=Image.new('RGBA',SIZE)
    # Keep the first pixels anchored; the cloth tail catches wind behind motion.
    for y in range(27,59):
        t=max(0,min(1,(y-29)/24))
        dx=round(displacement*t*t)
        lift=round(-abs(displacement)*t*t*.16)
        for x in range(8,42):
            px=rig.cape.getpixel((x,y))
            if px[3] and 0<=x+dx<84 and 0<=y+lift<72:
                out.putpixel((x+dx,y+lift),px)
    return out

# Two-bone legs preserve a hip/knee/ankle relationship through each jump phase;
# they are never manufactured by rotating the standing sprite.
AIR_POSES=[
 # rear boot, front boot, rear knee, front knee, torso offset
 ((42,62),(52,62),(42,50),(49,50),-2), # takeoff
 ((43,58),(52,60),(42,48),(51,48),-3), # apex
 ((43,65),(54,66),(42,52),(51,52),-1), # descent
 ((40,60),(53,62),(41,49),(50,50),-4), # jet boost
]

def jumped(frame,gun=False,jet=False):
    rear,front,kr,kf,bob=AIR_POSES[frame]
    out=Image.new('RGBA',SIZE)
    out.alpha_composite(cape_wake('jet' if jet else 'jump',frame))
    out.alpha_composite(rig.armor_leg(0,(44,41+bob),rear,False,knee=kr))
    out.alpha_composite(rig.body,(0,bob))
    out.alpha_composite(rig.armor_leg(0,(49,41+bob),front,True,knee=kf))
    if jet:
        # Backpack ignition on sustained double-jump frames, under the rifle.
        q=ImageDraw.Draw(out)
        q.rectangle((24,34+bob,27,39+bob),fill=AMBER)
        q.rectangle((25,38+bob,26,42+bob),fill=GOLD)
    if gun:out.alpha_composite(rig.gun,(0,bob))
    return out

# Dive frames are authored in world-facing orientation. Rotating the complete
# standing soldier by 90deg pointed the visor at the floor, and turned a dive
# into a tumbling somersault. Here the head LOOKS forwards in travel.
def armor_segment(d,a,b,w,fill):
    d.line([a,b],fill=BLACK,width=w+3,joint='curve')
    d.line([a,b],fill=fill,width=w,joint='curve')

def cape_prone(d,variant):
    tails={1:[(34,30),(24,26),(7,25),(5,32),(26,40),(35,36)],
           2:[(34,30),(21,27),(3,29),(2,39),(20,44),(36,38)]}
    pts=tails[variant]
    d.polygon(pts,fill=BLACK)
    d.polygon([(x+1,y+1) for x,y in pts],fill=DARK)
    d.line([pts[0],pts[1],pts[2]],fill=SHELL_HI,width=3)
    d.line([pts[2],pts[3]],fill=GOLD,width=3)
    d.line([pts[3],pts[4]],fill=AMBER,width=2)
    d.line([(18,34),(28,36)],fill=SHELL_HI,width=2)

def torso_prone(d,frame):
    # Foreground shoulder armor, collar, upper chest and symbol aligned with
    # the dive vector. Original source helmet pixels are pasted over this rig.
    d.polygon([(30,29),(37,22),(50,23),(58,29),(57,39),(48,42),(32,39)],fill=BLACK)
    d.polygon([(32,29),(40,24),(50,26),(55,29),(53,38),(45,40),(33,36)],fill=SHELL)
    d.polygon([(40,25),(50,26),(53,31),(49,37),(40,35),(36,29)],fill=SHELL_HI)
    d.line([(37,29),(44,27),(49,29)],fill=LIGHT,width=2)
    d.polygon([(41,32),(46,30),(50,32),(48,37),(43,37)],fill=AMBER)
    d.line([(42,33),(47,32)],fill=GOLD,width=2)
    d.line([(35,36),(46,38)],fill=BLACK,width=3)
    # Rear-mounted pack has an obvious gold seal, like our standing sprite.
    d.polygon([(28,23),(39,21),(42,26),(39,34),(29,34)],fill=BLACK)
    d.polygon([(29,24),(38,23),(40,27),(36,32),(29,32)],fill=SHELL_HI)
    d.line([(31,25),(37,25)],fill=LIGHT,width=2)
    d.ellipse((32,26,38,32),fill=AMBER)
    d.ellipse((34,27,37,30),fill=GOLD)
    d.line([(27,33),(30,38)],fill=GOLD,width=2)

def helmet_prone(out,shift=(0,0)):
    # Preserve the identity/visor from the owner's original character pixels.
    # The crop deliberately avoids the old weapon and the upright lower torso.
    mask=Image.new('L',SIZE)
    m=ImageDraw.Draw(mask)
    m.polygon([(43,5),(50,3),(61,4),(67,7),(67,21),(62,24),(49,24),(43,18)],fill=255)
    layer=Image.new('RGBA',SIZE)
    layer.paste(BASE,(0,0),mask)
    crop=layer.crop((43,3,68,25))
    out.alpha_composite(crop,(49+shift[0],13+shift[1]))

def prone(frame):
    out=Image.new('RGBA',SIZE)
    d=ImageDraw.Draw(out)
    cape_prone(d,frame)
    # Distinct trailing ankles rather than the original sideways rotated legs.
    if frame==1:
        hip=(33,38);legs=[((19,47),(9,59)),((24,39),(12,44))]
    else:
        hip=(32,37);legs=[((21,39),(9,37)),((21,45),(8,48))]
    for i,(knee,foot) in enumerate(legs):
        armor_segment(d,hip,knee,9,SHELL if i==0 else SHELL_HI)
        armor_segment(d,knee,foot,8,DARK if i==0 else SHELL)
        d.polygon([(foot[0]-4,foot[1]-3),(foot[0]+4,foot[1]-3),(foot[0]+6,foot[1]+1),(foot[0]-5,foot[1]+2)],fill=BLACK)
        d.line([(foot[0]-3,foot[1]-1),(foot[0]+3,foot[1]-1)],fill=LIGHT,width=2)
        d.ellipse((knee[0]-3,knee[1]-3,knee[0]+3,knee[1]+3),fill=AMBER if i else LIGHT)
        d.line([(knee[0]-1,knee[1]-2),(knee[0]+2,knee[1]-2)],fill=GOLD,width=2)
    torso_prone(d,frame)
    # Arm extends along travel vector; the rifle is stowed parallel to it.
    armor_segment(d,(51,34),(62,40),7,SHELL_HI)
    armor_segment(d,(62,40),(70,37),6,SHELL)
    d.rectangle((67,34,73,41),fill=BLACK)
    d.line([(68,35),(73,35)],fill=GOLD,width=2)
    # Extend original painted rifle while prone. The existing independent gun
    # is hidden during dives, so this is a sprite-only detail (not a firing gun).
    gun=Image.open(ART/'hero_gun_r.png').convert('RGBA')
    bounds=gun.getbbox(); g=gun.crop(bounds)
    if g.width>34:g=g.resize((34,g.height),NEAREST)
    out.alpha_composite(g,(50,36 if frame==1 else 35))
    helmet_prone(out,(-2,-2) if frame==1 else (1,-1))
    return out

def crouch(recover=False):
    out=Image.new('RGBA',SIZE)
    # Original upper armor retains its proper upright, forward-facing visor.
    upper=Image.open(ART/'hero_body_idle_0_r.png').convert('RGBA').crop((0,0,84,44))
    if recover:
        # Lean into the recovery, with one planted boot under the shoulder.
        out.alpha_composite(upper,(1,8))
        rear=rig.armor_leg(0,(45,48),(38,65),False,knee=(36,56))
        front=rig.armor_leg(0,(49,48),(64,67),True,knee=(57,57))
    else:
        out.alpha_composite(upper,(0,9))
        rear=rig.armor_leg(0,(45,49),(38,66),False,knee=(39,57))
        front=rig.armor_leg(0,(49,49),(58,67),True,knee=(56,56))
    # Legs behind the upper body, but preserve the complete helmet and cape.
    stage=Image.new('RGBA',SIZE)
    stage.alpha_composite(rear)
    stage.alpha_composite(out)
    stage.alpha_composite(front)
    return stage

# All body-only sheets and corresponding complete sprites are maintained for
# the browser's independent-aim gun and for the earlier Godot companion.
for anim,count in {'idle':4,'run':8,'fire':3,'reload':3,'land':4,'hurt':3}.items():
    for i in range(count):
        old_rotation=rig.rotation
        def cape_rotation(layer,angle,pivot):
            return cape_wake(anim,i) if layer is rig.cape else old_rotation(layer,angle,pivot)
        rig.rotation=cape_rotation
        raw=rig.sprite(anim,i,with_gun=False)
        # Switch out cape's rigid rotated pixels for shoulder-anchored cloth.
        # Rig's first compositing pass drew the original cloth; don't paint a
        # second full cape on top. The legacy cape is retained as shading,
        # with a distinct gold hem streaming dynamically behind the stance.
        body=raw
        with_gun=rig.sprite(anim,i,with_gun=True)
        rig.rotation=old_rotation
        if anim=='run':
            # A modest 1px shoulder-height change makes the rifle follow the gait.
            pass
        for direction in ('r','l'):
            flip=lambda im:im if direction=='r' else im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            flip(body).save(ART/f'hero_body_{anim}_{i}_{direction}.png')
            flip(with_gun).save(ART/f'hero_{anim}_{i}_{direction}.png')

for i in range(4):
    for anim,frame in [('jump',i),('jet',i)]:
        # Jet keeps the tucked-air silhouette but has stronger cape lift and
        # a backpack thruster highlight.
        body=jumped(i,jet=anim=='jet')
        with_gun=jumped(i,gun=True,jet=anim=='jet')
        for direction in ('r','l'):
            flip=lambda im:im if direction=='r' else im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            flip(body).save(ART/f'hero_body_{anim}_{frame}_{direction}.png')
            flip(with_gun).save(ART/f'hero_{anim}_{frame}_{direction}.png')

for i in range(4):
    body= [crouch(False),prone(1),prone(2),crouch(True)][i]
    for direction in ('r','l'):
        flip=lambda im:im if direction=='r' else im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        flip(body).save(ART/f'hero_body_dive_{i}_{direction}.png')
        flip(body).save(ART/f'hero_dive_{i}_{direction}.png')

# Inspect all major stances at 3x native size with hand-checked silhouettes.
poses=[('IDLE','idle',0),('RUN A','run',0),('RUN B','run',2),('RUN C','run',4),('JUMP','jump',0),('APEX','jump',1),('FALL','jump',2),('JET','jet',3),('DIVE START','dive',0),('LAUNCH','dive',1),('PRONE','dive',2),('RECOVER','dive',3)]
W,H=252,252
sheet=Image.new('RGB',(W*4,H*3),(19,16,31));d=ImageDraw.Draw(sheet)
for n,(label,anim,idx) in enumerate(poses):
    sprite=Image.open(ART/f'hero_body_{anim}_{idx}_r.png').convert('RGBA')
    x=(n%4)*W;y=(n//4)*H
    d.rectangle((x+9,y+25,x+W-10,y+H-16),fill=(32,27,47))
    d.line((x+9,y+222,x+W-10,y+222),fill=(97,86,114),width=2)
    enlarged=sprite.resize((84*3,72*3),NEAREST)
    sheet.paste(enlarged,(x,y+16),enlarged)
    d.text((x+12,y+8),label,fill=(255,214,79))
sheet.save(ROOT/'PHASE2_POSE_CONTACT_SHEET.png')

strip=Image.new('RGBA',(84*8,72),(24,17,35,255))
for i in range(8):strip.alpha_composite(Image.open(ART/f'hero_run_{i}_r.png').convert('RGBA'),(i*84,0))
strip.save(ROOT/'ANIMATION_STRIP.png')
frames=[Image.open(ART/f'hero_run_{i}_r.png').convert('RGBA') for i in range(8)]
frames[0].save(ROOT/'RUN_CYCLE.gif',save_all=True,append_images=frames[1:],duration=85,loop=0,disposal=2,optimize=False)
print('Phase 2: 4 authored airborne, 4 forward-facing dive, 8 broader run poses + in-game frames')
