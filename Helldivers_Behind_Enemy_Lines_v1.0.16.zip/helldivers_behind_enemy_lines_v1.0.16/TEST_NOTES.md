# v1.0.14 — Liberty Day soundtrack validation

- Three original songs and title/victory/campaign/boss cue rules validated by `node tests/test_original_music.js`.
- `ffprobe` confirms stereo 48 kHz MP3 for Liberty Day; `ffmpeg` full decode returned no errors.
- Eight-area campaign, traversal, interface, atmosphere, player animation and mobile gesture regressions passed.
- iPad/phone landscape Chromium browser tests (`tests/test_phase5_touch.py`, `tests/test_phase3_browser.py`) passed.
- Native iPad Safari and Godot engine have not been run-tested.

---

# v1.0.13 — Phase 5 Validation

- New real-browser `tests/test_phase5_touch.py` verifies iPad touch defaults, left-handed mirroring, size/opacity, haptic and battery-saver options, touch music-volume sync, drag-to-steer input, reset, and compact landscape viewport fit. The test uses an in-memory localStorage shim because the test runner has an opaque document origin.
- `tests/test_mobile_gestures.py` and `tests/test_phase3_browser.py` passed after the changes.
- `tests/test_mobile_touch.py` passed once in isolation. On a later bulk-regression run it stalled; that run is not counted as a pass.
- All eight-area campaign, Act III traversal, character animation, rifle alignment, original music, phase 1 visuals, phase 3 UI, and phase 4 atmosphere JavaScript regressions passed.
- Physical iPad Safari, device-specific haptics, and battery runtime are unverified. Godot companion is an earlier prototype.

---

## v1.0.12 — Phase 4 Environmental Atmosphere

- `node tests/test_phase4_atmosphere.js`: PASS (8 animated scenes; world-space placement, stateful lighting and fixed collision rims; low-quality settings persistence).
- `python tests/test_phase4_browser.py`: PASS (desktop and mobile Chromium touch emulation, options UI, no browser page errors).
- `node tests/test_headless_canvas.js`, `node tests/test_act3_traversal.js`, `node tests/test_phase1_visual.js`, `node tests/test_phase2_animation.js`, `node tests/test_phase3_ui.js`, `node tests/test_original_music.js`, `node tests/test_gait_and_muzzle.js`: PASS.
- `python tests/test_hero_art.py`, `python tests/test_phase2_sprite.py`, `python tests/test_mobile_gestures.py`: PASS.
- Legacy `python tests/test_mobile_touch.py`: stalled in this environment, **not** claimed as passed.
- Physical iPad Safari and Godot engine are **not** verified.

---

## v1.0.11 Phase 3 Mission Interface verification

- `node tests/test_phase3_ui.js` — new / resume / confirm-overwrite menus, save preservation, pause actions, map freeze, objectives, notification status, saved accessibility preferences — PASS.
- `python tests/test_phase3_browser.py` — real headless Chromium pointer, keyboard, options, map, touch emulation including landscape viewport bounds, dialogue advancement — PASS.
- `node tests/test_headless_canvas.js` — eight-sector campaign and all **257/257** registered visual assets — PASS.
- `node tests/test_act3_traversal.js` — traverse gaps, objective locks and rescue ending — PASS.
- `node tests/test_original_music.js` — uninterrupted Cup of Liber-tea and boss overrides — PASS.
- `node tests/test_phase1_visual.js` — eight scene visual styles and collision consistency — PASS.
- `node tests/test_phase2_animation.js`, `node tests/test_gait_and_muzzle.js`, `python tests/test_phase2_sprite.py`, `python tests/test_hero_art.py` — PASS.
- `python tests/test_mobile_gestures.py`, `python tests/test_mobile_touch.py` — PASS in Chromium emulation (run individually).

Not verified on physical iPad/Safari. Godot engine integration beyond the older prototype is not tested.

---

## v1.0.10 Phase 2 character verification

- New `python tests/test_phase2_sprite.py`: all nine player animations, mirrored sides, 8 unique gait frames, 4 unique jump and dive frames, forward visor in prone poses, no contact shadow — PASS.
- New `node tests/test_phase2_animation.js`: in-game sprite selection during run, jump, jet, dive, fire and landing; rifle tracks 1px body bob; shots originate at rotated muzzle; actual Canvas screenshots — PASS.
- `python tests/test_hero_art.py`: existing sprite and gun asset checks — PASS.
- `node tests/test_gait_and_muzzle.js`: 7 aiming directions and run cycle — PASS.
- `node tests/test_headless_canvas.js`: campaign, levels, enemy AI, saves, progression — PASS.
- `node tests/test_phase1_visual.js`: 8 level palettes and layer separation — PASS.
- `node tests/test_act3_traversal.js`: all new traversal gaps and objective gates — PASS.
- `node tests/test_original_music.js`: continuous Cup of Liber-tea and boss override — PASS.
- `python tests/test_mobile_gestures.py`: simultaneous iPad-style pointer controls, gesture suppression — PASS.
- Not verified: iPad hardware Safari, full Godot engine playthrough; the Godot companion remains a partial prototype.

---

## v1.0.9 Phase 1 visual check

- All 257 declared visual assets loaded.
- `tests/test_headless_canvas.js`: 8-area story/save and game rendering PASS.
- `tests/test_phase1_visual.js`: 8-room styles, platform-edge RGB/contrast, no foreground occlusion pass, original room geometry PASS.
- `tests/test_act3_traversal.js`: gap traversal, doors, Shelter Twelve PASS.
- `tests/test_original_music.js`: continuous main theme and boss override PASS.
- `tests/test_gait_and_muzzle.js`: animation and rifle aim PASS.
- `tests/test_mobile_touch.py`, `tests/test_mobile_gestures.py`, `tests/test_hero_art.py`: PASS.
- Not verified: physical iPad Safari; Godot engine runtime.

---

# v1.0.8 — Verification Notes

PASS (automated, browser Canvas engine/source):

- `node tests/test_headless_canvas.js`: complete Act I/II flow, sentinel-to-transit handoff, all three new levels and Act III ending, checkpoints/save migration, enemy systems, and screenshots.
- All **257/257 declared visual assets** loaded, including three new scene backgrounds.
- `node tests/test_act3_traversal.js`: traversed every gap in Freight Conduit and Flooded Pumpworks with real run/jump physics (no teleports), reached Shelter Twelve, checked lock/quest gates, and restored saved chapter progress.
- `node tests/test_original_music.js`: continuous Cup of Liber-tea across exploration and ordinary combat, boss overrides, dialogue ducking, saved gain and mute.
- `node tests/test_gait_and_muzzle.js`: eight gait frames and weapon muzzle alignment.
- `python tests/test_hero_art.py`: jump/dive asset integrity.
- `python tests/test_mobile_gestures.py`: browser gesture suppression and simultaneous held touch controls.

Limitations: no physical iPad Safari playthrough or full live browser-navigation session in this environment. Godot companion is retained from Act II and has not received the new Act III content. The older `tests/test_mobile_touch.py` can hang in this environment and is excluded from the pass list.
