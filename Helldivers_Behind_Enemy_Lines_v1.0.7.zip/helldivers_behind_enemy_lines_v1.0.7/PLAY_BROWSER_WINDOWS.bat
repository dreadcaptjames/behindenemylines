@echo off
start "" "%~dp0browser-demo\index.html"
