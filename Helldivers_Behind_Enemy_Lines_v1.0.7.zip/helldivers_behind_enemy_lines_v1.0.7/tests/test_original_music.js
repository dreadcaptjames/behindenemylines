const fs=require('fs'),vm=require('vm'),path=require('path'),assert=require('assert');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'browser-demo/index.html'),'utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
for(const name of ['cup_of_liber_tea_combat.mp3','by_order_of_high_command_boss.mp3']){
  assert(fs.statSync(path.join(root,'audio',name)).size>2_000_000,`${name} should be playable audio`);
}
function element(){return {hidden:true,value:'70',textContent:'',setAttribute(){},addEventListener(){},append(){},focus(){}};}
const elems={game:{getContext:()=>({imageSmoothingEnabled:false}),getBoundingClientRect:()=>({left:0,top:0,width:960,height:540}),addEventListener(){},focus(){}},controlsPanel:element()};
const document={hidden:false,getElementById:id=>elems[id]||(elems[id]=element()),createElement:()=>element()};
class Audio {
  constructor(src){this.src=src;this.loop=false;this.volume=0;this.currentTime=0;this.readyState=4;this.playCount=0;this.seekCount=0;}
  play(){this.playCount++;return Promise.resolve()}
  cloneNode(){return this}
}
class Image {set src(v){this._src=v;this.naturalWidth=64;this.naturalHeight=64}}
class Gain {constructor(){this.gain={value:0}}connect(){}}
class AudioCtx {constructor(){this.state='running';this.destination={};this.currentTime=0;}createMediaElementSource(){return {connect(){}}}createGain(){return new Gain()}resume(){return Promise.resolve()}}
const saved=new Map();
const localStorage={getItem:k=>saved.has(k)?saved.get(k):null,setItem:(k,v)=>saved.set(k,String(v)),removeItem:k=>saved.delete(k)};
const env=vm.createContext({console,Math,Set,Map,Audio,Image,document,window:{AudioContext:AudioCtx,addEventListener(){}},navigator:{getGamepads:()=>[]},localStorage,requestAnimationFrame(){},performance:{now:()=>0},Date});
vm.runInContext(js,env,{filename:'browser-demo/index.html'});
const run=s=>vm.runInContext(s,env);
const near=(a,b,margin=.015)=>Math.abs(a-b)<margin;
(async()=>{
  assert(run("musicTracks.main.src.endsWith('cup_of_liber_tea_combat.mp3')"));
  assert(run("musicTracks.boss.src.endsWith('by_order_of_high_command_boss.mp3')"));
  assert(near(run('musicMaster'),.7),'default level 70%');
  assert(run('musicCue')==='main','Cup of Liber-tea is the default song');
  run('startMusic()');
  assert(run('musicStarted'),'music unlocked by user gesture');
  assert(run('Object.keys(musicGains).length')===2,'WebAudio gain mixer is enabled for both originals');
  assert(run('Object.values(musicTracks).every(a=>a.playCount===1)'),'music streams start together to maintain stable playheads');
  run('reset();state="playing";enem=[];adaptiveMusic(.5)');
  assert(run('musicCue')==='main','main soundtrack plays while exploring');
  assert(run('musicGains.main.gain.value')>0,'Cup audible during exploration');
  run('musicTracks.main.currentTime=41');
  run('enem=[{kind:"walker",hp:2,x:p.x+90,alert:3}];for(let i=0;i<360;i++)adaptiveMusic(.016)');
  assert(run('musicCue')==='main','ordinary combat does not switch tracks');
  assert(run('musicTracks.main.currentTime')===41,'ordinary combat never seeks or restarts main theme');
  run('enem=[];for(let i=0;i<360;i++)adaptiveMusic(.016)');
  assert(run('musicCue')==='main','leaving combat does not change music');
  assert(run('musicTracks.main.currentTime')===41,'after combat, main theme retains playhead');
  run('musicTracks.boss.currentTime=29;enem=[{kind:"warden",hp:10,x:p.x+50,alert:1}];bossAwake=true;adaptiveMusic(.5)');
  assert(run('musicCue')==='boss','boss-specific track selected');
  assert(run('musicTracks.boss.currentTime')===0,'boss track starts at its opening');
  assert(run('musicTracks.main.currentTime')===41,'main theme continues underneath boss music');
  run('enem[0].x=p.x+550;for(let i=0;i<250;i++)adaptiveMusic(.016)');
  assert(run('musicCue')==='boss','boss cue does not thrash at proximity boundary');
  run('enem[0].hp=0;for(let i=0;i<500;i++)adaptiveMusic(.016)');
  assert(run('musicCue')==='main','main theme resumes after boss ends');
  assert(run('musicTracks.main.currentTime')===41,'main theme resumes without restarting song');
  for(let i=0;i<120;i++)run('adaptiveMusic(.016)');
  const normal=run('musicGains.main.gain.value');
  run('state="dialogue";for(let i=0;i<120;i++)adaptiveMusic(.016)');
  assert(run('musicGains.main.gain.value')<normal*.5,'radio ducks music');
  run('musicMaster=.3;localStorage.setItem("bel_music_master",String(musicMaster));state="playing";adaptiveMusic(.5)');
  assert(saved.get('bel_music_master')==='0.3','volume persisted');
  run('musicOn=false;for(let i=0;i<200;i++)adaptiveMusic(.016)');
  assert(near(run('musicGains.main.gain.value'),0,.003),'mute fades main theme to silence');
  assert(near(run('musicGains.boss.gain.value'),0,.003),'mute fades boss theme to silence');
  console.log('PASS: continuous Cup of Liber-tea through exploration/combat, boss-only transitions, no main-theme restart, WebAudio gains, ducking, volume, mute');
})().catch(e=>{console.error(e);process.exitCode=1});
