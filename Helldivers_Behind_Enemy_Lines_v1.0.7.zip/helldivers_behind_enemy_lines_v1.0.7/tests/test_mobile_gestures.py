from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parents[1]
css=(root/'mobile/touch-controls.css').read_text()
js=(root/'mobile/touch-controls.js').read_text()
fixture='''<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover"></head><body><header></header><div id="shell" style="position:relative;width:960px;height:540px"><canvas id="game" style="width:960px;height:540px"></canvas><section id="controlsPanel" hidden></section></div><script>
let state='playing',p={x:135,y:228},camera=0,mouseDown=false,mouseX=0,mouseY=0,mouseSeen=0,clock=1,musicOn=false,comms=false,emp=false,stratMode=false;
const bindings={moveLeft:'a',moveRight:'d',jump:' ',reload:'r',dive:'shift',interact:'e',stratagem:'q',pulse:'g',map:'m'};
const __held=new Set(),__events=[];
window.addEventListener('keydown',e=>{__held.add(e.key);__events.push('down:'+e.key)});
window.addEventListener('keyup',e=>{__held.delete(e.key);__events.push('up:'+e.key)});
function hasSave(){return false}
</script></body></html>'''
with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
  ctx=browser.new_context(viewport={'width':1180,'height':820},screen={'width':1180,'height':820},is_mobile=True,has_touch=True)
  page=ctx.new_page(); errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(fixture,wait_until='domcontentloaded');page.add_style_tag(content=css);page.add_script_tag(content=js)
  page.wait_for_timeout(100)
  print('touch:',page.locator('body').get_attribute('class'),'no selection',page.evaluate("getComputedStyle(document.querySelector('#tcDpad')).webkitUserSelect"))
  assert page.locator('body').get_attribute('class').find('bel-touch-active')!=-1
  for evt in ('selectstart','dblclick','gesturestart','contextmenu','dragstart','touchstart','touchmove'):
   result=page.eval_on_selector('#tcDpad button[data-key="arrowright"]',f'''(el) => {{const e=new Event('{evt}',{{bubbles:true,cancelable:true}});el.dispatchEvent(e);return e.defaultPrevented}}''')
   print(evt, result)
   assert result,evt+' was not blocked'
  # Two simultaneous touch pointers work independently, without fighting native gesture actions.
  page.locator('#tcDpad button[data-key="arrowright"]').dispatch_event('pointerdown',{'button':0,'pointerId':7,'pointerType':'touch','isPrimary':True})
  page.locator('#tcActions button[data-action="jump"]').dispatch_event('pointerdown',{'button':0,'pointerId':8,'pointerType':'touch','isPrimary':False})
  print('held',page.evaluate('Array.from(__held)'))
  assert set(page.evaluate('Array.from(__held)'))=={'arrowright',' '},'multi-touch keys not held'
  page.locator('#tcDpad button[data-key="arrowright"]').dispatch_event('pointerup',{'button':0,'pointerId':7,'pointerType':'touch'})
  print('held after right release',page.evaluate('Array.from(__held)'))
  assert set(page.evaluate('Array.from(__held)'))=={' '}
  page.locator('#tcActions button[data-action="jump"]').dispatch_event('pointerup',{'button':0,'pointerId':8,'pointerType':'touch'})
  assert page.evaluate('__held.size')==0
  # Touch-off should release held control and stop suppressing gestures
  page.locator('#tcDpad button[data-key="arrowright"]').dispatch_event('pointerdown',{'button':0,'pointerId':9,'pointerType':'touch'})
  page.locator('#belTouchToggle').click()
  assert page.evaluate('__held.size')==0
  assert page.locator('body').get_attribute('class').find('bel-touch-active')==-1
  result=page.eval_on_selector('#tcDpad button[data-key="arrowright"]','(el) => {const e=new Event("dblclick",{bubbles:true,cancelable:true});el.dispatchEvent(e);return e.defaultPrevented}')
  assert not result
  print('PASS: mobile touch gestures blocked in play mode, multi-touch held correctly, touch-off unlocks browser behavior; errors',errors)
  assert not errors
  browser.close()
