# HELLDIVERS: BEHIND ENEMY LINES — v1.0.7

## Original soundtrack — continuous main theme

Two original compositions supplied by the project owner are included as browser-optimized 192 kbps MP3 files:

| Gameplay | Music | Browser filename |
| --- | --- | --- |
| Exploration, travel, and normal enemy fights | **Cup of Liber-tea** — continuous main theme | `audio/cup_of_liber_tea_combat.mp3` |
| Warden and Sentinel boss battles | **By Order of High Command** — rare boss override | `audio/by_order_of_high_command_boss.mp3` |

The main theme continues playing without restarting between encounters. Only bosses trigger crossfades, with a longer hold to prevent soundtrack changes at boss-area boundaries. Radio dialogue ducks the music; pause/background silences it, while title/victory are quieter. The music toggle and a new volume slider save their settings locally. On iPad, a Web Audio gain mixer provides audio levels independently of Safari's hardware volume restrictions. Music starts after a user gesture due to browser autoplay rules.

The complete original compositions have not been arbitrarily shortened for a cue. A short 2.5-second seam overlap makes replay boundaries less abrupt, though this is not a tempo-matched stem arrangement. The original WAV masters are **not included in the public game ZIP**; only optimized in-game derivatives are bundled. This prevents unnecessary downloads and preserves the source masters separately.

**To play:** Extract the ZIP and open `browser-demo/index.html` on desktop; or upload the complete ZIP to the repository root so the GitHub Pages workflow publishes it. Sound starts with first gameplay interaction. The existing mobile controls and game saves are preserved.

---

# HELLDIVERS: BEHIND ENEMY LINES — v1.0.5

**Movement & Automaton Scale Pass** | Unofficial fan-made prototype.

## Changes in this release

- Four new painted jump poses, selected by ascent, apex, descent and fall velocity; jump-jet art shares the corrected, tighter leg pose.
- Tactical dive is now a proper movement sequence: crouch, launch, airborne travel and recovery, with real horizontal and vertical velocity and a lower collision silhouette while airborne.
- Bigger, class-specific Automaton bodies. Troopers and Marauders are roughly Helldiver-height; Devastators, Berserkers and Scout Striders are taller. Fixed turrets and drones deliberately retain their smaller specialist silhouettes.
- Enemy hitboxes, optics, line-of-sight checks, projectile origins and melee reach use matching scale profiles, avoiding oversized art with tiny hitboxes.
- The existing v1.0.4 atmosphere, corrected rifle muzzle alignment, iPad controls, music toggle, saves, and two-act campaign remain intact.

## Launch

Extract the ZIP, then open `browser-demo/index.html` in a modern browser. On touchscreen devices, rotate to landscape for easier two-thumb controls. Touch controls are in `mobile/`.

Keyboard: A/D move, Space jump, Shift dive, mouse aim + fire, F fire, E interact, R reload, Q stratagem, G EMP, M map.

## Testing

Verified here: browser Canvas campaign and rendering tests, state-based dive trajectory tests, four-stage airborne sprite loading, hitbox/scale tests, rifle muzzle tests, artwork checks and touch gesture tests. The Godot companion (`project.godot`) has been updated to use matching sprites, animation states and sizes, but **has not been executed in Godot** in this environment.

## Public deployment

The full release ZIP is designed for your repository `dreadcaptjames/behindenemylines`; uploading this ZIP intact to the repository root and committing to `main` makes it a deployment candidate for the configured GitHub Pages workflow. It is **not automatically uploaded or deployed** by generating this package.

This fan project is not affiliated with Arrowhead or Sony. Public use of the Helldivers setting and marks may require permission.
