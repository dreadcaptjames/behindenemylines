# v1.0.7 — Continuous Main Theme

- **Cup of Liber-tea** now loops throughout exploration and ordinary combat, with no transitions when enemies appear/disappear.
- **By Order of High Command** is reserved for Warden and Sentinel boss encounters. The boss cue holds for 6.5 seconds after losing proximity to avoid repeated changes near encounter boundaries.
- The main theme's playhead is never reset when entering or leaving a fight; it continues quietly behind boss music and returns smoothly.
- Radio dialogue continues to duck the active track; pause and background tabs remain silent; music volume/toggle and iPad touch audio remain intact.
- Updated the Godot companion music policy and the browser music tests. Browser media playback still requires a user gesture on iPad.

---

# v1.0.6 — Original Soundtrack Integration

- Added `Cup of Liber-tea` as the combat composition and `By Order of High Command` for the Warden/Sentinel bosses.
- Converted original stereo WAV masters into optimized, crossfade-seamed 192 kbps MP3 game assets.
- Kept the quieter existing exploration underscore, with dynamic fades between music states and radio-dialogue ducking.
- Added master music level slider (browser storage) alongside the existing music toggle.
- Added a Web Audio gain mixer for reliable iPad Safari volume control after user input.
- Updated Godot companion music source references (engine runtime unverified).
- Preserved v1.0.5 movement, dive, Automaton scale, and touch controls.

---

# v1.0.5 — Movement and Automaton Scale

- Added 4 painted jump keyframes, improved jump-jet posing, and 4 dedicated dive keyframes for right/left facings.
- Dive action now has crouch, airborne launch, travel, recovery, and matching horizontal/vertical momentum.
- Replaced the old dive's upright sprite/shifting behavior with a horizontal prone pose and dynamic collision box.
- Scaled 7 Automaton ground-unit variants and coordinated enemy hitboxes, threat detection, optics, firing positions and melee ranges.
- Kept drones and turrets smaller by design and preserved existing Hulk-class bosses.
- Preserved browser touch controls, save compatibility, two-act progression, character rifle aim and environmental depth fixes.
- Updated editable Godot companion; engine execution remains unverified.
