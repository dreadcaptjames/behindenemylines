# v1.0.7 — Continuous Main Theme

The original track **Cup of Liber-tea** is now the full-time main soundtrack. It plays seamlessly throughout exploration, regular combat, and travel, without switching at enemy detection or room boundaries.

**By Order of High Command** is still the dedicated boss track for Warden and Reactor Sentinel fights. Those rare transitions crossfade and retain a 6.5-second boss-zone hold to avoid rapid toggles. The main track's underlying playback never restarts when it fades back after a boss.

Dialogue ducks the music. The title/victory screens use a lower level; pausing or switching browser tabs silences music without resetting its playhead. Existing music toggle and volume preference are kept.

Browser: soundtrack selection and playhead continuity unit tests, complete campaign regression, movement/rifle checks and mobile gesture tests passed. The standalone legacy Playwright mobile-touch scenario timed out in the testing environment; physical iPad playback is not verified. Godot audio logic is updated but cannot be engine-tested here.

The complete package includes both compressed licensed-by-project-owner songs and all game sources. The original master WAV files are not part of the public download.
