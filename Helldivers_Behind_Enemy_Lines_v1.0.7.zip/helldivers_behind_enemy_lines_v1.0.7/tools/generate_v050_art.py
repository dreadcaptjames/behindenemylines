"""Draw entirely original low-resolution industrial backgrounds and foes for v0.5.0.
Pillow only. Run from anywhere; output is anchored relative to this file.
"""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import random, math
ART=Path(__file__).resolve().parents[1]/'art';ART.mkdir(parents=True,exist_ok=True)
R=random.Random(50731)
PURPLE='#140f23';INK='#0b0a16';TARNISH='#5c4368';BRASS='#d4a536';GOLD='#ffcf42';CYAN='#63cbd5';RUST='#a94e3b'
def bg(theme):
    w,h=480,270;im=Image.new('RGBA',(w,h),(10,8,20,255));d=ImageDraw.Draw(im)
    color='#10202a' if theme=='blacksite' else '#201529'
    d.rectangle((0,42,w,269),fill=color)
    # deep machinery and vaults
    for i in range(24):
        x=i*26-13;d.rectangle((x,28,x+19,227),fill='#111522' if theme=='blacksite' else '#21172a')
        d.rectangle((x+4,52,x+12,227),fill='#202b37' if theme=='blacksite' else '#34283b')
        for y in range(67,211,33):
            d.rectangle((x+5,y,x+10,y+17),fill='#122630' if theme=='blacksite' else '#3a203a')
            d.rectangle((x+6,y+3,x+8,y+10),fill='#2d5960' if theme=='blacksite' else '#795541')
    # Architecture of high vaults
    for x in range(14,560,108):
        d.rectangle((x-3,25,x+10,226),fill='#2e303d' if theme=='blacksite' else '#342737')
        d.rectangle((x+3,30,x+5,228),fill='#766676' if theme=='blacksite' else '#695364')
        d.rectangle((x-7,30,x+15,38),fill='#5a495c')
        d.line((x+5,44,x+74,95,x+78,226),fill='#53495b',width=4)
        d.line((x+5,44,x+74,95,x+78,226),fill='#181521',width=1)
        for y in (62,108,156,199):
            d.rectangle((x+4,y,x+6,y+4),fill=BRASS)
    # cable troughs
    for y in (48,55,119):
        d.line([(0,y),(80,y+6),(171,y+3),(260,y+8),(350,y+2),(480,y+5)],fill='#0b111c',width=5)
        d.line([(0,y),(80,y+6),(171,y+3),(260,y+8),(350,y+2),(480,y+5)],fill='#665567',width=1)
    # Hangar distant consoles and glow windows
    for i in range(7):
        x=23+i*75; y=125+(i*13)%43
        d.rectangle((x,y,x+43,y+51),fill='#090e1b')
        d.rectangle((x+3,y+3,x+40,y+45),outline='#665467',width=2)
        d.rectangle((x+7,y+8,x+29,y+26),fill='#184251' if theme=='blacksite' else '#512e3f')
        for j in range(4):
            d.rectangle((x+8+j*7,y+31,x+10+j*7,y+33),fill=CYAN if theme=='blacksite' else GOLD)
    # deep lower shadow and hazard markings
    d.rectangle((0,225,w,269),fill='#151322')
    for x in range(0,w,21):
        d.rectangle((x,230,x+18,233),fill='#41374a')
        d.rectangle((x+4,242,x+9,244),fill='#867381')
        d.line((x+1,255,x+7,252),fill='#b18330',width=2)
    if theme=='reactor':
        # The enormous reactor core is part of the background and persists as an intimidating silhouette
        d.ellipse((290,8,468,240),fill='#080c18',outline='#624e6e',width=6)
        d.ellipse((314,18,445,221),fill='#291c30',outline='#b17b38',width=5)
        for i in range(10):
            y=36+i*18
            d.line((324,y,437,y),fill='#684a53',width=2)
        d.polygon([(373,42),(415,86),(403,177),(355,194),(332,131)],fill='#471e35')
        d.polygon([(375,57),(396,90),(391,160),(364,178),(350,123)],fill='#eb6a36')
        d.polygon([(375,73),(389,101),(384,147),(369,159),(362,124)],fill='#ffdb6a')
        d.line((345,110,436,100),fill='#ffde70',width=2)
        for i in range(4):
            d.rectangle((300+i*33,203,312+i*33,224),fill='#31242f',outline='#c58e44',width=2)
    else:
        d.rectangle((330,85,477,206),fill='#10232d',outline='#696173',width=5)
        d.rectangle((348,101,458,184),fill='#183f4b')
        for i in range(8):
            d.line((350,111+i*10,456,111+i*10),fill='#34707c',width=2)
        d.text((356,132),'D-9',fill='#75d0d3')
        for i in range(4):d.rectangle((350+i*24,193,360+i*24,197),fill='#e4ab38')
    im.save(ART/f'{theme}_bg.png')

bg('blacksite')
bg('reactor')

def drone(frame,flip):
    im=Image.new('RGBA',(52,48));d=ImageDraw.Draw(im)
    # micro silhouette, cyan camera, alternating rotor flares
    yoff=2 if frame%2 else 0
    d.polygon([(11,24+yoff),(4,16+yoff),(16,12+yoff),(23,19+yoff),(28,11+yoff),(40,11+yoff),(48,23+yoff),(39,33+yoff),(14,33+yoff)], fill='#130e1b')
    d.polygon([(13,21+yoff),(18,14+yoff),(36,14+yoff),(43,22+yoff),(36,30+yoff),(17,30+yoff)],fill='#554563')
    d.rectangle((20,17+yoff,34,27+yoff),fill='#231929',outline='#9b839a')
    d.rectangle((25,19+yoff,33,24+yoff),fill='#71e0de')
    d.rectangle((28,19+yoff,31,21+yoff),fill='#fafffa')
    for x in (8,40):
        d.rectangle((x,21+yoff,x+5,26+yoff),fill='#d0a036')
        d.polygon([(x,17+yoff),(x+6,17+yoff),(x+9,11+yoff),(x-3,11+yoff)],fill='#e7ac42' if frame%2 else '#986a40')
        d.rectangle((x-2,32+yoff,x+7,34+yoff),fill='#392d42')
    d.rectangle((18,28+yoff,22,33+yoff),fill='#a94e38')
    d.rectangle((34,28+yoff,38,33+yoff),fill='#a94e38')
    if flip:im=im.transpose(Image.Transpose.FLIP_LEFT_RIGHT)
    return im
for f in range(4):
    for s in ('r','l'):drone(f,s=='l').save(ART/f'drone_{f}_{s}.png')

# Sentinel: 112x106 heavy biomechanical guardian, gold trim and molten red power cells
im=Image.new('RGBA',(112,106));d=ImageDraw.Draw(im)
d.rectangle((39,11,75,40),fill=INK)
d.polygon([(27,28),(44,15),(76,15),(90,29),(89,81),(75,92),(38,91),(23,78)],fill='#0c0b17')
d.polygon([(39,20),(72,20),(83,31),(80,68),(69,85),(43,85),(32,68),(31,36)],fill='#494052')
d.polygon([(46,23),(68,23),(77,32),(75,56),(70,71),(44,71),(38,56),(39,32)],fill='#272032')
d.polygon([(54,30),(68,32),(70,50),(55,54),(44,45),(45,34)],fill='#d3583a')
d.polygon([(55,34),(65,35),(66,45),(55,50),(48,42)],fill='#ffe070')
d.rectangle((45,60,70,65),fill='#ab8654')
d.rectangle((49,61,66,63),fill='#fff4ae')
for flip in (False,True):
    x=9 if not flip else 76
    d.polygon([(x,29),(x+20,18),(x+27,33),(x+22,63),(x+8,74),(x-1,62)],fill='#120f1d')
    d.polygon([(x+5,34),(x+18,26),(x+22,36),(x+16,56),(x+4,62)],fill='#6e596d')
    d.rectangle((x+7,44,x+15,49),fill='#eac047')
    d.polygon([(x+7,68),(x+17,69),(x+20,100),(x+3,101)],fill='#120e19')
    d.polygon([(x+8,70),(x+15,71),(x+16,91),(x+6,93)],fill='#6e5b6c')
    d.rectangle((x+5,94,x+19,101),fill='#c8a342')
    d.rectangle((x+3,101,x+21,104),fill='#120e1d')
for y in (26,78):
    d.rectangle((34,y,42,y+3),fill='#bd9431');d.rectangle((74,y,82,y+3),fill='#bd9431')
d.rectangle((49,76,63,88),fill='#1a1723',outline='#9c7842',width=2)
d.rectangle((53,79,60,83),fill='#fbc64b')
im.save(ART/'sentinel.png')
# crisp upgrade icon
im=Image.new('RGBA',(16,16));d=ImageDraw.Draw(im)
d.polygon([(7,0),(11,5),(8,5),(12,10),(7,15),(8,9),(4,9),(6,5),(3,5)],fill='#65dce0')
d.polygon([(7,2),(9,6),(6,8),(9,9),(7,13),(7,9),(5,9)],fill='#fff6b4')
im.save(ART/'icon_emp.png')
# reactor status icon
im=Image.new('RGBA',(16,16));d=ImageDraw.Draw(im)
d.ellipse((1,1,14,14),outline='#d6a63b',width=2);d.ellipse((5,5,10,10),fill='#f97048');d.line((7,0,7,3),fill='#fff29d',width=2)
im.save(ART/'icon_reactor.png')
print('wrote new original v0.5.0 art assets to',ART)
