from PIL import Image, ImageDraw
from pathlib import Path
import numpy as np, wave, math, subprocess, tempfile, os
root=Path(__file__).resolve().parents[1]
art=root/'art'; audio=root/'audio'
# Portraits: original intentionally low-res, nearest-neighbor artwork.
P={'command':('#1c1426','#ffcf35','#fd9f29','#483b53'),'survivor':('#122530','#65e4d4','#a4e8f2','#3c6572'),'automaton':('#1d1324','#fa5149','#fb8470','#4c3643'),'helldiver':('#1b1627','#facd35','#ffa331','#53495e')}
for typ,(bg,accent,glow,arm) in P.items():
    im=Image.new('RGBA',(64,64),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.rectangle((0,0,63,63),fill=bg)
    for yy in range(2,64,9):d.line((0,yy,63,yy),fill='#302a3b' if typ!='survivor' else '#193540',width=1)
    d.polygon([(6,63),(12,41),(25,35),(39,35),(54,45),(62,63)],fill=arm,outline='#0b0b13')
    d.rectangle((12,48,52,62),fill='#262333' if typ!='survivor' else '#244650')
    d.rectangle((29,47,35,56),fill=accent)
    if typ=='automaton':
        d.rectangle((17,16,47,43),fill='#48404d',outline='#05050a',width=3)
        d.rectangle((22,23,42,34),fill='#101015');d.rectangle((22,25,28,31),fill='#f84f36');d.rectangle((36,25,42,31),fill='#f84f36')
        d.rectangle((19,40,45,43),fill='#b75740')
        d.polygon([(17,16),(31,9),(47,16)],fill='#68616b')
    elif typ=='survivor':
        d.polygon([(14,19),(21,12),(42,12),(50,21),(44,45),(20,45)],fill='#232c39',outline='#080d16',width=2)
        d.rectangle((20,25,45,34),fill='#477882');d.rectangle((22,27,43,31),fill=glow)
        d.rectangle((29,35,35,42),fill='#143541');d.rectangle((13,42,18,52),fill=accent)
    else:
        d.polygon([(15,20),(22,9),(40,10),(50,21),(46,41),(19,41)],fill='#433c55',outline='#08070e',width=3)
        d.line((29,10,39,19),fill=accent,width=4)
        d.polygon([(20,24),(46,23),(43,35),(22,35)],fill='#1a1318')
        d.rectangle((23,26,43,33),fill=glow);d.rectangle((30,26,35,32),fill='#fff9bc')
        d.rectangle((25,38,40,44),fill='#1a1520')
        d.rectangle((11,21,15,35),fill=accent);d.rectangle((47,20,51,34),fill=accent)
        d.polygon([(11,50),(22,46),(29,55),(25,61),(8,61)],fill=accent)
        d.polygon([(52,50),(43,46),(37,55),(40,61),(56,61)],fill=accent)
    d.line((2,2,61,2),fill=accent,width=2)
    im.save(art/f'radio_{typ}.png')
# Extra animation with same 80x64 source proportions and pixel grid.
for side in ['r','l']:
    idle=Image.open(art/f'hero_idle_0_{side}.png').convert('RGBA'); run=Image.open(art/f'hero_run_2_{side}.png').convert('RGBA'); dive=Image.open(art/f'hero_dive_1_{side}.png').convert('RGBA')
    for f in range(4):
        im=Image.new('RGBA',(80,64))
        squish=[0,3,2,0][f]
        src=[run,idle,idle,run][f]
        src=src.resize((80,64-squish),Image.Resampling.NEAREST)
        im.alpha_composite(src,(0,squish))
        d=ImageDraw.Draw(im)
        if f in [0,1]:
            for j in range(5):
                x=22+j*9+(f%2*2);y=57+(j%2)*2
                d.rectangle((x,y,x+2,y+1),fill='#b29a87' if j%2 else '#e1bd54')
        im.save(art/f'hero_land_{f}_{side}.png')
    for f in range(3):
        im=idle.copy();d=ImageDraw.Draw(im)
        edge='#ff563c' if f%2==0 else '#faaf72'
        d.line([(19,6),(32,3),(43,7)],fill=edge,width=2)
        d.line([(14,47),(20,52),(28,54)],fill=edge,width=1)
        for j in range(4):
            x=19+(j*11+f*5)%48;y=8+(j*17)%44
            d.rectangle((x,y,x+2,y+2),fill=edge)
        im.save(art/f'hero_hurt_{f}_{side}.png')
# Small original tactical detail decals: CRT warning screens and abandoned evacuation supplies.
im=Image.new('RGBA',(96,64));d=ImageDraw.Draw(im)
d.rectangle((0,45,96,64),fill='#120d17')
d.polygon([(8,19),(29,12),(80,21),(90,45),(10,45)],fill='#2b283b',outline='#70616a')
d.rectangle((20,24,76,38),fill='#131d25',outline='#659890',width=2)
d.text((25,26),'SOS',fill='#8bedd2')
d.rectangle((6,49,32,62),fill='#575163',outline='#bc8a43',width=2)
d.rectangle((45,48,63,62),fill='#4f3541',outline='#947b83')
for x in [14,23,51,58]:d.rectangle((x,51,x+3,54),fill='#dfb542')
im.save(art/'evidence_terminal.png')
# Synthesize original seamless dark ambient score + adaptive combat/reaction layers.
fs=22050; tempo=96; beat=60/tempo; dur=32*beat; n=int(round(dur*fs)); t=np.arange(n)/fs
rng=np.random.default_rng(407)
def sine(f):return np.sin(2*np.pi*f*t)
def smooth(x,k):
    return np.convolve(x,np.ones(k)/k,'same')
def pad(freq,vol):
    # layered detuned partials and slow tremolo; near periodic over 20-second loop
    return vol*(.58*sine(freq)+.19*sine(freq*.998)+.14*sine(freq*2)+.09*sine(freq*3))
def envpulse(t0,length=.55):
    dt=(t-t0)%dur;return np.where(dt<length,np.exp(-dt*6)*np.sin(np.minimum(1,dt/.012)*np.pi/2),0)
# All waves sum into original loopable soundscapes. Remove tiny boundary clicks with wrap blend.
base=np.zeros(n); root_notes=[73.42,87.31,65.41,82.41]  # D2 F2 C2 E2
for bar in range(8):
    f=root_notes[bar%4]; start=bar*4*beat
    phase=(t-start)/beat
    # eight-beat bar-long synthesized chord that fades at ends
    mask=(t>=start)&(t<start+4*beat)
    e=np.sin(np.clip((t-start)/(4*beat),0,1)*np.pi)**.35*mask
    base+=e*(pad(f,.17)+pad(f*1.5,.075)+pad(f*2.002,.042))
# continuous filtered turbulence and metallic industrial oscillator
noise=rng.normal(0,.045,n)
noise=smooth(noise,65)
base+=.7*noise+ .022*sine(29.1)*(0.5+0.5*np.sin(2*np.pi*t/dur))
base+=.03*np.sin(2*np.pi*2*t)*(np.sin(2*np.pi*43*t))
# combat: kit plus hammer-like low kicks, snare harmonics, repeating brass tones
combat=np.zeros(n)
for b in range(32):
    s=b*beat
    tt=(t-s)%dur
    k=np.where(tt<.22,np.sin(2*np.pi*(68*tt-75*tt*tt))*np.exp(-tt*24),0)
    combat+=.14*k*(1.2 if b%4==0 else .55)
    if b%4 in [1,3]:
        hh=rng.normal(0,.05,n); hh=smooth(hh,5)
        combat+=np.where(tt<.12, hh*np.exp(-tt*35),0)
    if b%2==0:
        combat+=np.where(tt<.08,rng.normal(0,.012,n)*np.exp(-tt*53),0)
for bar in range(8):
    s=bar*4*beat; tt=(t-s)%dur
    mask=(tt<4*beat)&(t>=s)
    f=[146.83,174.61,130.81,164.81][bar%4]
    combat+=np.where(mask,.053*np.sin(2*np.pi*f*tt)*(0.65+0.35*np.sin(2*np.pi*tt/(beat*2))),0)
combat+=.065*sine(36.7)*(0.4+0.6*(np.sin(np.pi*t/beat)**8))
# boss: darker, more massive, with repeated mechanical accents
boss=np.zeros(n)
for b in range(32):
    tt=(t-b*beat)%dur
    boss+=np.where(tt<.24,.22*np.sin(2*np.pi*(62*tt-62*tt*tt))*np.exp(-tt*22),0)
    if b%2==1:
        boss+=np.where(tt<.29,.052*rng.normal(0,1,n)*np.exp(-tt*21),0)
boss+=.095*sine(55.0)*(0.6+0.4*np.cos(2*np.pi*t/(beat*4)))
boss+=.045*sine(110.05)+.028*sine(164.8)
# Stereo wide pseudo-echo with periodic sample offset for each original stem.
for name,signal in [('ambient_loop',base),('combat_loop',combat),('boss_loop',boss)]:
    k=int(.017*fs); left=signal;right=.92*np.roll(signal,k)
    stereo=np.stack([left,right],axis=1)
    # very short boundary fade applies equally to end/start (smooth loop seam)
    fade=round(.027*fs); st=stereo.copy()
    for i in range(fade):
        blend=(i+1)/fade
        st[i]=st[i]*blend+st[n-fade+i]*(1-blend)
    stereo=st
    stereo=np.tanh(stereo*1.3)*.55
    tmp=audio/(name+'.wav')
    with wave.open(str(tmp),'wb') as w:
        w.setnchannels(2);w.setsampwidth(2);w.setframerate(fs);w.writeframes((stereo*32767).astype('<i2').tobytes())
    subprocess.run(['ffmpeg','-loglevel','error','-y','-i',str(tmp),'-c:a','libvorbis','-qscale:a','4',str(audio/(name+'.ogg'))],check=True)
    tmp.unlink()
# short original warning/mission cues
def cue(name,f,seconds,beeps):
    n2=int(seconds*fs); tt=np.arange(n2)/fs; sig=np.zeros(n2)
    for at,length,mult in beeps:
        tau=tt-at;mask=(tau>=0)&(tau<length)
        env=np.where(mask,np.minimum(1,tau/.005)*np.minimum(1,(length-tau)/.04),0)
        sig+=.23*env*(np.sin(2*np.pi*f*mult*tau)+.28*np.sin(2*np.pi*f*2.01*mult*tau))
    with wave.open(str(audio/f'{name}.wav'),'wb') as w:
        w.setnchannels(1);w.setsampwidth(2);w.setframerate(fs);w.writeframes((np.clip(sig,-1,1)*32767).astype('<i2').tobytes())
cue('radio_chirp',820,.32,[(0,.07,1),(.1,.07,1.2),(.20,.065,1.5)])
cue('enemy_warning',310,.6,[(0,.15,1),(.2,.15,.75),(.4,.12,.6)])
print('generated asset bytes',[(x.name,x.stat().st_size) for x in audio.glob('*loop*.ogg')])
