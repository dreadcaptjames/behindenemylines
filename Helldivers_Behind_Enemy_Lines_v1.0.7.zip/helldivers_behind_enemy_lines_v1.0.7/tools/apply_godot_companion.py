"""Mirror v1.0.5 browser movement and unit proportions in the editable Godot companion."""
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
p=ROOT/'scripts/game.gd';s=p.read_text()

def replace(old,new,name):
 global s
 if old not in s:raise RuntimeError('Cannot locate '+name)
 s=s.replace(old,new,1)

s=s.replace('v1.0.4','v1.0.5')
# Copy body keyframes so Godot's existing full/overlay sprite loader has a valid texture.
from shutil import copyfile
for i in range(1,4):
 for side in ['r','l']:
  copyfile(ROOT/f'art/hero_body_jump_{i}_{side}.png',ROOT/f'art/hero_jump_{i}_{side}.png')
for i in range(2,4):
 for side in ['r','l']:
  copyfile(ROOT/f'art/hero_body_dive_{i}_{side}.png',ROOT/f'art/hero_dive_{i}_{side}.png')
replace('elif animation in ["idle", "jet", "land"]:', 'elif animation in ["idle", "jet", "land", "jump", "dive"]:', 'load new animation counts')
replace('''		elif animation == "dive":
			count = 2
''','', 'old dive count')
replace('var dash_timer: float = 0.0','var dash_timer: float = 0.0\nvar dash_direction: int = 1\nvar dash_launched: bool = false','dive vars')
replace('dash_timer = 0.0\n\tdash_cooldown = 0.0','dash_timer = 0.0\n\tdash_direction = 1\n\tdash_launched = false\n\tdash_cooldown = 0.0','reset dive vars')
# Collision is lower and wider during the launched dive. Keep 0..point geometry for consistency.
replace('''func _player_box(px: float, py: float) -> Rect2:
	return Rect2(px - PLAYER_HALF_W, py - PLAYER_H, PLAYER_HALF_W * 2.0, PLAYER_H)''','''func _player_box(px: float, py: float) -> Rect2:
	var half_width: float = 19.0 if dash_timer > 0.0 and dash_launched else PLAYER_HALF_W
	var height: float = 26.0 if dash_timer > 0.0 and dash_launched else PLAYER_H
	return Rect2(px - half_width, py - height, half_width * 2.0, height)

func _player_width() -> float:
	return 19.0 if dash_timer > 0.0 and dash_launched else PLAYER_HALF_W

func _player_height() -> float:
	return 26.0 if dash_timer > 0.0 and dash_launched else PLAYER_H''','dive box')
replace('''	if dash_timer <= 0.0:
		vx = axis * MOVE_SPEED
		if Input.is_action_just_pressed("dash") and dash_cooldown <= 0.0:
			dash_timer = 0.28
			dash_cooldown = 1.20
			vx = float(facing) * 345.0
			_spawn_puff(player_x, player_y - 8.0, 8, Color("#c8a14b"))
	else:
		vx = float(facing) * 345.0
	if Input.is_action_just_pressed("jump"):
''','''	if dash_timer <= 0.0:
		vx = axis * MOVE_SPEED
		if Input.is_action_just_pressed("dash") and dash_cooldown <= 0.0:
			dash_timer = 0.58
			dash_cooldown = 1.24
			dash_direction = facing
			dash_launched = false
			vx = float(dash_direction) * 42.0
			_spawn_puff(player_x, player_y - 3.0, 5, Color("#c8a14b"))
	else:
		var dive_age: float = 0.58-dash_timer
		if dive_age < 0.09:
			vx = float(dash_direction)*42.0
		else:
			if not dash_launched:
				dash_launched = true
				vy = minf(vy,-164.0)
				grounded = false
				jump_count = maxi(jump_count,1)
				_spawn_puff(player_x,player_y-8.0,10,Color("#a69b9c"))
			vx = float(dash_direction)*(294.0 if dive_age<0.37 else (202.0 if dive_age<0.48 else 78.0))
		facing = dash_direction
	if dash_timer<=0.0 and Input.is_action_just_pressed("jump"):
''','dive physics')
replace('player_x = block.position.x - PLAYER_HALF_W','player_x = block.position.x - _player_width()','dive wall right')
replace('player_x = block.end.x + PLAYER_HALF_W','player_x = block.end.x + _player_width()','dive wall left')
replace('old_y - PLAYER_H >= block.end.y - 6.0','old_y - _player_height() >= block.end.y - 6.0','dive head collision')
replace('player_y = block.end.y + PLAYER_H','player_y = block.end.y + _player_height()','dive ceiling collision')
# define visual/collision profile for enemy classes
anchor='func _enemy_shoot(e: Dictionary) -> void:'
idx=s.index(anchor)
profile='''# v1.0.5: scale grounded Automatons to or above Helldiver height.
# Rendering and collision dimensions share this authoritative profile.
func _unit_profile(e: Dictionary) -> Dictionary:
	match str(e.get("unit","trooper")):
		"marauder": return {"scale":1.62,"hit_w":24.0,"hit_h":65.0,"eye":52.0,"muzzle":42.0,"reach":25.0}
		"devastator": return {"scale":1.88,"hit_w":29.0,"hit_h":85.0,"eye":64.0,"muzzle":51.0,"reach":30.0}
		"rocket_devastator": return {"scale":1.96,"hit_w":31.0,"hit_h":88.0,"eye":67.0,"muzzle":54.0,"reach":31.0}
		"heavy_devastator": return {"scale":2.02,"hit_w":33.0,"hit_h":91.0,"eye":70.0,"muzzle":55.0,"reach":33.0}
		"berserker": return {"scale":1.83,"hit_w":27.0,"hit_h":79.0,"eye":62.0,"muzzle":48.0,"reach":36.0}
		"strider": return {"scale":2.18,"hit_w":32.0,"hit_h":99.0,"eye":82.0,"muzzle":70.0,"reach":35.0}
	return {"scale":1.60,"hit_w":24.0,"hit_h":65.0,"eye":52.0,"muzzle":42.0,"reach":25.0}

'''
s=s[:idx]+profile+s[idx:]
replace('''	var mx: float = float(e["x"])+float(e["dir"])*(45.0 if heavy else (18.0 if fly else 22.0))
	var my: float = float(e["y"])-(0.0 if fly else (60.0 if heavy else 27.0))''', '''	var up: Dictionary = _unit_profile(e)
	var mx: float = float(e["x"])+float(e["dir"])*(45.0 if heavy else (18.0 if fly else (22.0 if e["kind"] == "turret" else 22.0*float(up["scale"]))))
	var my: float = float(e["y"])-(0.0 if fly else (60.0 if heavy else (27.0 if e["kind"] == "turret" else float(up["muzzle"]))))''','enemy shot origin')
replace('''var eye_y: float = float(e["y"])-(0.0 if fly else (61.0 if heavy else 29.0))''','''var eye_y: float = float(e["y"])-(0.0 if fly else (61.0 if heavy else (29.0 if e["kind"] == "turret" else float(_unit_profile(e)["eye"]))))''','enemy awareness height')
replace('''distance < (31.0 if str(e.get("unit","")) == "berserker" else 22.0)''','''distance < float(_unit_profile(e)["reach"])''','enemy contact reach')
replace('''var half_w: float = 43.0 if e["kind"] in ["warden","sentinel"] else 21.0
				var height: float = 92.0 if e["kind"] in ["warden","sentinel"] else (37.0 if e["kind"] == "drone" else 43.0)''','''var up: Dictionary = _unit_profile(e)
				var half_w: float = 43.0 if e["kind"] in ["warden","sentinel"] else (21.0 if e["kind"] == "drone" else (22.0 if e["kind"] == "turret" else float(up["hit_w"])))
				var height: float = 92.0 if e["kind"] in ["warden","sentinel"] else (37.0 if e["kind"] == "drone" else (43.0 if e["kind"] == "turret" else float(up["hit_h"])))''','shot hitbox')
# Align telegraphs, sprites, and bars to scaled silhouettes
replace('''var origin := Vector2(sx+float(e["dir"])*(45.0 if heavy else (18.0 if e["kind"]=="drone" else 22.0)), y-(0.0 if e["kind"]=="drone" else (60.0 if heavy else 27.0)))''','''var up: Dictionary = _unit_profile(e)
			var muzzle_shift: float = 45.0 if heavy else (18.0 if e["kind"]=="drone" else (22.0 if e["kind"]=="turret" else 22.0*float(up["scale"])))
			var muzzle_height: float = 0.0 if e["kind"]=="drone" else (60.0 if heavy else (27.0 if e["kind"]=="turret" else float(up["muzzle"])))
			var origin := Vector2(sx+float(e["dir"])*muzzle_shift,y-muzzle_height)''','enemy telegraph')
replace('''			draw_texture(sprites["bot_%s_%d_%s" % [str(e.get("unit","trooper")),frame, "r" if int(e["dir"]) > 0 else "l"]], Vector2(floorf(sx - 26), floorf(y - 48)))''','''			var up: Dictionary = _unit_profile(e)
			var model_scale: float = float(up["scale"])
			var model_key: String = "bot_%s_%d_%s" % [str(e.get("unit","trooper")),frame, "r" if int(e["dir"]) > 0 else "l"]
			draw_texture_rect(sprites[model_key],Rect2(sx-26.0*model_scale,y-48.0*model_scale,52.0*model_scale,48.0*model_scale),false)''','enemy sprite draw')
replace('''_draw_health_bar(sx - 14.0, y - 52.0, 28.0, float(e["hp"]) / float(e["max_hp"]), Color("#e85b4f"))''','''_draw_health_bar(sx - 14.0, y - (float(_unit_profile(e)["hit_h"])+9.0 if e["kind"] == "walker" else 52.0), 28.0, float(e["hp"]) / float(e["max_hp"]), Color("#e85b4f"))''','scaled health bar')
# Animation selection synced to physics rather than static walk/dive sheets.
replace('''	elif dash_timer > 0.0:
		animation = "dive"
		frame = int(anim_clock * 18.0) % 2''','''	elif dash_timer > 0.0:
		animation = "dive"
		var dive_age: float = 0.58-dash_timer
		frame = 0 if dive_age<0.09 else (1 if dive_age<0.20 else (2 if dive_age<0.47 else 3))''','dive frames')
replace('''		frame = int(anim_clock * 12.0) % 4 if animation == "jet" else 0''','''		frame = int(anim_clock * 12.0) % 4 if animation == "jet" else (0 if vy < -110.0 else (1 if vy<55.0 else (2 if vy<245.0 else 3)))''','jump keyframes')
replace('''	facing = int(rifle_info["face"])''','''	if dash_timer<=0.0: facing = int(rifle_info["face"])''','dive facing')
replace('''	if sprites.has(gun_name):''','''	if dash_timer<=0.0 and sprites.has(gun_name):''','dive stow rifle')
replace('''	if fire_timer > 0.0 and muzzle_effects.size() == 4:''','''	if fire_timer > 0.0 and dash_timer<=0.0 and muzzle_effects.size() == 4:''','hide dive muzzle')
p.write_text(s)
print('Updated Godot companion (not engine-tested)')
