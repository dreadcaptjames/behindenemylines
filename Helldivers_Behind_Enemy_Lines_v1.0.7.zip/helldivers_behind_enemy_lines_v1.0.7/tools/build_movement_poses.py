"""Construct tighter-jump and real horizontal dive keyframes from original sprite layers.
Nearest-neighbor pixel construction is intentional; the deliverable is actual game art.
"""
from PIL import Image, ImageDraw
from pathlib import Path
ART=Path(__file__).resolve().parent.parent/'art'
INK=(13,9,21,255)
DARK=(38,28,53,255)
ARMOR=(63,47,78,255)
PLATE=(97,77,119,255)
GOLD=(255,197,24,255)
BRIGHT=(255,225,65,255)

# Pixel-art legs use specific knee, shin and boot placements rather than separated silhouettes.
poses=[
    ((37,39),(36,50),(36,61),(47,39),(47,49),(49,60)), # ascent: braced feet
    ((37,39),(33,46),(39,57),(47,39),(51,47),(49,57)), # apex: both tucked
    ((37,39),(36,50),(34,65),(47,39),(47,50),(50,65)), # descent: extending
    ((37,39),(37,51),(37,64),(47,39),(49,51),(50,64)), # thrust: stabilized
]

def thick_segment(draw, a,b,w,base):
    draw.line([tuple(a),tuple(b)], fill=INK,width=w+4,joint='curve')
    draw.line([tuple(a),tuple(b)], fill=base,width=w,joint='curve')

def new_jump_pose(phase):
    base=Image.open(ART/'hero_body_jump_0_r.png').convert('RGBA')
    out=Image.new('RGBA',base.size)
    # Preserve cape silhouette down to the hem and the original upper body.
    out.alpha_composite(base.crop((0,0,31,72)),(0,0))
    out.alpha_composite(base.crop((31,0,84,39)),(31,0))
    d=ImageDraw.Draw(out)
    hipL,kneeL,bootL,hipR,kneeR,bootR=poses[phase]
    # Rear leg, then front leg: knees remain under the torso at x 32..51.
    thick_segment(d,hipR,kneeR,8,ARMOR)
    thick_segment(d,kneeR,bootR,7,DARK)
    d.rectangle((bootR[0]-3,bootR[1]-1,bootR[0]+8,bootR[1]+2),fill=INK)
    d.rectangle((bootR[0]-1,bootR[1]-1,bootR[0]+6,bootR[1]+1),fill=PLATE)
    d.line([(hipR[0]+2,hipR[1]+3),(kneeR[0]+1,kneeR[1]-1)],fill=GOLD,width=3)
    thick_segment(d,hipL,kneeL,9,PLATE)
    thick_segment(d,kneeL,bootL,7,ARMOR)
    d.rectangle((bootL[0]-3,bootL[1]-1,bootL[0]+8,bootL[1]+2),fill=INK)
    d.rectangle((bootL[0]-1,bootL[1]-1,bootL[0]+6,bootL[1]+1),fill=PLATE)
    d.line([(hipL[0]-1,hipL[1]+2),(kneeL[0]-1,kneeL[1]-1)],fill=GOLD,width=3)
    d.polygon([(34,35),(51,35),(53,43),(41,45),(33,41)],fill=INK)
    d.polygon([(36,36),(50,36),(50,41),(41,43),(35,40)],fill=ARMOR)
    d.line([(35,40),(46,40)],fill=PLATE,width=2)
    return out

for i in range(4):
    r=new_jump_pose(i)
    r.save(ART/f'hero_body_jump_{i}_r.png')
    r.transpose(Image.Transpose.FLIP_LEFT_RIGHT).save(ART/f'hero_body_jump_{i}_l.png')
    # The jet animation is now based on this tucked-leg silhouette, not the old splayed frame.
    r.save(ART/f'hero_body_jet_{i}_r.png')
    r.transpose(Image.Transpose.FLIP_LEFT_RIGHT).save(ART/f'hero_body_jet_{i}_l.png')

idle=Image.open(ART/'hero_body_idle_0_r.png').convert('RGBA')

def fit_into(sprite, max_w=80,max_h=55):
    bounds=sprite.getbbox()
    crop=sprite.crop(bounds)
    w,h=crop.size
    scale=min(max_w/w,max_h/h,1.4)
    crop=crop.resize((round(w*scale),round(h*scale)),Image.Resampling.NEAREST)
    surface=Image.new('RGBA',(84,72))
    surface.alpha_composite(crop,((84-crop.width)//2, (72-crop.height)//2))
    return surface

def pose_dive(degrees, dx=0,dy=0, squat=False):
    if squat:
        bounds=idle.getbbox();img=idle.crop(bounds)
        # The launch/recovery crouch lowers the helmet and shifts the knees under the body.
        img=img.resize((img.width,round(img.height*.82)),Image.Resampling.NEAREST)
        canvas=Image.new('RGBA',(84,72));canvas.alpha_composite(img,(max(0,20+dx),72-img.height+dy-1));return canvas
    rotated=idle.rotate(degrees,expand=True,resample=Image.Resampling.NEAREST)
    out=fit_into(rotated,78,47)
    if dx or dy:
        shifted=Image.new('RGBA',(84,72));shifted.alpha_composite(out,(dx,dy));return shifted
    return out

# Frames are consumed by a mechanical state machine: crouch, launch, glide, recovery.
frames=[pose_dive(0,dx=-1,squat=True),pose_dive(-61,dx=3,dy=0),pose_dive(-88,dx=2,dy=1),pose_dive(-31,dx=1,dy=7)]
for i,r in enumerate(frames):
    r.save(ART/f'hero_body_dive_{i}_r.png')
    r.transpose(Image.Transpose.FLIP_LEFT_RIGHT).save(ART/f'hero_body_dive_{i}_l.png')

# An editable contact sheet for checking the delivered in-game poses.
from PIL import ImageFont
sheet=Image.new('RGB',(4*168,2*168),(22,16,33))
for idx,part in enumerate([new_jump_pose(i) for i in range(4)]+frames):
    enlarged=part.resize((168,144),Image.Resampling.NEAREST)
    x=(idx%4)*168; y=(idx//4)*168
    sheet.paste(enlarged,(x,y+14),enlarged)
    ImageDraw.Draw(sheet).text((x+4,y+2),['ASCENT','APEX','DESCENT','JET','CROUCH','LAUNCH','DIVE','RECOVERY'][idx],fill=(255,226,98))
sheet.save(ART.parent/'MOVEMENT_POSES.png')
print('Created new airborne and dive frames plus MOVEMENT_POSES.png')
