"""Original pixel artwork expansion for BEL v0.4; only reads v0.3 sprites/backgrounds.
Generated additions retain fixed low-resolution pixel artwork and do not use third-party game assets.
"""
from PIL import Image, ImageDraw, ImageOps, ImageFont
from pathlib import Path
import random, math, re
root=Path(__file__).resolve().parents[1]; art=root/'art'; art.mkdir(exist_ok=True,parents=True)
rng=random.Random(40319)
PURPLE='#31253f'; EDGE='#120d1c'; GOLD='#ffc726'; LIGHT='#fff0aa'; RED='#f06443'; TEAL='#80e4d6'
# Existing sprites are small original pixel art; refine silhouettes and add extra hand-drawn frame variations.
def ink(im, mode, f):
    d=ImageDraw.Draw(im); y=(f//2)%2; phase=f%8
    if mode!='dive':
        # Additional armor contour, optics, bolts, segmented ammunition markings and backpack depth.
        d.line([(29,14+y),(31,11+y),(35,9+y)],fill='#a18ab5',width=1)
        d.point((37,10+y),fill='#dac2d5')
        d.line([(26,26+y),(28,25+y),(30,26+y)],fill='#e5b51f',width=1)
        d.rectangle((18,24+y,20,25+y),fill='#83647c')
        d.point((21,34+y),fill=LIGHT)
        d.line([(34,33+y),(39,33+y)],fill='#a08cae',width=1)
        for ax in [62,66,70]:d.point((ax,34+y),fill='#aa90ad')
        d.line([(32,47),(36,47)],fill='#caa135',width=1)
        # Shoulder skull / insignia hint at 1:1 sprite resolution.
        d.rectangle((25,27+y,29,30+y),fill='#d7ad21')
        d.point((26,28+y),fill=EDGE);d.point((28,28+y),fill=EDGE)
        d.point((27,30+y),fill=EDGE)
        if mode=='run':
            # Graphic cape trailing and alternating boot sole impacts.
            d.polygon([(4+(phase%3),58),(10+(phase%3),54),(15,57)],fill=GOLD)
            d.line([(14,52),(19,44)],fill='#b59038',width=1)
            if phase%2==0:d.line([(23,62),(35,62)],fill='#b09aab',width=1)
            else:d.line([(41,62),(56,62)],fill='#9f88a0',width=1)
        elif mode=='idle':
            d.line([(8,53+(phase%2)),(16,49+(phase%2))],fill='#8f6b4d',width=1)
        elif mode=='jet':
            d.rectangle((17,38,20,43),fill='#fbb21b')
            d.rectangle((24,41,26,46),fill='#ffdb61')
            yj=phase%3
            d.polygon([(17,44),(14-yj,49+yj),(20,47),(22,44)],fill='#ee6a20')
            d.polygon([(24,46),(24,52+yj),(27,47)],fill=GOLD)
        elif mode=='jump':
            d.line([(22,60),(27,61)],fill='#c9b1c5',width=1)
        elif mode=='fire':
            d.rectangle((75,32,79,34),fill=('#fff6b1' if f%2==0 else '#ffb52b'))
            if f%3==0:d.point((70,31),fill='#d8bcc5')
        elif mode=='reload':
            d.point((62,45+f%2),fill=GOLD)
    else:
        d.line([(9,46),(23,42)],fill='#84627d',width=1)
        if f%2:d.polygon([(5,51),(9,50),(12,52),(2,56)],fill=GOLD)
    return im

def sprite(path):return Image.open(art/path).convert('RGBA')
def save_sprite(mode,f,base_index,shiftx=0,shifty=0):
    base=sprite(f'hero_{mode}_{base_index}_r.png')
    if shiftx or shifty:
        shifted=Image.new('RGBA',base.size);shifted.alpha_composite(base,(shiftx,shifty));base=shifted
    ink(base,mode,f)
    base.save(art/f'hero_{mode}_{f}_r.png');ImageOps.mirror(base).save(art/f'hero_{mode}_{f}_l.png')
# Refresh existing variants and add new transition frames.
for mode, indices in {'idle':[0,1,0,1], 'run':[0,1,2,3,0,1,2,3], 'fire':[0,1,0], 'jet':[0,1,0,1], 'reload':[0,1,2], 'dive':[0,0], 'jump':[0]}.items():
    original=[sprite(f'hero_{mode}_{i}_r.png') for i in sorted(set(indices))]
    for frame,base in enumerate(indices):
        # Use original bytes in memory so creating frame 4 doesn't depend on frame 0 post-processing.
        im=original[sorted(set(indices)).index(base)].copy()
        shiftx=1 if mode=='run' and frame in (2,6) else 0
        shifty=-1 if mode=='run' and frame in (1,5) else 0
        if shiftx or shifty:
            moved=Image.new('RGBA',im.size);moved.alpha_composite(im,(shiftx,shifty));im=moved
        ink(im,mode,frame)
        im.save(art/f'hero_{mode}_{frame}_r.png');ImageOps.mirror(im).save(art/f'hero_{mode}_{frame}_l.png')
# Add 4-frame sparks around the muzzle using small original tiles.
for frame in range(4):
    im=Image.new('RGBA',(32,24));d=ImageDraw.Draw(im)
    if frame<3:
        r=[14,10,6][frame];cx,cy=4,12
        d.polygon([(cx,cy-2),(cx+r,cy-4),(cx+max(3,r-3),cy),(cx+r+4,cy+2),(cx+4,cy+4),(cx,cy+2)],fill=['#fff5be','#ffde66','#f4a52b'][frame])
        d.line([(4,10),(11+frame,3+frame)],fill='#fff1af',width=2 if frame==0 else 1)
        for z in range(2+frame):
            xx=16+z*4; yy=(z*7+frame*2)%17+3
            d.rectangle((xx,yy,xx+1,yy+1),fill='#ffae38')
    im.save(art/f'muzzle_flash_{frame}.png')
# New midground: silhouetted factories, cranes, blast walls, hanging conduits.
W,H=1536,270
mid=Image.new('RGBA',(W,H));d=ImageDraw.Draw(mid)
for i,x in enumerate(range(-36,W+130,124)):
    h=round(95+27*math.sin(i*1.7)+rng.randint(-10,17)); y=H-h
    d.rectangle((x,y,x+86,H),fill='#221d32')
    d.rectangle((x+4,y,x+81,y+4),fill='#3c3047')
    d.line((x+6,y+9,x+80,y+9),fill='#34283f',width=2)
    for yy in range(y+18,266,24):
        d.line((x+5,yy,x+83,yy),fill='#30283e',width=2)
        if i%3==0:
            d.rectangle((x+20,yy-9,x+28,yy-2),fill='#68404d')
    for xx in [x+13,x+42,x+70]:
        d.line((xx,y+6,xx,269),fill='#131323',width=3)
    if i%2==0:
        d.rectangle((x+27,y-38,x+50,y),fill='#231f34')
        d.rectangle((x+32,y-37,x+46,y-34),fill='#5a4050')
        d.rectangle((x+35,y-40,x+43,y-38),fill='#684751')
    if i%4==1:
        d.line((x+36,y-16,x+84,y-52),fill='#483449',width=3)
        d.line((x+36,y-16,x+91,y-16),fill='#483449',width=2)
        d.line((x+88,y-53,x+88,y-2),fill='#5e4456',width=1)
    for xx in range(x+9,x+80,18):
        if rng.random()<.6:d.rectangle((xx,y+15,xx+3,y+17),fill=rng.choice(['#764347','#9b553e','#51405b']))
# Flat cross-region pipe line, brackets and little red light towers.
for height in [149,187,214]:
    d.line((0,height,W,height),fill='#262035',width=5)
    d.line((0,height,W,height),fill='#594255',width=1)
for x in range(85,W,241):
    d.rectangle((x,103,x+9,221),fill='#241d32')
    d.rectangle((x+2,107,x+5,219),fill='#49324a')
    d.rectangle((x-3,104,x+12,109),fill='#776073')
    d.rectangle((x+1,100,x+8,103),fill='#b1553d')
mid.save(art/'mid_industry.png')
# Deep foreground props: dark silhouetted equipment in front of horizon, alpha composited.
props=Image.new('RGBA',(W,H));d=ImageDraw.Draw(props)
for x in range(50,W,198):
    ht=rng.randint(38,70)
    d.rectangle((x,250-ht,x+21,270),fill=(14,13,25,235))
    d.rectangle((x+3,253-ht,x+18,257-ht),fill=(77,57,73,230))
    for ty in range(267-ht,268,10):
        d.rectangle((x+7,ty,x+13,ty+2),fill=(93,60,67,200))
    d.line((x-4,251-ht,x+24,251-ht),fill=(89,69,90,235),width=2)
    if x%3:
        d.line((x+10,250-ht,x-3,236-ht),fill=(51,42,62,255),width=2)
props.save(art/'foreground_machines.png')
# Sublevel/Archive backgrounds gain industrial character but preserve readable collision plane.
for name in ['sublevel','archive']:
    source=sprite(name+'_bg.png'); im=source.copy();d=ImageDraw.Draw(im)
    cold=name=='archive'; col='#6ed6cc' if cold else '#e8964e'; dim='#37616c' if cold else '#624450'; metal='#665d78' if cold else '#635067'
    for x in range(24,480,99):
        # overhead I-beam and rivets
        d.rectangle((x,45,x+5,217),fill='#302a40' if cold else '#282434')
        d.line((x+2,46,x+2,215),fill=metal,width=1)
        d.rectangle((x-6,45,x+13,48),fill=metal)
        for y in range(52,219,31):d.point((x+1,y),fill=col)
        # inspection displays
        d.rectangle((x+18,132,x+47,153),fill='#151a2c',outline=metal,width=2)
        d.rectangle((x+21,137,x+44,148),fill='#122832' if cold else '#261b2c')
        for k in range(4):d.line((x+22,140+k*2,x+30+(k*5)%13,140+k*2),fill=col)
        d.rectangle((x+40,151,x+43,152),fill=col)
        # floor hatches
        d.rectangle((x+32,212,x+80,225),fill='#211b2d',outline='#53475b')
        for xx in range(x+37,x+77,10):d.line((xx,216,xx+4,222),fill='#aa823e' if not cold else '#477e86',width=1)
    # pipes and cables along ceiling
    d.line((0,50,480,50),fill='#665065',width=3)
    d.line((0,55,480,55),fill='#332b40',width=2)
    for k in range(0,480,56):
        d.arc((k,49,k+52,93),0,180,fill='#635269',width=2)
        d.point((k+9,50),fill='#aa995e')
    # Vent slots and warn stripes near floor
    for x in range(16,470,70):
        d.rectangle((x,184,x+45,190),fill='#15131f',outline=dim)
        for xx in range(x+4,x+43,6):d.line((xx,186,xx+3,188),fill=metal)
    if cold:
        d.rectangle((202,70,278,83),fill='#082c36',outline='#4b96a2')
        d.text((211,73),'ACCESS 04',fill='#8ae1d6',font=ImageFont.load_default())
        d.rectangle((205,87,274,89),fill='#2c8191')
    else:
        d.rectangle((193,74,287,87),fill='#231b2b',outline='#9e6244')
        d.text((201,77),'WORKS // 06',fill='#e7b45b',font=ImageFont.load_default())
        d.rectangle((199,90,280,93),fill='#a3683d')
    # grime / pinprick sparks intentionally deterministic
    for _ in range(180):
        x=rng.randrange(480); y=rng.randrange(49,225)
        if rng.random()<.15:d.point((x,y),fill=col)
        elif rng.random()<.35:d.point((x,y),fill='#45334f')
    im.save(art/f'{name}_bg.png')
# alternative enemy animation frames with arm articulation and panel lighting
for f in range(2,4):
    base=sprite(f'automaton_{f%2}_r.png');d=ImageDraw.Draw(base)
    d.rectangle((16,28,25,29),fill='#8d7583')
    d.rectangle((27,17,35,19),fill='#ff7e5a' if f==2 else '#ff433d')
    d.line((13,23,13+(f%2)*3,30),fill='#837080',width=2)
    base.save(art/f'automaton_{f}_r.png'); ImageOps.mirror(base).save(art/f'automaton_{f}_l.png')
print('Created updated original sprites, new parallax layers, and expanded industrial backdrops.')
