"""Apply gameplay changes: multi-state dive, velocity-based jump, enemy art/physics scale."""
from pathlib import Path
p=Path(__file__).resolve().parent.parent/'browser-demo'/'index.html'
s=p.read_text()
def change(old,new,label):
    global s
    if old not in s: raise ValueError('Missing code section: '+label+' '+old[:80])
    s=s.replace(old,new,1)

change('v1.0.4','v1.0.5','browser version')
s=s.replace('· v1.0.4','· v1.0.5')
s=s.replace('v=1.0.4','v=1.0.5')
s=s.replace('BUILD 1.0.4','BUILD 1.0.5')
# Load new airborne and dive sprites as true frames, not looped placeholder images.
change("{idle:4,run:8,jump:1,dive:2,fire:3,reload:3,jet:4,land:4,hurt:3}))for(let f=0;f<count;f++)for(const dir of ['r','l'])assets.push(`hero_body_${anim}_${f}_${dir}`);", "{idle:4,run:8,jump:4,dive:4,fire:3,reload:3,jet:4,land:4,hurt:3}))for(let f=0;f<count;f++)for(const dir of ['r','l'])assets.push(`hero_body_${anim}_${f}_${dir}`);",'body art registration')

# Enemy sizes expressed relative to the actual 52x48 source images. A Trooper's visible 40px body
# becomes 64px at 1.60x; the Helldiver's visible 67px body remains 1x.
anchor='const initialEnemies=()=>['
idx=s.index(anchor)
scale_code="""// v1.0.5: visual height and collision box are coupled so large machines do not
// behave as tiny targets. Flying drones and fixed turrets have separate dimensions.
const AUTOMATON_UNIT_PROFILE={
 trooper:{scale:1.60,hitW:24,hitH:65,eye:52,muzzle:42,reach:25},
 marauder:{scale:1.62,hitW:24,hitH:65,eye:52,muzzle:42,reach:25},
 devastator:{scale:1.88,hitW:29,hitH:85,eye:64,muzzle:51,reach:30},
 rocket_devastator:{scale:1.96,hitW:31,hitH:88,eye:67,muzzle:54,reach:31},
 heavy_devastator:{scale:2.02,hitW:33,hitH:91,eye:70,muzzle:55,reach:33},
 berserker:{scale:1.83,hitW:27,hitH:79,eye:62,muzzle:48,reach:36},
 strider:{scale:2.18,hitW:32,hitH:99,eye:82,muzzle:70,reach:35}
};
function automatonSize(e){return AUTOMATON_UNIT_PROFILE[e.unit]||AUTOMATON_UNIT_PROFILE.trooper}
"""
s=s[:idx]+scale_code+s[idx:]
change('dash:0,dashCd:0,land:0','dash:0,dashCd:0,diveDir:1,diveLaunched:false,land:0','reset player dive fields')
change('function hitbox(){return [p.x-10,p.y-44,20,44]}', "function playerDimensions(){return p.dash>0&&p.diveLaunched?{w:19,h:26}:{w:10,h:44}}\nfunction hitbox(){const d=playerDimensions();return [p.x-d.w,p.y-d.h,d.w*2,d.h]}", 'dive collision geometry')
change("if(p.dash<=0){p.vx=dir*143;if(tap('dive')&&p.dashCd<=0){p.dash=.28;p.dashCd=1.2;p.vx=p.face*345;puff(p.x,p.y-8,8,'#bba15a')}}else p.vx=p.face*345;", """if(p.dash<=0){
 p.vx=dir*143;
 if(tap('dive')&&p.dashCd<=0){
  p.dash=.58;p.dashCd=1.24;p.diveDir=p.face;p.diveLaunched=false;
  p.vx=p.diveDir*42;puff(p.x,p.y-3,5,'#bba15a');
 }
}else{
 const diveAge=.58-p.dash;
 // Crouch -> airborne launch -> extended horizontal travel -> recovery.
 if(diveAge<.09)p.vx=p.diveDir*42;
 else{
  if(!p.diveLaunched){p.diveLaunched=true;p.vy=Math.min(p.vy,-164);p.ground=false;p.jumps=Math.max(p.jumps,1);puff(p.x,p.y-8,10,'#a69b9c')}
  p.vx=p.diveDir*(diveAge<.37?294:diveAge<.48?202:78);
 }
 p.face=p.diveDir;
}""",'dive controls')
change("if(tap('jump')){if(p.ground)","if(p.dash<=0&&tap('jump')){if(p.ground)",'disable jump while diving')
change("if(p.vx>0)p.x=b[0]-10;else if(p.vx<0)p.x=b[0]+b[2]+10", "if(p.vx>0)p.x=b[0]-playerDimensions().w;else if(p.vx<0)p.x=b[0]+b[2]+playerDimensions().w",'dynamic horizontal collision')
change("oldY-44>=b[1]+b[3]-6){p.y=b[1]+b[3]+44", "oldY-playerDimensions().h>=b[1]+b[3]-6){p.y=b[1]+b[3]+playerDimensions().h",'dynamic vertical collision')
# Real dive poses & velocity-based jump phases, gun hidden during the dive silhouette.
change("a==='jet'?Math.floor(clock*12)%4:a==='dive'?Math.floor(clock*18)%2", "a==='jet'?Math.floor(clock*12)%4:a==='jump'?(p.vy< -110?0:p.vy<55?1:p.vy<245?2:3):a==='dive'?(.58-p.dash<.09?0:.58-p.dash<.20?1:.58-p.dash<.47?2:3)",'jump and dive frame states')
change("const gun=rifleGeometry();p.face=gun.facing;", "const gun=rifleGeometry();if(p.dash<=0)p.face=gun.facing;",'face locked during dive')
change("const rifle=art[`hero_gun_${p.face>0?'r':'l'}`];\n if(rifle?.naturalWidth){", "const rifle=p.dash>0?null:art[`hero_gun_${p.face>0?'r':'l'}`];\n if(rifle?.naturalWidth){",'dive body only')
change("if(p.fire>0){\n   const frame=Math.max(0,Math.min(3", "if(p.fire>0&&p.dash<=0){\n   const frame=Math.max(0,Math.min(3",'no floating muzzle while diving')

# Scale body/sensors/weapon origins coherently.
change("const x=e.x+e.dir*(heavy?45:fly?18:22),y=e.y-(fly?0:heavy?60:27);", "const prof=automatonSize(e);const x=e.x+e.dir*(heavy?45:fly?18:e.kind==='turret'?22:22*prof.scale),y=e.y-(fly?0:heavy?60:e.kind==='turret'?27:prof.muzzle);",'AI projectile origin')
change("const eyeY=e.y-(fly?0:heavy?61:29),targetY=p.y-24;", "const eyeY=e.y-(fly?0:heavy?61:e.kind==='turret'?29:automatonSize(e).eye),targetY=p.y-24;",'AI line of sight')
change("dist<(e.unit==='berserker'?31:22)","dist<automatonSize(e).reach",'melee reach')
change("let w=['warden','sentinel'].includes(e.kind)?43:21,h=['warden','sentinel'].includes(e.kind)?92:e.kind==='drone'?37:43;", "const prof=automatonSize(e);let w=['warden','sentinel'].includes(e.kind)?43:e.kind==='drone'?21:e.kind==='turret'?22:prof.hitW,h=['warden','sentinel'].includes(e.kind)?92:e.kind==='drone'?37:e.kind==='turret'?43:prof.hitH;",'player shot hitboxes')
change("const heavy=['warden','sentinel'].includes(e.kind), fly=e.kind==='drone', turret=e.kind==='turret', walker=e.kind==='walker';", "const heavy=['warden','sentinel'].includes(e.kind), fly=e.kind==='drone', turret=e.kind==='turret', walker=e.kind==='walker', prof=automatonSize(e);",'render profiles')
change("const sx=x+e.dir*(heavy?45:fly?18:22),sy=e.y-(fly?0:heavy?60:27)", "const sx=x+e.dir*(heavy?45:fly?18:turret?22:22*prof.scale),sy=e.y-(fly?0:heavy?60:turret?27:prof.muzzle)",'attack telegraph origin')
# do scaling for every sprite including berserker ghost afterimage
change("image(`bot_${unit}_${frame}_${e.dir>0?'r':'l'}`,x-26-e.dir*10,e.y-48+bob);", "image(`bot_${unit}_${frame}_${e.dir>0?'r':'l'}`,x-26*prof.scale-e.dir*10,e.y-48*prof.scale+bob,52*prof.scale,48*prof.scale);",'berserker trail')
change("image(`bot_${unit}_${frame}_${e.dir>0?'r':'l'}`,x-26+lean,e.y-48+bob);", "image(`bot_${unit}_${frame}_${e.dir>0?'r':'l'}`,x-26*prof.scale+lean,e.y-48*prof.scale+bob,52*prof.scale,48*prof.scale);",'draw unit size')
# Replace block of unit-specific overlays to scale them based on body proportions (avoid little eyes in neck).
start=s.index('   // localized detail passes: eyes, weapon glows, and silhouette callouts')
end=s.index('\n }\n if(e.hit>0)',start)
s=s[:start]+"""   // Facial optics and armor trim follow the new larger model proportions.
   const eyeY=e.y-prof.eye+bob, eyeX=x+e.dir*4*prof.scale;
   rect(eyeX-1,eyeY,3,3,'#ff765f');
   if(unit==='rocket_devastator'){rect(x+e.dir*11,e.y-prof.muzzle+bob,8,4,'#c49b4c')}
   if(unit==='heavy_devastator'){rect(x+e.dir*15,e.y-prof.muzzle+7+bob,8,10,'#243240')}
   if(unit==='strider'){rect(x-e.dir*2,e.y-14+bob,13,4,'#303742')}
   if(unit==='berserker'){rect(x+e.dir*18,e.y-27+bob,10,3,'#d3d0cb')}
"""+s[end:]
change("healthbar(x-14,e.y-(fly?39:52),28,e.hp/e.max);", "healthbar(x-14,e.y-(fly?39:turret?52:prof.hitH+9),28,e.hp/e.max);",'health bars match scale')
change("if(e.stun>0){rect(x-12,e.y-64,25,4,'#7beee5');text('EMP',x-9,e.y-67,8,'#7beee5')}","if(e.stun>0){const sy=e.y-(walker?prof.hitH+16:64);rect(x-12,sy,25,4,'#7beee5');text('EMP',x-9,sy-3,8,'#7beee5')}",'EMP marker scaled')
s=s.replace('v1.0.4:','v1.0.5:')
p.write_text(s)
print('Patched browser runtime for movement, dive, and Automaton scale')
