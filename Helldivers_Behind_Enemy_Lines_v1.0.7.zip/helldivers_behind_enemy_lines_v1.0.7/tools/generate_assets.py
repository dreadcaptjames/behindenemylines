"""Original pixel art and procedural sound assets for the prototype.
The supplied art_direction_reference.png is only used on the title screen.
No game assets are extracted from commercial titles.
"""
from PIL import Image, ImageDraw, ImageOps
from pathlib import Path
import random, math, wave, struct
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'art'; AUD=ROOT/'audio'
ART.mkdir(exist_ok=True); AUD.mkdir(exist_ok=True)
BLACK='#0b0912'; EDGE='#100c17'; PURPLE='#2c223a'; MID='#483651'; LIT='#655173'; PALE='#9886a7'; GOLD='#ffcb12'; LIGHT='#fff15e'; ORANGE='#ee8b0c'; RED='#ec4a40'

def draw_hero(frame, variant):
    im=Image.new('RGBA',(80,64)); d=ImageDraw.Draw(im)
    bob=0 if frame in ('idle','jump') else ((variant%2)*1)
    if frame=='dive':
        # Horizontal airborne silhouette with a ribbon cape and extended rifle.
        d.polygon([(14,32),(3,41),(5,52),(27,43),(45,40)], fill=PURPLE, outline=EDGE)
        d.polygon([(4,43),(7,48),(25,41)],fill=ORANGE)
        d.rectangle((22,26,54,42),fill=PURPLE,outline=EDGE,width=2)
        d.rectangle((27,25,50,28),fill=GOLD)
        d.rectangle((13,20,32,32),fill=PURPLE,outline=EDGE,width=2)
        d.rectangle((19,22,24,27), fill=ORANGE)
        d.rectangle((46,19,62,33),fill=PURPLE,outline=EDGE,width=2)
        d.rectangle((55,22,64,29),fill=GOLD)
        d.rectangle((52,33,79,39),fill=PURPLE,outline=EDGE,width=2)
        d.rectangle((67,35,73,36),fill=GOLD)
        d.rectangle((35,40,48,46),fill=MID,outline=EDGE,width=2)
        d.rectangle((18,42,30,49),fill=MID,outline=EDGE,width=2)
    else:
        # Cape and backpack sit behind the character.
        d.polygon([(24,24+bob),(18,35+bob),(8,51+bob),(2,59+bob),(18,56+bob),(27,40+bob)],fill='#211a2f',outline=EDGE)
        d.polygon([(7,54+bob),(3,59+bob),(18,56+bob),(25,43+bob),(20,44+bob)],fill=GOLD)
        d.polygon([(10,43+bob),(19,31+bob),(24,33+bob),(13,51+bob)],fill='#514060')
        d.rectangle((16,21+bob,30,42+bob),fill='#2f263e',outline=EDGE,width=2)
        d.rectangle((18,26+bob,21,34+bob),fill=ORANGE)
        d.rectangle((22,30+bob,25,36+bob),fill=GOLD)
        stride=[(0,0),(5,-4),(0,1),(-4,-3)][variant%4] if frame=='run' else (0,0)
        if frame=='jump': stride=(3,-7)
        # Legs with alternating silhouette offsets.
        leg1x=26+stride[0]; leg1y=44+max(stride[1],-4)
        leg2x=42-stride[0]; leg2y=44-max(stride[1],-4)
        for lx,ly in [(leg1x,leg1y),(leg2x,leg2y)]:
            d.polygon([(lx-7,ly),(lx+5,ly),(lx+7,ly+11),(lx+4,ly+18),(lx-8,ly+18)],fill='#30253c',outline=EDGE)
            d.polygon([(lx-2,ly+3),(lx+5,ly+4),(lx+4,ly+9),(lx-1,ly+10)],fill=GOLD)
            d.rectangle((lx-9,min(60,ly+11),lx+8,61),fill='#4d3c59',outline=EDGE,width=2)
            d.rectangle((lx-6,min(60,ly+14),lx+3,min(62,ly+17)),fill='#75627e')
        # Torso and chest armor.
        d.polygon([(25,22+bob),(35,18+bob),(49,25+bob),(47,44+bob),(26,43+bob),(21,30+bob)],fill='#392b49',outline=EDGE)
        d.polygon([(29,24+bob),(45,25+bob),(42,34+bob),(30,34+bob)],fill='#5b4568')
        d.polygon([(30,22+bob),(45,24+bob),(48,30+bob),(40,28+bob)],fill=GOLD)
        d.rectangle((30,40+bob,44,46+bob),fill='#6d5278',outline=EDGE,width=2)
        d.rectangle((34,42+bob,39,45+bob),fill=GOLD)
        # Back arm and left pauldron.
        d.polygon([(21,24+bob),(29,23+bob),(34,29+bob),(30,37+bob),(20,35+bob)],fill=GOLD,outline=EDGE)
        d.polygon([(24,27+bob),(30,26+bob),(32,32+bob),(24,33+bob)],fill='#32253c')
        d.rectangle((25,28+bob,30,30+bob),fill=ORANGE)
        # Head, visor, respirator.
        d.polygon([(27,10+bob),(33,5+bob),(46,7+bob),(53,13+bob),(51,29+bob),(36,30+bob),(28,22+bob)],fill='#2c213a',outline=EDGE)
        d.polygon([(30,13+bob),(34,8+bob),(46,9+bob),(49,13+bob)],fill='#776084')
        d.rectangle((36,7+bob,43,9+bob),fill=GOLD)
        d.polygon([(40,15+bob),(54,15+bob),(52,23+bob),(40,23+bob)],fill=ORANGE,outline=EDGE)
        d.rectangle((44,16+bob,50,19+bob),fill=LIGHT)
        d.rectangle((49,18+bob,52,23+bob),fill=GOLD)
        d.rectangle((42,25+bob,49,30+bob),fill='#584563',outline=EDGE,width=2)
        # Rifle and foreground arm, aligned with projectile spawn.
        d.polygon([(40,31+bob),(57,29+bob),(59,33+bob),(47,41+bob),(38,38+bob)],fill='#453750',outline=EDGE)
        d.polygon([(49,30+bob),(72,30+bob),(74,33+bob),(79,33+bob),(79,39+bob),(53,39+bob),(46,36+bob)],fill='#4c3b57',outline=EDGE)
        d.rectangle((56,31+bob,74,33+bob),fill='#796584')
        d.rectangle((61,36+bob,69,37+bob),fill=GOLD)
        d.rectangle((73,33+bob,79,35+bob),fill='#ae9bba')
        d.rectangle((52,39+bob,56,43+bob),fill='#392c48')
        d.polygon([(39,35+bob),(47,35+bob),(51,41+bob),(45,44+bob),(37,40+bob)],fill='#3e304e',outline=EDGE)
        d.rectangle((41,37+bob,46,40+bob),fill=GOLD)
    return im
for typ,count in [('idle',2),('run',4),('jump',1),('dive',1)]:
    for i in range(count):
        im=draw_hero(typ,i)
        im.save(ART/f'hero_{typ}_{i}_r.png')
        ImageOps.mirror(im).save(ART/f'hero_{typ}_{i}_l.png')

def enemy_walk(i):
    im=Image.new('RGBA',(52,48)); d=ImageDraw.Draw(im)
    shift=3 if i%2 else -2
    # Mechanical legs
    d.polygon([(13,33),(24,31),(19+shift,44),(10+shift,46)],fill='#3e3b48',outline=EDGE)
    d.polygon([(30,32),(40,33),(45-shift,44),(35-shift,46)],fill='#3e3b48',outline=EDGE)
    d.rectangle((7+shift,43,23+shift,47),fill='#79717d',outline=EDGE)
    d.rectangle((31-shift,43,49-shift,47),fill='#79717d',outline=EDGE)
    # arm plates
    d.rectangle((4,22,14,35),fill='#514453',outline=EDGE,width=2)
    d.rectangle((39,23,50,34),fill='#574455',outline=EDGE,width=2)
    d.rectangle((10,14,43,36),fill='#4e4355',outline=EDGE,width=2)
    d.polygon([(14,15),(20,10),(38,11),(42,18),(36,30),(18,29)],fill='#716571',outline=EDGE)
    d.rectangle((13,29,40,35),fill='#2b2330')
    # red eye and crest
    d.rectangle((21,16,39,22),fill='#a22427',outline=EDGE)
    d.rectangle((25,17,36,19),fill='#ff7260')
    d.rectangle((28,17,30,20),fill='#fff0c0')
    d.rectangle((25,7,34,13),fill='#383440',outline=EDGE)
    d.rectangle((27,8,33,9),fill='#9b9b9d')
    return im
for i in range(2):
    img=enemy_walk(i)
    img.save(ART/f'automaton_{i}_r.png'); ImageOps.mirror(img).save(ART/f'automaton_{i}_l.png')

def turret():
    im=Image.new('RGBA',(54,42)); d=ImageDraw.Draw(im)
    d.polygon([(15,39),(19,25),(34,25),(40,39)],fill='#554759',outline=EDGE)
    d.rectangle((12,33,44,40),fill='#514455',outline=EDGE,width=2)
    d.polygon([(12,12),(24,7),(40,14),(46,28),(11,29)],fill='#61556a',outline=EDGE)
    d.rectangle((22,15,48,23),fill='#2b2535',outline=EDGE,width=2)
    d.rectangle((46,16,54,21),fill='#6f6576',outline=EDGE)
    d.rectangle((15,18,21,22),fill=RED)
    d.rectangle((18,18,20,19),fill='#ffb16a')
    d.rectangle((13,25,42,29),fill='#352b3f')
    return im
im=turret();im.save(ART/'turret_r.png');ImageOps.mirror(im).save(ART/'turret_l.png')

def boss():
    im=Image.new('RGBA',(112,106));d=ImageDraw.Draw(im)
    d.polygon([(18,60),(39,60),(38,98),(11,104)],fill='#4f4654',outline=EDGE)
    d.polygon([(69,60),(93,62),(104,103),(74,102)],fill='#4f4654',outline=EDGE)
    d.rectangle((12,90,42,103),fill='#786c78',outline=EDGE,width=3)
    d.rectangle((75,91,108,103),fill='#786c78',outline=EDGE,width=3)
    d.polygon([(25,31),(47,15),(70,16),(97,33),(89,72),(25,77),(14,50)],fill='#625565',outline=EDGE)
    d.polygon([(30,37),(52,25),(78,31),(85,53),(67,65),(30,61)],fill='#2d2936')
    d.polygon([(29,34),(51,20),(78,25),(87,39),(74,45),(44,42)],fill='#918390',outline=EDGE)
    d.polygon([(11,34),(31,29),(33,60),(11,70),(2,52)],fill='#726474',outline=EDGE)
    d.polygon([(89,28),(105,34),(111,59),(97,68),(81,56)],fill='#726474',outline=EDGE)
    d.rectangle((38,39,76,51),fill='#a02024',outline=EDGE,width=3)
    d.rectangle((44,40,71,45),fill='#ff644c')
    d.rectangle((48,40,58,43),fill='#fff09d')
    d.rectangle((42,67,71,79),fill='#403647',outline=EDGE,width=2)
    for xx in [44,51,58,65]:d.rectangle((xx,71,xx+3,75),fill='#cc4034')
    d.rectangle((93,51,111,62),fill='#48414f',outline=EDGE,width=2)
    d.rectangle((100,55,110,57),fill='#a69faa')
    d.rectangle((13,4,26,24),fill='#62515f',outline=EDGE,width=2)
    d.rectangle((18,6,23,15),fill=RED)
    d.rectangle((79,4,92,25),fill='#62515f',outline=EDGE,width=2)
    d.rectangle((83,6,88,15),fill=RED)
    return im
boss().save(ART/'warden.png')

rng=random.Random(7)
W=1536; H=270
sky=Image.new('RGBA',(W,H)); p=sky.load()
for y in range(H):
    t=y/H
    color=(round(8+21*t),round(7+9*t),round(22+18*t),255)
    for x in range(W): p[x,y]=color
s=ImageDraw.Draw(sky)
# distant red-purple nebula light zones
for cx in [180,700,1190]:
    for radius in range(115,0,-9):
        a=max(0,8-int(radius/14));
        s.ellipse((cx-radius,50-radius//2,cx+radius,50+radius//2),outline=(87,37,62,a),width=2)
# Massive eclipsed planet low on horizon
s.ellipse((1080,20,1280,219),fill='#261a39',outline='#423149',width=2)
s.ellipse((1130,40,1320,209),fill='#1a122b')
s.arc((1081,22,1278,218),45,170,fill='#a13f2b',width=2)
for j in range(145):
    x=rng.randrange(W);y=rng.randrange(20,152)
    s.point((x,y),fill=rng.choice(['#5b476b','#4a3c5e','#88708a','#382b4b']))
sky.save(ART/'sky.png')
far=Image.new('RGBA',(W,H)); f=ImageDraw.Draw(far)
f.polygon([(0,215),(90,202),(170,215),(230,174),(315,209),(430,188),(550,220),(670,180),(790,209),(905,169),(1050,216),(1160,174),(1320,220),(1430,194),(W,213),(W,H),(0,H)],fill='#231d34')
for i in range(44):
    x=rng.randrange(W);w=rng.choice([14,17,22,34,45]); h=rng.randrange(12,69)
    f.rectangle((x,226-h,x+w,270),fill='#2a233a')
    if rng.random() < .5:
        f.rectangle((x+3,225-h,x+w-3,226-h),fill='#584457')
    if rng.random()<.6:
        for yy in range(232-h,234,10):
            f.rectangle((x+4,yy,x+6,yy+2),fill='#624444')
far.save(ART/'far_industry.png')
near=Image.new('RGBA',(W,H)); n=ImageDraw.Draw(near)
for i in range(27):
    x=i*61+rng.randint(-15,15);height=rng.randint(42,105);w=rng.randint(25,60)
    n.rectangle((x,270-height,x+w,H),fill='#191725')
    n.rectangle((x+3,270-height,x+w-3,272-height),fill='#30283b')
    if i%3==0:
        n.rectangle((x+w//2-6,270-height-28,x+w//2+5,270-height),fill='#211b2c')
        n.rectangle((x+w//2-5,270-height-29,x+w//2+6,270-height-26),fill='#514052')
    for yy in range(280-height,258,12):
        for xx in range(x+5,x+w-5,10):
            if rng.random() < .43: n.rectangle((xx,yy,xx+3,yy+3),fill=rng.choice(['#5b302e','#743b2d','#462c35']))
    n.line((x,270-height,x-13,270-height+13),fill='#352739',width=2)
near.save(ART/'near_industry.png')

tile=Image.new('RGBA',(32,32),'#24202d');t=ImageDraw.Draw(tile)
t.rectangle((0,0,31,3),fill='#736079'); t.line((0,5,31,5),fill='#3d3145')
t.rectangle((0,6,31,31),fill='#282331')
t.rectangle((2,10,28,27),outline='#382e41')
for _ in range(12):
    x=rng.randint(2,30);y=rng.randint(8,30)
    t.line((x,y,x+rng.choice([-3,3]),y+1),fill=rng.choice(['#3f3349','#1b1924','#4d3c51']))
for x in [3,27]:
    t.rectangle((x,3,x+2,5),fill='#c59a2f')
tile.save(ART/'concrete_tile.png')

def icon(kind):
    im=Image.new('RGBA',(16,16));d=ImageDraw.Draw(im)
    if kind=='ammo':
        d.rectangle((4,3,11,13),fill='#3a3048',outline=GOLD,width=2);d.rectangle((6,2,9,4),fill='#fff1a0')
    if kind=='health':
        d.rectangle((2,2,13,13),fill='#3d594b',outline='#6be5a7',width=2);d.rectangle((6,4,9,11),fill='#e4ffeb');d.rectangle((4,6,11,9),fill='#e4ffeb')
    if kind=='jet':
        d.polygon([(3,8),(8,2),(13,8),(10,8),(10,12),(6,12),(6,8)],fill='#efb318',outline=EDGE)
    if kind=='terminal':
        d.rectangle((2,2,13,12),fill='#41354c',outline='#ffcc12',width=2);d.rectangle((5,5,11,7),fill='#fff38b');d.rectangle((5,9,8,9),fill='#fc9d34')
    im.save(ART/f'icon_{kind}.png')
for k in ['ammo','health','jet','terminal']:icon(k)

# Fully original synthesized effects; each is short so the repo stays lightweight.
rate=22050

def save_wave(name, f, duration, seed):
    count=int(rate*duration)
    rng=np.random.default_rng(seed)
    times=np.arange(count)/rate
    samples=f(times,rng)
    env=np.minimum(1,np.maximum(0,(duration-times)*min(25,4/duration)))
    samples=np.asarray(samples)*env
    samples=np.tanh(samples*1.15)*.65
    pcm=(np.clip(samples,-1,1)*32767).astype('<i2')
    with wave.open(str(AUD/name),'wb') as wf:
        wf.setnchannels(1);wf.setsampwidth(2);wf.setframerate(rate);wf.writeframes(pcm.tobytes())
save_wave('rifle.wav',lambda t,r: .50*np.sin(2*np.pi*(195*t+750*t*t)) + .25*r.standard_normal(len(t))*np.exp(-18*t),.15,2)
save_wave('jump.wav',lambda t,r: .36*np.sin(2*np.pi*(140*t+410*t*t)),.19,3)
save_wave('hurt.wav',lambda t,r:.45*np.sin(2*np.pi*(120*t-80*t*t))+.28*r.standard_normal(len(t)),.28,4)
save_wave('pickup.wav',lambda t,r:.30*np.sin(2*np.pi*(500*t+900*t*t))+.18*np.sin(2*np.pi*880*t),.36,5)
save_wave('explosion.wav',lambda t,r:.46*r.standard_normal(len(t))*np.exp(-3*t)+.48*np.sin(2*np.pi*(70*t-18*t*t)),.8,6)
save_wave('terminal.wav',lambda t,r:.3*np.sin(2*np.pi*660*t)+.2*np.sin(2*np.pi*990*t),.32,7)
print('Generated pixel art and sound in',ROOT)

# v0.2.0: additional combat/reload/jump-jet frames, espionage collectible,
# and a hand-authored industrial silhouette layer. These are original pixels.
for i in range(2):
    base=draw_hero('idle',i)
    if i:
        offset=Image.new('RGBA',(80,64))
        offset.paste(base,(-2,0))
        base=offset
    d=ImageDraw.Draw(base)
    d.polygon([(72,31),(79,29),(77,33),(79,37),(71,35)],fill=GOLD)
    d.rectangle((75,32,79,34),fill=LIGHT)
    base.save(ART/f'hero_fire_{i}_r.png')
    ImageOps.mirror(base).save(ART/f'hero_fire_{i}_l.png')
for i in range(3):
    base=draw_hero('idle',i%2)
    d=ImageDraw.Draw(base)
    # The magazine comes down, is replaced, and is clicked into position.
    mag_down=i==1
    d.rectangle((56,38,66,42),fill='#3b2f48',outline=EDGE)
    d.polygon([(59,39),(64,40),(67 if mag_down else 64,54 if mag_down else 49),(59,50)],fill='#554861',outline=EDGE)
    d.rectangle((60,43,62,46),fill=GOLD)
    if i==2:d.rectangle((63,38,68,40),fill=LIGHT)
    base.save(ART/f'hero_reload_{i}_r.png')
    ImageOps.mirror(base).save(ART/f'hero_reload_{i}_l.png')
for i in range(2):
    base=draw_hero('jump',i)
    d=ImageDraw.Draw(base)
    d.polygon([(21,57),(25,57),(24+i*2,63),(19,61)],fill=ORANGE,outline=EDGE)
    d.polygon([(42,58),(46,57),(47-i,63),(41,62)],fill=GOLD,outline=EDGE)
    d.rectangle((22,58,24,60),fill=LIGHT)
    d.rectangle((43,58,45,61),fill=LIGHT)
    base.save(ART/f'hero_jet_{i}_r.png')
    ImageOps.mirror(base).save(ART/f'hero_jet_{i}_l.png')

chip=Image.new('RGBA',(16,16))
d=ImageDraw.Draw(chip)
d.rectangle((3,1,12,14),fill='#302b43',outline=GOLD,width=2)
d.rectangle((5,4,10,6),fill='#f8cb40')
d.rectangle((5,9,10,10),fill='#c7b0a0')
d.rectangle((2,3,3,5),fill=LIGHT)
d.rectangle((12,10,14,12),fill=ORANGE)
chip.save(ART/'icon_intel.png')

ind=Image.new('RGBA',(W,H))
d=ImageDraw.Draw(ind)
rng2=random.Random(21)
# Strong layers of shapes, kept below the usable player silhouette so combat
# stays readable, with brighter pixel details around pipes and metal gantries.
for i,x in enumerate(range(0,W+80,92)):
    y=183+rng2.randint(-25,25)
    d.rectangle((x-6,y,x+34,H),fill=(18,15,29,210),outline=(62,48,71,255),width=2)
    d.rectangle((x+1,y+8,x+27,y+15),fill=(40,32,49,255))
    d.rectangle((x+3,y+10,x+26,y+11),fill=(109,75,78,245))
    for yy in range(y+23,min(H,y+70),10):
        d.rectangle((x+1,yy,x+5,yy+2),fill=(98,73,79,190))
    if i%3==0:
        d.rectangle((x+12,y-27,x+22,y+7),fill=(33,30,43,255),outline=(93,72,91,220),width=2)
        d.rectangle((x+13,y-24,x+21,y-20),fill=(162,68,44,255))
        d.rectangle((x+14,y-23,x+17,y-21),fill=(242,127,64,255))
    if i%4==1:
        # Elevated relay arms; thin, broken cables and highlights.
        d.line((x+12,y-5,x+57,y-35),fill=(84,67,90,240),width=3)
        d.line((x+58,y-35,x+64,y+15),fill=(44,39,54,180),width=2)
        d.rectangle((x+55,y-38,x+60,y-33),fill=(227,146,60,200))
# Vents and long segmented conduits. This layer has no large opaque rectangles
# above y=160 and should not cover the jump-jet/objective platforms.
for y,x1,x2 in [(215,50,485),(207,560,980),(222,1090,1500)]:
    d.line((x1,y,x2,y),fill=(84,62,87,255),width=4)
    d.line((x1,y-3,x2,y-3),fill=(151,105,84,190),width=1)
    for x in range(x1,x2,37):
        d.rectangle((x,y-5,x+5,y+4),fill=(37,30,45,255),outline=(108,84,96,230))
for x in [250,475,812,1032,1380]:
    d.polygon([(x,204),(x+24,190),(x+46,204),(x+46,225),(x,225)],fill=(25,23,37,230),outline=(91,68,83,255))
    d.rectangle((x+12,197,x+33,201),fill=(197,121,51,245))
    d.rectangle((x+14,198,x+20,199),fill=(255,207,91,255))
ind.save(ART/'decor_industrial.png')

save_wave('reload.wav',lambda t,r: .33*np.sin(2*np.pi*(370*t+145*t*t))*np.exp(-9*t)+.18*r.standard_normal(len(t))*np.exp(-12*t),.25,22)
print('Generated v0.2.0 frame set and environmental assets')
