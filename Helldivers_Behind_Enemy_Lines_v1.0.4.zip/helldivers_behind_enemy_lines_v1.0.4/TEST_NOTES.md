# v1.0.4 — Test Notes

- `node tests/test_headless_canvas.js`: full campaign regression, all assets, visual snapshots, and new dynamic-background assertions.
- `python tests/test_mobile_gestures.py`: Chromium mobile emulation with synthetic multi-pointer hold tests, Safari-style gesture cancellation checks, and touch-mode release checks (requires Python Playwright + Chromium).
- Physical iPadOS Safari still needs device testing. Safari's system-level gestures outside the game are controlled by iPadOS and cannot be blocked by a webpage.
- The Godot companion source remains provided for continuity; this v1.0.4 graphics and Safari gesture pass is verified in the **browser** runtime, not separately inside Godot.
