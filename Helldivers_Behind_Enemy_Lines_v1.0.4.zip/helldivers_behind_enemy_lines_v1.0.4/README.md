# HELLDIVERS: BEHIND ENEMY LINES — v1.0.4

## Dynamic Depth & iPad Gesture Fix

A continuation of v1.0.3, preserving rifle alignment, gait corrections, two campaign acts, music, touch controls, armor and ability unlocks.

### Scenery
- Removed moving, dark, screen-crossing cables from the final foreground pass.
- Removed screen-wide scanlines that darkened the player and gameplay.
- Moved near-floor mechanical detail behind the player and interactables.
- Added varied parallax industrial skylines, subdued animated fans, window lights, steam drifts and sector-specific palette changes.
- Kept platforms and hazards readable above the backdrop.

### Mobile web / Safari
- Prevents long-press selection, callout menus, double-tap zoom, drag-select and native touch gestures **within the game surface**.
- Disables accidental scrolling/overscroll during active touch play.
- Keeps the bindings panel scrollable and normal browser functionality outside game controls.
- Maintains the two-thumb movement/aim-and-fire layout and desktop input.

### Play
Open `browser-demo/index.html` locally or publish the ZIP through the repository's Pages workflow.
On iPad, play in landscape orientation. Safari's system gestures outside the page itself remain controlled by iPadOS.

### Validation
Browser regression and mobile interaction tests are included; Godot engine runtime has not been validated here.
