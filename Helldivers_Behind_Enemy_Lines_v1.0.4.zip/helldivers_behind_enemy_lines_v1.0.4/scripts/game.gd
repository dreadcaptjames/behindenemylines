extends Node2D
## HELLDIVERS: BEHIND ENEMY LINES — original fan-game prototype, v1.0.4.
## Self-contained gameplay. All gameplay visuals and collision are drawn/handled
## in the 480x270 pixel-perfect virtual viewport; no third-party plug-ins needed.

const VIEW_W: float = 480.0
const VIEW_H: float = 270.0
const WORLD_END: float = 3100.0
const MOVE_SPEED: float = 143.0
const GRAVITY: float = 740.0
const JUMP_SPEED: float = -342.0
const PLAYER_HALF_W: float = 10.0
const PLAYER_H: float = 44.0
const MAG_SIZE: int = 18
const STRAT_CODE: Array[String] = ["U", "R", "D", "U"]

const INTRO: Array = [
	{"speaker": "SES JUDGMENT OF DAWN", "a": "COLONIAL RELAY DELTA-9 HAS GONE DARK.", "b": "INVESTIGATE THE SOURCE OF THE JAMMING."},
	{"speaker": "MISSION CONTROL", "a": "YOUR DESTROYER HAS LOST YOUR TELEMETRY.", "b": "NO STRATAGEMS. NO EXTRACTION. MOVE OUT."},
	{"speaker": "HELLDIVER // FIELD LOG 001", "a": "LOCATE THE COLONY UPLINK AND REESTABLISH", "b": "COMMUNICATIONS. DEMOCRACY AWAITS."}
]

var mode: String = "title" # title, dialogue, playing, pause, victory
var dialog_pages: Array = []
var dialog_page: int = 0
var dialog_resume: String = "playing"
var dialog_age: float = 0.0
var landing_fx: float = 0.0
var music_layers: Dictionary = {}
var sprites: Dictionary = {}
var sky: Texture2D
var far: Texture2D
var near: Texture2D
var mid: Texture2D
var foreground_machines: Texture2D
var muzzle_effects: Array[Texture2D] = []
var decor: Texture2D
var tile: Texture2D
var ref_art: Texture2D
var sublevel_bg: Texture2D
var archive_bg: Texture2D
var blacksite_bg: Texture2D
var reactor_bg: Texture2D
var concept_main: Texture2D
var concept_rooms: Dictionary = {}
var hud_font: Font
var world_solids: Array[Rect2] = []
var sector_solids: Dictionary = {}
var sector_enemies: Dictionary = {}
var sector: String = "main"
var visited_sectors: Dictionary = {"main": true}
var arc_cutter: bool = false
var armor_recovered: bool = false
var emp_recovered: bool = false
var pulse_cooldown: float = 0.0
var pulse_fx: float = 0.0
var laser_off: float = 0.0
var junction_a: bool = false
var junction_b: bool = false
var reactor_disabled: bool = false
var sentinel_awake: bool = false
var sentinel_defeated: bool = false
var checkpoint_sector: String = "main"
var max_health: int = 5
var dynamic_gate: Rect2 = Rect2(2420, 0, 24, 228)
var enemies: Array[Dictionary] = []
var bullets: Array[Dictionary] = []
var particles: Array[Dictionary] = []
var player_x: float = 90.0
var player_y: float = 202.0
var vx: float = 0.0
var vy: float = 0.0
var facing: int = 1
var grounded: bool = false
var jump_count: int = 0
var can_double_jump: bool = false
var comms_restored: bool = false
var boss_awake: bool = false
var boss_defeated: bool = false
var health: int = 5
var ammo: int = MAG_SIZE
var reload_timer: float = 0.0
var fire_timer: float = 0.0
var hurt_timer: float = 0.0
var dash_timer: float = 0.0
var dash_cooldown: float = 0.0
var strat_cooldown: float = 0.0
var strat_input: bool = false
var strat_progress: int = 0
var orbital_warning: float = -1.0
var orbital_target: float = 0.0
var screen_flash: float = 0.0
var checkpoint_x: float = 90.0
var checkpoint_y: float = 228.0
var checkpoint_index: int = 0
var map_open: bool = false
var notify: String = ""
var notify_timer: float = 0.0
var tutorial_timer: float = 12.0
var camera_x: float = 0.0
var anim_clock: float = 0.0
var run_phase: float = 0.0 # movement-distance driven gait, shared by weapon and run states
var elapsed: float = 0.0
var enemies_destroyed: int = 0
var total_deaths: int = 0
var music_enabled: bool = true
var stim_used: bool = false
var recoil_shake: float = 0.0
var mouse_aim_time: float = 0.0
var recovered_logs: Array[int] = []
const LOGS: Array = [
	{"room":"main","x":365.0,"y":164.0,"title":"COLONY BLACK BOX 01", "a":"EVACUATION REQUEST DENIED. REASON:", "b":"RELAY DELTA-9 PRIORITY CLASSIFIED."},
	{"room":"main","x":2240.0,"y":157.0,"title":"COLONY BLACK BOX 02", "a":"WARDEN DIRECTIVE: SUPPRESS ALL TRAFFIC.", "b":"AUTHORIZATION KEY: SUPER EARTH // REDACTED."},
	{"room":"sublevel","x":690.0,"y":134.0,"title":"MAINTENANCE DIRECTIVE 03", "a":"CUTTER SUPPLY MOVED TO THE LOWER WORKS.", "b":"ARCHIVE ACCESS REMAINS SEALED BY ORDER."},
	{"room":"archive","x":386.0,"y":135.0,"title":"DELTA-9 RECORD // CLASSIFIED", "a":"SUPER EARTH OVERRIDE ACCEPTED AT 04:17.", "b":"THE RELAY SILENCE WAS AN INSIDE JOB."},
	{"room":"blacksite","x":718.0,"y":143.0,"title":"BLACKSITE RECORD // 05", "a":"PROJECT SILENCE WAS NEVER AN AUTOMATON OP.", "b":"THE ORDER ORIGINATED FROM HUMAN COMMAND."},
	{"room":"reactor","x":731.0,"y":139.0,"title":"REACTOR AUDIT // 06", "a":"COLONY SURVIVORS WERE MOVED BELOW GROUND.", "b":"NO EXTRACTION WAS AUTHORIZED. FIND THEM."},
	{"room":"main","x":2022.0,"y":158.0,"title":"EMERGENCY BROADCAST // 07", "a":"CIVILIAN EVAC SHUTTLES WERE RECALLED.", "b":"A SEAF OFFICER SEALED THE LOWER TUNNELS."},
	{"room":"blacksite","x":1211.0,"y":147.0,"title":"SURVIVOR TRACE // 08", "a":"WE HEARD YOU FIGHT THE MACHINES ABOVE.", "b":"FOLLOW THE POWER. THE CHILDREN ARE WAITING."}
]

func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	hud_font = ThemeDB.fallback_font
	_load_art()
	_setup_music()
	_setup_actions()
	_build_world()
	_reset_mission()
	mode = "title"
	queue_redraw()

func _load_art() -> void:
	for animation in ["idle", "run", "jump", "dive", "fire", "reload", "jet", "land", "hurt"]:
		var count: int = 1
		if animation == "run":
			count = 8
		elif animation in ["reload", "fire"]:
			count = 3
		elif animation in ["idle", "jet", "land"]:
			count = 4
		elif animation == "dive":
			count = 2
		elif animation == "hurt":
			count = 3
		for i in range(count):
			for side in ["r", "l"]:
				var key: String = "%s_%d_%s" % [animation, i, side]
				sprites[key] = load("res://art/hero_%s.png" % key)
				sprites["body_" + key] = load("res://art/hero_body_%s.png" % key)
	for i in range(4):
		for side in ["r", "l"]:
			sprites["robot_%d_%s" % [i, side]] = load("res://art/automaton_%d_%s.png" % [i, side])
	for unit in ["trooper", "marauder", "devastator", "rocket_devastator", "heavy_devastator", "berserker", "strider"]:
		for i in range(4):
			for side in ["r", "l"]:
				sprites["bot_%s_%d_%s" % [unit,i,side]] = load("res://art/bot_%s_%d_%s.png" % [unit,i,side])
	for i in range(4):
		for side in ["r", "l"]:
			sprites["drone_%d_%s" % [i, side]] = load("res://art/drone_%d_%s.png" % [i, side])
	for side in ["r", "l"]:
		sprites["turret_" + side] = load("res://art/turret_%s.png" % side)
		sprites["hero_gun_" + side] = load("res://art/hero_gun_%s.png" % side)
	sprites["warden"] = load("res://art/warden.png")
	sprites["sentinel"] = load("res://art/sentinel.png")
	for who in ["command", "survivor", "automaton", "helldiver"]:
		sprites["radio_"+who] = load("res://art/radio_%s.png" % who)
	sprites["automaton_emblem"] = load("res://art/automaton_emblem.png")
	sprites["helldiver_emblem"] = load("res://art/helldiver_emblem.png")
	sprites["evidence_terminal"] = load("res://art/evidence_terminal.png")
	for item in ["health", "jet", "terminal", "ammo", "intel", "breach", "armor", "emp", "reactor"]:
		sprites["icon_" + item] = load("res://art/icon_%s.png" % item)
	sky = load("res://art/sky.png")
	far = load("res://art/far_industry.png")
	near = load("res://art/near_industry.png")
	mid = load("res://art/mid_industry.png")
	foreground_machines = load("res://art/foreground_machines.png")
	for i in range(4): muzzle_effects.append(load("res://art/muzzle_flash_%d.png" % i))
	decor = load("res://art/decor_industrial.png")
	tile = load("res://art/concept_metal_tile.png")
	sublevel_bg = load("res://art/sublevel_bg.png")
	archive_bg = load("res://art/archive_bg.png")
	blacksite_bg = load("res://art/blacksite_bg.png")
	reactor_bg = load("res://art/reactor_bg.png")
	concept_main = load("res://art/factory_concept_panorama.png")
	for room in ["sublevel", "archive", "blacksite", "reactor"]:
		concept_rooms[room] = load("res://art/%s_concept_bg.png" % room)
	ref_art = load("res://art/art_direction_reference.png")

func _setup_music() -> void:
	for track_name in ["ambient", "combat", "boss"]:
		var stream: AudioStreamOggVorbis = load("res://audio/%s_loop.ogg" % track_name)
		if stream == null: continue
		stream.loop = true
		var player := AudioStreamPlayer.new()
		player.name = "Music_" + track_name
		player.stream = stream
		player.volume_db = -80.0
		add_child(player)
		player.play()
		music_layers[track_name] = player

func _update_music(delta: float) -> void:
	var danger: bool = false
	var boss: bool = false
	if mode == "playing":
		for e in enemies:
			if int(e["hp"]) <= 0: continue
			if e["kind"] == "warden" and not boss_awake: continue
			if e["kind"] == "sentinel" and not sentinel_awake: continue
			if absf(float(e["x"])-player_x) < 280.0:
				danger = true
				if e["kind"] in ["warden","sentinel"]: boss = true
	for track_name in music_layers:
		var player: AudioStreamPlayer = music_layers[track_name]
		var target: float = -80.0
		if music_enabled:
			if track_name == "ambient" and mode in ["playing", "dialogue"]: target = -25.0 if mode == "playing" else -34.0
			if track_name == "combat" and danger and not boss: target = -24.0
			if track_name == "boss" and boss: target = -22.0
		player.volume_db = move_toward(player.volume_db,target,delta*27.0)

func _register(name: String, keys: Array, joy: Array = []) -> void:
	if not InputMap.has_action(name):
		InputMap.add_action(name)
	for key in keys:
		var event := InputEventKey.new()
		event.physical_keycode = key
		InputMap.action_add_event(name, event)
	for index in joy:
		var button := InputEventJoypadButton.new()
		button.button_index = index
		InputMap.action_add_event(name, button)

func _setup_actions() -> void:
	_register("left", [KEY_A, KEY_LEFT], [JOY_BUTTON_DPAD_LEFT])
	_register("right", [KEY_D, KEY_RIGHT], [JOY_BUTTON_DPAD_RIGHT])
	_register("up", [KEY_W, KEY_UP], [JOY_BUTTON_DPAD_UP])
	_register("down", [KEY_S, KEY_DOWN], [JOY_BUTTON_DPAD_DOWN])
	_register("jump", [KEY_SPACE], [JOY_BUTTON_A])
	_register("fire", [KEY_F], [JOY_BUTTON_X])
	_register("interact", [KEY_E], [JOY_BUTTON_Y])
	_register("reload", [KEY_R], [JOY_BUTTON_B])
	_register("dash", [KEY_SHIFT], [JOY_BUTTON_RIGHT_SHOULDER])
	_register("stratagem", [KEY_Q], [JOY_BUTTON_LEFT_SHOULDER])
	_register("map", [KEY_M], [JOY_BUTTON_BACK])
	_register("pulse", [KEY_G], [JOY_BUTTON_LEFT_TRIGGER])
	_register("confirm", [KEY_ENTER, KEY_KP_ENTER], [JOY_BUTTON_START])
	_register("pause", [KEY_ESCAPE, KEY_P], [JOY_BUTTON_START])
	_register("resume", [KEY_C])
	_register("music_toggle", [KEY_B])

func _build_world() -> void:
	# Every region is traversable in both directions; mobility pickups open the
	# elevated routes while the relay opens a physical gate to the final arena.
	world_solids = [
		Rect2(0, 228, 694, 50), Rect2(762, 228, 535, 50),
		Rect2(1343, 228, 505, 50), Rect2(1907, 228, 595, 50),
		Rect2(2565, 228, 560, 50),
		Rect2(318, 179, 112, 12), Rect2(542, 164, 140, 12),
		Rect2(827, 184, 125, 12), Rect2(1060, 166, 155, 12),
		Rect2(1420, 178, 132, 12), Rect2(1618, 150, 173, 12),
		Rect2(1957, 180, 131, 12), Rect2(2174, 174, 158, 12),
		Rect2(2326, 145, 124, 12), Rect2(2711, 185, 116, 12)
	]
	sector_solids["main"] = world_solids.duplicate()
	sector_solids["sublevel"] = [Rect2(0,228,252,50),Rect2(303,228,247,50),Rect2(609,228,222,50),Rect2(894,228,276,50),
		Rect2(148,182,121,12),Rect2(382,167,150,12),Rect2(626,152,162,12),Rect2(849,178,170,12)]
	sector_solids["archive"] = [Rect2(0,228,760,50),Rect2(120,185,131,12),Rect2(303,153,126,12),Rect2(518,190,148,12)]
	sector_solids["blacksite"] = [Rect2(0,228,582,50),Rect2(641,228,546,50),Rect2(1246,228,404,50),Rect2(225,185,136,12),Rect2(428,166,159,12),Rect2(769,185,160,12),Rect2(1040,165,166,12),Rect2(1300,178,161,12)]
	sector_solids["reactor"] = [Rect2(0,228,1200,50),Rect2(182,180,130,12),Rect2(400,163,146,12),Rect2(616,185,148,12),Rect2(797,167,139,12)]

func _base_enemies() -> Array[Dictionary]:
	return [
		{"kind": "walker", "unit": "trooper", "x": 452.0, "y": 228.0, "hp": 4, "max_hp": 4, "left": 394.0, "right": 640.0, "dir": -1, "fire": 0.7, "speed": 22.0},
		{"kind": "walker", "unit": "marauder", "x": 902.0, "y": 228.0, "hp": 4, "max_hp": 4, "left": 808.0, "right": 1157.0, "dir": -1, "fire": 1.2, "speed": 28.0},
		{"kind": "turret", "x": 1245.0, "y": 228.0, "hp": 5, "max_hp": 5, "left": 0.0, "right": 0.0, "dir": -1, "fire": 1.4, "speed": 0.0},
		{"kind": "walker", "unit": "strider", "x": 1506.0, "y": 228.0, "hp": 4, "max_hp": 4, "left": 1370.0, "right": 1750.0, "dir": -1, "fire": 1.1, "speed": 23.0},
		{"kind": "turret", "x": 2030.0, "y": 228.0, "hp": 5, "max_hp": 5, "left": 0.0, "right": 0.0, "dir": -1, "fire": 1.4, "speed": 0.0},
		{"kind": "walker", "unit": "rocket_devastator", "x": 2290.0, "y": 228.0, "hp": 4, "max_hp": 4, "left": 2110.0, "right": 2380.0, "dir": -1, "fire": 1.1, "speed": 25.0},
		{"kind": "walker", "unit": "heavy_devastator", "x": 2655.0, "y": 228.0, "hp": 5, "max_hp": 5, "left": 2588.0, "right": 2794.0, "dir": -1, "fire": 0.9, "speed": 28.0},
		{"kind": "warden", "x": 2904.0, "y": 228.0, "hp": 22, "max_hp": 22, "left": 0.0, "right": 0.0, "dir": -1, "fire": 1.5, "speed": 0.0}
	]

func _side_enemies() -> Array[Dictionary]:
	return [
		{"kind":"walker","unit":"berserker","x":408.0,"y":228.0,"hp":4,"max_hp":4,"left":340.0,"right":517.0,"dir":-1,"fire":1.1,"speed":27.0},
		{"kind":"turret","x":729.0,"y":228.0,"hp":5,"max_hp":5,"left":0.0,"right":0.0,"dir":-1,"fire":1.6,"speed":0.0},
		{"kind":"walker","unit":"rocket_devastator","x":1004.0,"y":228.0,"hp":5,"max_hp":5,"left":942.0,"right":1096.0,"dir":-1,"fire":0.9,"speed":27.0}
	]

func _archive_enemies() -> Array[Dictionary]:
	return [{"kind":"turret","x":517.0,"y":228.0,"hp":5,"max_hp":5,"left":0.0,"right":0.0,"dir":-1,"fire":1.3,"speed":0.0}]

func _blacksite_enemies() -> Array[Dictionary]:
	return [
		{"kind":"drone","x":285.0,"y":138.0,"hp":3,"max_hp":3,"left":180.0,"right":425.0,"dir":-1,"fire":1.1,"speed":46.0,"home_y":138.0,"phase":4.8,"stun":0.0},
		{"kind":"walker","unit":"devastator","x":685.0,"y":228.0,"hp":5,"max_hp":5,"left":652.0,"right":790.0,"dir":-1,"fire":1.1,"speed":29.0},
		{"kind":"drone","x":980.0,"y":130.0,"hp":3,"max_hp":3,"left":824.0,"right":1112.0,"dir":-1,"fire":1.6,"speed":46.0,"home_y":130.0,"phase":16.6,"stun":0.0},
		{"kind":"turret","x":1420.0,"y":228.0,"hp":6,"max_hp":6,"left":0.0,"right":0.0,"dir":-1,"fire":1.2,"speed":0.0}
	]

func _reactor_enemies() -> Array[Dictionary]:
	return [
		{"kind":"drone","x":285.0,"y":126.0,"hp":3,"max_hp":3,"left":150.0,"right":395.0,"dir":-1,"fire":1.2,"speed":43.0,"home_y":126.0,"phase":4.8,"stun":0.0},
		{"kind":"walker","unit":"heavy_devastator","x":626.0,"y":228.0,"hp":5,"max_hp":5,"left":565.0,"right":720.0,"dir":-1,"fire":1.4,"speed":26.0},
		{"kind":"sentinel","x":1038.0,"y":228.0,"hp":32,"max_hp":32,"left":0.0,"right":0.0,"dir":-1,"fire":1.65,"speed":0.0,"stun":0.0}
	]

func _sector_width() -> float:
	if sector == "sublevel": return 1170.0
	if sector == "archive": return 760.0
	if sector == "blacksite": return 1650.0
	if sector == "reactor": return 1200.0
	return WORLD_END

func _travel(to_sector: String, x: float, y: float) -> void:
	sector_enemies[sector] = enemies.duplicate()
	sector = to_sector
	visited_sectors[to_sector] = true
	enemies.clear()
	for e in sector_enemies[to_sector]: enemies.append(e)
	world_solids.clear()
	for block in sector_solids[to_sector]: world_solids.append(block)
	player_x = x
	player_y = y
	run_phase = 0.0
	vx = 0.0
	vy = 0.0
	grounded = false
	jump_count = 0
	camera_x = clampf(x - 190.0,0.0,_sector_width() - VIEW_W)
	bullets.clear()
	orbital_warning = -1.0
	strat_input = false
	map_open = false
	if to_sector == "blacksite" or to_sector == "reactor":
		checkpoint_sector = to_sector
		checkpoint_x = 84.0 if to_sector == "blacksite" else 86.0
		checkpoint_y = 228.0
	_play_sound("terminal",-8.0)
	_save_progress()

const SAVE_PATH: String = "user://behind_enemy_lines_v060.json"
const OLD_SAVE_PATH: String = "user://behind_enemy_lines_v050.json"
const LEGACY_SAVE_PATH: String = "user://behind_enemy_lines_v040.json"
const ORIGINAL_SAVE_PATH: String = "user://behind_enemy_lines_v030.json"

func _save_progress() -> void:
	var record: Dictionary = {"version":5,"jets":can_double_jump,"comms":comms_restored,"cutter":arc_cutter,
		"armor":armor_recovered,"intel":recovered_logs.duplicate(),"visited":visited_sectors.duplicate(),
		"checkpoint":checkpoint_index,"checkpoint_sector":checkpoint_sector,"checkpoint_x":checkpoint_x,
		"emp":emp_recovered,"junction_a":junction_a,"junction_b":junction_b,"reactor_disabled":reactor_disabled,
		"boss_defeated":boss_defeated,"sentinel_defeated":sentinel_defeated,
		"stim":stim_used,"deaths":total_deaths,"kills":enemies_destroyed}
	var file := FileAccess.open(SAVE_PATH,FileAccess.WRITE)
	if file != null: file.store_string(JSON.stringify(record))

func _has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH) or FileAccess.file_exists(OLD_SAVE_PATH) or FileAccess.file_exists(LEGACY_SAVE_PATH) or FileAccess.file_exists(ORIGINAL_SAVE_PATH)

func _resume_progress() -> bool:
	if not _has_save(): return false
	var read_path: String = SAVE_PATH if FileAccess.file_exists(SAVE_PATH) else (OLD_SAVE_PATH if FileAccess.file_exists(OLD_SAVE_PATH) else (LEGACY_SAVE_PATH if FileAccess.file_exists(LEGACY_SAVE_PATH) else ORIGINAL_SAVE_PATH))
	var file := FileAccess.open(read_path,FileAccess.READ)
	if file == null: return false
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if typeof(parsed) != TYPE_DICTIONARY: return false
	var record: Dictionary = parsed
	if int(record.get("version",0)) not in [3,4,5]: return false
	_reset_mission()
	can_double_jump = bool(record.get("jets",false))
	comms_restored = bool(record.get("comms",false))
	arc_cutter = bool(record.get("cutter",false))
	armor_recovered = bool(record.get("armor",false))
	max_health = 6 if armor_recovered else 5
	health = max_health
	for entry in record.get("intel",[]):
		var index: int = int(entry)
		if index >= 0 and index < LOGS.size() and not recovered_logs.has(index): recovered_logs.append(index)
	var seen: Dictionary = record.get("visited",{})
	visited_sectors = {"main":true}
	for k in seen.keys(): visited_sectors[k] = seen[k]
	checkpoint_index = clampi(int(record.get("checkpoint",0)),0,2)
	if checkpoint_index == 2: checkpoint_x = 2220.0
	elif checkpoint_index == 1: checkpoint_x = 1390.0
	boss_defeated = bool(record.get("boss_defeated",false))
	emp_recovered = bool(record.get("emp",false))
	junction_a = bool(record.get("junction_a",false))
	junction_b = bool(record.get("junction_b",false))
	reactor_disabled = bool(record.get("reactor_disabled",false))
	sentinel_defeated = bool(record.get("sentinel_defeated",false))
	if int(record.get("version",0)) >= 4:
		var saved_sector: String = str(record.get("checkpoint_sector","main"))
		if sector_enemies.has(saved_sector) and saved_sector in ["main","blacksite","reactor"]:
			checkpoint_sector = saved_sector
			checkpoint_x = clampf(float(record.get("checkpoint_x",checkpoint_x)),70.0, _sector_width() if saved_sector == "main" else (1650.0 if saved_sector == "blacksite" else 1200.0))
	else:
		if boss_defeated: checkpoint_x = 2840.0
	sector = checkpoint_sector
	enemies.clear()
	for e in sector_enemies[sector]: enemies.append(e)
	world_solids.clear()
	for block in sector_solids[sector]: world_solids.append(block)
	player_x = checkpoint_x
	player_y = 228.0
	camera_x = clampf(player_x-190.0,0.0,_sector_width()-VIEW_W)
	stim_used = bool(record.get("stim",false))
	total_deaths = int(record.get("deaths",0))
	enemies_destroyed = int(record.get("kills",0))
	mode = "playing"
	_save_progress()
	_notify("MISSION RESUMED // CHECKPOINT RECOVERED",3.0)
	return true

func _reset_mission() -> void:
	sector = "main"
	arc_cutter = false
	armor_recovered = false
	emp_recovered = false
	pulse_cooldown = 0.0
	pulse_fx = 0.0
	laser_off = 0.0
	junction_a = false
	junction_b = false
	reactor_disabled = false
	sentinel_awake = false
	sentinel_defeated = false
	checkpoint_sector = "main"
	max_health = 5
	visited_sectors = {"main":true}
	sector_enemies = {"main":_base_enemies(),"sublevel":_side_enemies(),"archive":_archive_enemies(),"blacksite":_blacksite_enemies(),"reactor":_reactor_enemies()}
	world_solids.clear()
	for block in sector_solids["main"]: world_solids.append(block)
	player_x = 90.0
	player_y = 206.0
	run_phase = 0.0
	vx = 0.0
	vy = 0.0
	facing = 1
	grounded = false
	jump_count = 0
	can_double_jump = false
	comms_restored = false
	boss_awake = false
	boss_defeated = false
	health = max_health
	ammo = MAG_SIZE
	reload_timer = 0.0
	fire_timer = 0.0
	hurt_timer = 0.0
	dash_timer = 0.0
	dash_cooldown = 0.0
	strat_cooldown = 0.0
	strat_input = false
	strat_progress = 0
	orbital_warning = -1.0
	screen_flash = 0.0
	checkpoint_x = 90.0
	checkpoint_y = 228.0
	checkpoint_index = 0
	camera_x = 0.0
	map_open = false
	notify = ""
	notify_timer = 0.0
	tutorial_timer = 12.0
	elapsed = 0.0
	enemies_destroyed = 0
	total_deaths = 0
	stim_used = false
	recoil_shake = 0.0
	mouse_aim_time = 0.0
	recovered_logs.clear()
	enemies.clear()
	for e in sector_enemies["main"]: enemies.append(e)
	bullets.clear()
	particles.clear()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		mouse_aim_time = 4.0
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		mouse_aim_time = 4.0

func _physics_process(delta: float) -> void:
	if Input.is_action_just_pressed("music_toggle"):
		music_enabled = not music_enabled
	if mode == "title" and Input.is_action_just_pressed("resume"):
		if _resume_progress(): return
	if Input.is_action_just_pressed("confirm"):
		if mode == "title" or mode == "victory":
			_reset_mission()
			_show_dialogue(INTRO)
			return
		if mode == "dialogue":
			dialog_age = 0.0
			_play_sound("radio_chirp",-19.0)
			dialog_page += 1
			if dialog_page >= dialog_pages.size():
				mode = dialog_resume
			return
	if Input.is_action_just_pressed("pause"):
		if mode == "playing":
			mode = "pause"
			return
		elif mode == "pause":
			mode = "playing"
			return
	if mode != "playing":
		return

	elapsed += delta
	anim_clock += delta
	fire_timer = maxf(0.0, fire_timer - delta)
	landing_fx = maxf(0.0,landing_fx-delta)
	hurt_timer = maxf(0.0, hurt_timer - delta)
	dash_timer = maxf(0.0, dash_timer - delta)
	dash_cooldown = maxf(0.0, dash_cooldown - delta)
	strat_cooldown = maxf(0.0, strat_cooldown - delta)
	pulse_cooldown = maxf(0.0,pulse_cooldown-delta)
	pulse_fx = maxf(0.0,pulse_fx-delta)
	laser_off = maxf(0.0,laser_off-delta)
	notify_timer = maxf(0.0, notify_timer - delta)
	tutorial_timer = maxf(0.0, tutorial_timer - delta)
	screen_flash = maxf(0.0, screen_flash - delta * 2.7)
	recoil_shake = maxf(0.0, recoil_shake - delta * 13.0)
	mouse_aim_time = maxf(0.0, mouse_aim_time - delta)
	if reload_timer > 0.0:
		reload_timer = maxf(0.0, reload_timer - delta)
		if reload_timer == 0.0:
			ammo = MAG_SIZE
			_play_sound("pickup", -14.0)

	if Input.is_action_just_pressed("pulse") and not strat_input:
		_emp_pulse()
	if Input.is_action_just_pressed("map"):
		map_open = not map_open
	if Input.is_action_just_pressed("stratagem") and comms_restored:
		if strat_input:
			strat_input = false
		elif strat_cooldown <= 0.0 and orbital_warning < 0.0:
			strat_input = true
			strat_progress = 0
			_notify("ORBITAL STRIKE  //  INPUT DIRECTIONAL CODE", 1.8)
	if strat_input:
		_read_stratagem()
	else:
		_update_player(delta)
		if Input.is_action_just_pressed("interact"):
			_interact()
		if Input.is_action_just_pressed("reload"):
			_reload()
		if (Input.is_action_pressed("fire") or Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)) and fire_timer <= 0.0:
			_fire()

	_update_enemies(delta)
	_update_bullets(delta)
	_update_particles(delta)
	_update_world_events(delta)
	camera_x = clampf(player_x - 190.0, 0.0, _sector_width() - VIEW_W)

func _read_stratagem() -> void:
	var entry: String = ""
	if Input.is_action_just_pressed("up"):
		entry = "U"
	elif Input.is_action_just_pressed("right"):
		entry = "R"
	elif Input.is_action_just_pressed("down"):
		entry = "D"
	elif Input.is_action_just_pressed("left"):
		entry = "L"
	if entry == "":
		return
	if entry == STRAT_CODE[strat_progress]:
		strat_progress += 1
		_play_sound("terminal", -21.0)
		if strat_progress == STRAT_CODE.size():
			strat_input = false
			strat_cooldown = 11.0
			orbital_target = clampf(player_x + facing * 146.0, 75.0, _sector_width() - 75.0)
			orbital_warning = 0.95
			_notify("ORBITAL STRIKE INBOUND", 1.4)
	else:
		strat_progress = 0
		_play_sound("hurt", -20.0)
		_notify("INVALID CODE // TRY AGAIN", 1.0)

func _solid_list() -> Array[Rect2]:
	if comms_restored or sector != "main":
		return world_solids
	var all_solids: Array[Rect2] = world_solids.duplicate()
	all_solids.append(dynamic_gate)
	return all_solids

func _player_box(px: float, py: float) -> Rect2:
	return Rect2(px - PLAYER_HALF_W, py - PLAYER_H, PLAYER_HALF_W * 2.0, PLAYER_H)

func _update_player(delta: float) -> void:
	var axis: float = Input.get_axis("left", "right")
	if absf(axis) > 0.15 and not Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
		facing = 1 if axis > 0.0 else -1
	if dash_timer <= 0.0:
		vx = axis * MOVE_SPEED
		if Input.is_action_just_pressed("dash") and dash_cooldown <= 0.0:
			dash_timer = 0.28
			dash_cooldown = 1.20
			vx = float(facing) * 345.0
			_spawn_puff(player_x, player_y - 8.0, 8, Color("#c8a14b"))
	else:
		vx = float(facing) * 345.0
	if Input.is_action_just_pressed("jump"):
		if grounded:
			vy = JUMP_SPEED
			grounded = false
			jump_count = 1
			_play_sound("jump", -12.0)
			_spawn_puff(player_x, player_y, 5, Color("#81718a"))
		elif can_double_jump and jump_count < 2:
			vy = JUMP_SPEED * 0.88
			jump_count = 2
			_play_sound("jump", -7.0)
			_spawn_puff(player_x, player_y - 6.0, 11, Color("#ffca16"))
	vy = minf(600.0, vy + GRAVITY * delta)

	var solids: Array[Rect2] = _solid_list()
	var old_x: float = player_x
	player_x += vx * delta
	var horiz: Rect2 = _player_box(player_x, player_y)
	for block in solids:
		if horiz.intersects(block):
			if vx > 0.0:
				player_x = block.position.x - PLAYER_HALF_W
			elif vx < 0.0:
				player_x = block.end.x + PLAYER_HALF_W
			horiz = _player_box(player_x, player_y)
	player_x = clampf(player_x, 14.0, _sector_width() - 14.0)
	if grounded and absf(player_x - old_x) > 0.0:
		run_phase = fposmod(run_phase + absf(player_x - old_x) / 90.0, 1.0)

	var old_y: float = player_y
	var was_grounded: bool = grounded
	var fall_velocity: float = vy
	player_y += vy * delta
	grounded = false
	var vert: Rect2 = _player_box(player_x, player_y)
	for block in solids:
		if not vert.intersects(block):
			continue
		if vy >= 0.0 and old_y <= block.position.y + 6.0:
			player_y = block.position.y
			vy = 0.0
			grounded = true
			jump_count = 0
		elif vy < 0.0 and old_y - PLAYER_H >= block.end.y - 6.0:
			player_y = block.end.y + PLAYER_H
			vy = 0.0
		vert = _player_box(player_x, player_y)
	if grounded and not was_grounded and fall_velocity > 70.0:
		landing_fx = 0.24
		_spawn_puff(player_x,player_y - 2.0,mini(11,int(fall_velocity / 50.0)),Color("#99869e"))
	if grounded and absf(vx) > 15.0 and int(anim_clock * 15.0) != int((anim_clock - delta) * 15.0):
		_spawn_puff(player_x - facing * 7.0,player_y - 1.0,2,Color("#897789"))
	if player_y > 325.0:
		_respawn()

func _emp_pulse() -> void:
	if not emp_recovered:
		_notify("EMP UNAVAILABLE // SEARCH THE BLACKSITE",2.0)
		return
	if pulse_cooldown > 0.0:
		_notify("EMP RECHARGING // %dS" % ceili(pulse_cooldown),1.0)
		return
	pulse_cooldown = 9.0
	pulse_fx = 0.48
	laser_off = 5.0
	recoil_shake = maxf(recoil_shake,3.1)
	_play_sound("terminal",-2.0)
	_spawn_puff(player_x,player_y-27.0,38,Color("#7cebdc"))
	for b in bullets:
		if int(b["team"]) == 1 and Vector2(float(b["x"]),float(b["y"])).distance_to(Vector2(player_x,player_y-22.0)) < 165.0:
			b["life"] = 0.0
	for e in enemies:
		if int(e["hp"]) > 0 and (e["kind"] != "warden" or boss_awake) and (e["kind"] != "sentinel" or sentinel_awake) and Vector2(float(e["x"]),float(e["y"])-30.0).distance_to(Vector2(player_x,player_y-22.0)) < 145.0:
			e["stun"] = 2.2
			e["hp"] = int(e["hp"]) - (1 if e["kind"] == "sentinel" else 2)
			e["hit"] = 0.4
			if int(e["hp"]) <= 0: _kill_enemy(e)
	_notify("EMP BURST // HOSTILE SYSTEMS DISRUPTED",1.5)

# Rifle aim and projectiles share the weapon-art muzzle transform.
# Right art: pivot (43,28), exit (71,29). Left art is mirrored in 84px.
func _rifle_geometry() -> Dictionary:
	var aim := Vector2(float(facing), 0.0)
	var mouse_active: bool = Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and mouse_aim_time > 0.0
	if mouse_active:
		var cursor: Vector2 = get_local_mouse_position() + Vector2(camera_x, 0.0)
		aim = cursor - Vector2(player_x, player_y - 44.0)
		if aim.length() < 8.0: aim = Vector2(float(facing), 0.0)
	elif Input.get_connected_joypads().size() > 0:
		var pad: int = Input.get_connected_joypads()[0]
		var stick := Vector2(Input.get_joy_axis(pad, JOY_AXIS_RIGHT_X), Input.get_joy_axis(pad, JOY_AXIS_RIGHT_Y))
		if stick.length() > 0.32: aim = stick
	if aim.length() < 0.01: aim = Vector2(float(facing), 0.0)
	var direction := aim.normalized()
	var turn: int = facing
	if direction.x < -0.001: turn = -1
	elif direction.x > 0.001: turn = 1
	var pivot_art_x: float = 43.0 if turn > 0 else 40.0
	var tip_dx: float = 28.0 if turn > 0 else -28.0
	var theta: float = atan2(direction.y, direction.x)
	var rot: float = theta - (0.0 if turn > 0 else PI)
	var recoil: float = 1.5 * minf(1.0, fire_timer / 0.165) if fire_timer > 0.0 else 0.0
	var pivot := Vector2(player_x - 42.0 + pivot_art_x, player_y - 44.0) - direction * recoil
	var offset := Vector2(tip_dx, 1.0).rotated(rot)
	return {"pivot":pivot,"muzzle":pivot + offset,"rotation":rot,"theta":theta,
		"art_pivot_x":pivot_art_x,"direction":direction,"face":turn}

func _fire() -> void:
	if fire_timer > 0.0 or reload_timer > 0.0 or dash_timer > 0.05: return
	if ammo <= 0:
		_reload()
		return
	ammo -= 1
	fire_timer = 0.165
	var gun: Dictionary = _rifle_geometry()
	facing = int(gun["face"])
	var muzzle: Vector2 = gun["muzzle"]
	var shot_direction: Vector2 = gun["direction"]
	if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and mouse_aim_time > 0.0:
		var cursor := get_local_mouse_position() + Vector2(camera_x, 0.0)
		var target_direction := cursor - muzzle
		if target_direction.length() > 3.0: shot_direction = target_direction.normalized()
	bullets.append({"x":muzzle.x,"y":muzzle.y,"vx":shot_direction.x * 460.0,
		"vy":shot_direction.y * 460.0,"team":0,"life":1.12,"damage":1})
	_spawn_puff(muzzle.x,muzzle.y,5,Color("#ffdf41"))
	recoil_shake = maxf(recoil_shake,0.7)
	_play_sound("rifle",-10.0)

func _reload() -> void:
	if ammo < MAG_SIZE and reload_timer <= 0.0:
		reload_timer = 0.90
		_notify("RELOADING...", 0.8)
		_play_sound("reload", -16.0)

func _interact() -> void:
	for i in range(LOGS.size()):
		var log: Dictionary = LOGS[i]
		if str(log["room"]) != sector: continue
		if not recovered_logs.has(i) and _near(float(log["x"]), float(log["y"]), 56.0):
			recovered_logs.append(i)
			_save_progress()
			_play_sound("terminal", -15.0)
			_spawn_puff(float(log["x"]), float(log["y"]), 12, Color("#ffdf56"))
			_show_dialogue([{"speaker":str(log["title"]),"a":str(log["a"]),"b":str(log["b"])}])
			return
	if sector == "blacksite":
		if _near(67.0,205.0,65.0):
			_travel("main",3020.0,228.0)
			return
		if not junction_a and _near(451.0,151.0,68.0):
			junction_a = true
			_save_progress()
			_play_sound("terminal",-5.0)
			_show_dialogue([{"speaker":"POWER JUNCTION ALPHA // ONLINE","a":"ONE AUXILIARY CIRCUIT RESTORED.","b":"FIND THE REMAINING JUNCTION DEEPER INSIDE."}])
			return
		if not emp_recovered and _near(850.0,154.0,66.0):
			emp_recovered = true
			_save_progress()
			_play_sound("pickup",-4.0)
			_spawn_puff(850.0,154.0,31,Color("#86f5df"))
			_show_dialogue([{"speaker":"EMP DISRUPTOR // RECOVERED","a":"PRESS G FOR AN AREA ELECTROMAGNETIC PULSE.","b":"STUNS AUTOMATONS AND CLEARS HOSTILE FIRE."}])
			return
		if not junction_b and _near(1339.0,156.0,66.0):
			if not emp_recovered:
				_notify("EMP DISRUPTOR REQUIRED // ACCESS DENIED",2.1)
				return
			junction_b = true
			_save_progress()
			_play_sound("terminal",-5.0)
			_show_dialogue([{"speaker":"POWER JUNCTION BETA // ONLINE","a":"BLACKSITE REACTOR DOOR UNSEALED.","b":"RETURN TO THE EASTERN LIFT."}])
			return
		if _near(1555.0,202.0,65.0):
			if not junction_a or not junction_b:
				_notify("REACTOR LOCKED // TWO POWER JUNCTIONS",2.1)
				return
			_travel("reactor",86.0,228.0)
			_show_dialogue([{"speaker":"REACTOR LEVEL // SECURITY RED","a":"THE GUARDIAN IS POWERED BY A COOLANT CORE.","b":"DISABLE ITS FEED BEFORE YOU ATTACK."}])
			return
		_notify("LOCATE BOTH JUNCTIONS AND THE EMP DISRUPTOR",1.3)
		return
	if sector == "reactor":
		if _near(67.0,205.0,65.0):
			_travel("blacksite",1535.0,228.0)
			return
		if not reactor_disabled and _near(506.0,144.0,70.0):
			reactor_disabled = true
			_save_progress()
			_play_sound("terminal",-5.0)
			_spawn_puff(506.0,143.0,32,Color("#ffce57"))
			_show_dialogue([{"speaker":"COOLANT REGULATOR // DISABLED","a":"GUARDIAN SHIELDS COLLAPSING.","b":"ADVANCE TO THE REACTOR SENTINEL."}])
			return
		_notify("PUSH FORWARD // DESTROY THE SENTINEL" if reactor_disabled else "DISABLE THE COOLANT REGULATOR",1.3)
		return
	if sector == "sublevel":
		if _near(67.0,205.0,65.0):
			_travel("main",1490.0,178.0)
			_notify("RETURNED // DELTA-9 UPLINK",2.2)
			return
		if not arc_cutter and _near(948.0,156.0,64.0):
			arc_cutter = true
			_save_progress()
			_play_sound("pickup",-6.0)
			_spawn_puff(948.0,156.0,28,Color("#ffca2c"))
			_show_dialogue([{"speaker":"INDUSTRIAL ARC CUTTER RECOVERED","a":"SEVERED BULKHEADS CAN NOW BE OPENED.","b":"REVISIT THE SEALED COLONY ARCHIVE."}])
			return
		_notify("EXPLORE THE MAINTENANCE WORKS",1.2)
		return
	if sector == "archive":
		if _near(66.0,205.0,65.0):
			_travel("main",596.0,164.0)
			return
		if not armor_recovered and _near(610.0,172.0,65.0):
			armor_recovered = true
			max_health = 6
			health = max_health
			_save_progress()
			_play_sound("pickup",-6.0)
			_spawn_puff(610.0,172.0,28,Color("#6fe8cf"))
			_show_dialogue([{"speaker":"SUPER EARTH ARMORY // RECOVERED","a":"REINFORCED PLATING INCREASES MAX HEALTH.","b":"THE ARCHIVE LOGS HINT AT SABOTAGE."}])
			return
		_notify("NO FURTHER EQUIPMENT DETECTED",1.0)
		return
	if boss_defeated and _near(3025.0,203.0,67.0):
		_travel("blacksite",84.0,228.0)
		_show_dialogue([{"speaker":"BLACKSITE ZERO // SUBSURFACE ACCESS","a":"NO SUPER EARTH MARKINGS. NO EVACUATION SIGNS.","b":"RESTORE BOTH POWER JUNCTIONS TO DESCEND."}])
		return
	if can_double_jump and _near(1490.0,154.0,65.0):
		_travel("sublevel",67.0,228.0)
		_notify("MAINTENANCE WORKS // SUBLEVEL 06",2.5)
		return
	if _near(596.0,141.0,65.0):
		if not arc_cutter:
			_notify("BULKHEAD SEALED // ARC CUTTER REQUIRED",3.0)
			return
		_travel("archive",67.0,228.0)
		_notify("HIDDEN ARCHIVE // SECURITY BYPASSED",2.5)
		return
	if not can_double_jump and _near(1136.0, 149.0, 61.0):
		can_double_jump = true
		_save_progress()
		_play_sound("pickup", -5.0)
		_spawn_puff(1136.0, 143.0, 20, Color("#ffca16"))
		_show_dialogue([
			{"speaker":"FIELD EQUIPMENT RECOVERED", "a":"EXPERIMENTAL JUMP-JET THRUSTERS ONLINE.", "b":"PRESS JUMP AGAIN WHILE AIRBORNE."}
		])
		return
	if not comms_restored and _near(1708.0, 129.0, 61.0):
		comms_restored = true
		_save_progress()
		_play_sound("terminal", -3.0)
		_spawn_puff(1708.0, 129.0, 25, Color("#ffda45"))
		_show_dialogue([
			{"speaker":"RELAY DELTA-9 // RECONNECTED", "a":"SES JUDGMENT OF DAWN HAS YOUR SIGNAL.", "b":"ORBITAL FIRE SUPPORT RESTORED."},
			{"speaker":"MISSION CONTROL", "a":"EASTERN SECURITY GATE UNLOCKED.", "b":"DESTROY THE WARDEN AND SECURE THE SITE."},
			{"speaker":"STRATAGEM UNLOCKED", "a":"PRESS Q, THEN: UP  RIGHT  DOWN  UP.", "b":"DIRECT AN ORBITAL STRIKE IN FRONT OF YOU."}
		])
		return
	_notify("NOTHING TO INTERACT WITH", 1.0)

func _near(tx: float, ty: float, radius: float) -> bool:
	return Vector2(player_x, player_y - 24.0).distance_to(Vector2(tx, ty)) < radius

func _has_line_of_sight(ax: float, ay: float, bx: float, by: float) -> bool:
	var steps: int = maxi(2,int(ceil(Vector2(bx-ax,by-ay).length()/11.0)))
	for j in range(1,steps):
		var fraction: float = float(j)/float(steps)
		var point := Vector2(lerpf(ax,bx,fraction),lerpf(ay,by,fraction))
		for wall in _solid_list():
			if wall.has_point(point): return false
	return true

func _enemy_shoot(e: Dictionary) -> void:
	if str(e.get("unit","")) == "berserker": return
	var heavy: bool = e["kind"] in ["warden","sentinel"]
	var sent: bool = e["kind"] == "sentinel"
	var fly: bool = e["kind"] == "drone"
	var phase_two: bool = heavy and float(e["hp"])/float(e["max_hp"]) < 0.5
	var mx: float = float(e["x"])+float(e["dir"])*(45.0 if heavy else (18.0 if fly else 22.0))
	var my: float = float(e["y"])-(0.0 if fly else (60.0 if heavy else 27.0))
	var angle: float = Vector2(float(e.get("aim_x",player_x))-mx,float(e.get("aim_y",player_y-24.0))-my).angle()
	if sent:
		var offsets: Array = [-0.48,-0.24,0.0,0.24,0.48] if phase_two else [-0.26,0.0,0.26]
		for off in offsets:
			var a: float = angle+float(off)
			var speed: float = 225.0 if phase_two else 206.0
			bullets.append({"x":mx,"y":my,"vx":cos(a)*speed,"vy":sin(a)*speed,"team":1,"life":3.0,"damage":1})
		_spawn_puff(mx,my,12,Color("#ff6d4f"))
	elif str(e.get("unit","")) == "rocket_devastator":
		bullets.append({"x":mx,"y":my,"vx":cos(angle)*150.0,"vy":sin(angle)*150.0,"team":1,"life":3.1,"damage":1,"rocket":true})
		_spawn_puff(mx,my,8,Color("#ff734e"))
	elif heavy and phase_two:
		for off in [-0.1,0.1]:
			var a: float = angle+float(off)
			bullets.append({"x":mx,"y":my,"vx":cos(a)*275.0,"vy":sin(a)*275.0,"team":1,"life":2.8,"damage":1})
		_spawn_puff(mx,my,8,Color("#ff8d4f"))
	else:
		var speed: float = 180.0 if not heavy and not fly else (170.0 if fly else 265.0)
		bullets.append({"x":mx,"y":my,"vx":cos(angle)*speed,"vy":sin(angle)*speed,"team":1,"life":2.9,"damage":1})
		_spawn_puff(mx,my,5 if fly else 3,Color("#78d8ce") if fly else Color("#ff6d4f"))

func _update_enemies(delta: float) -> void:
	for e in enemies:
		if int(e["hp"]) <= 0: continue
		if e["kind"] == "warden" and not boss_awake: continue
		if e["kind"] == "sentinel" and not sentinel_awake: continue
		var dx: float = player_x-float(e["x"])
		var distance: float = absf(dx)
		var heavy: bool = e["kind"] in ["warden","sentinel"]
		var fly: bool = e["kind"] == "drone"
		e["fire"] = float(e["fire"])-delta
		e["hit"] = maxf(0.0,float(e.get("hit",0.0))-delta)
		e["stun"] = maxf(0.0,float(e.get("stun",0.0))-delta)
		if float(e["stun"]) > 0.0:
			e["telegraph"] = 0.0
			e["hit"] = 0.13
			continue
		var eye_y: float = float(e["y"])-(0.0 if fly else (61.0 if heavy else 29.0))
		var visible: bool = distance < (410.0 if heavy else 290.0) and absf(player_y-24.0-eye_y)<165.0 and _has_line_of_sight(float(e["x"]),eye_y,player_x,player_y-24.0)
		e["alert"] = maxf(0.0,float(e.get("alert",0.0))-delta)
		if visible:
			e["alert"] = 3.1
			e["last_x"] = player_x
		if fly:
			e["x"] = clampf(float(e["x"])+float(e["dir"])*float(e["speed"])*delta,float(e["left"]),float(e["right"]))
			if float(e["x"])<=float(e["left"]) or float(e["x"])>=float(e["right"]): e["dir"]=-int(e["dir"])
			e["y"] = float(e["home_y"])+sin(anim_clock*2.3+float(e["phase"]))*9.0
		elif e["kind"] == "walker":
			if str(e.get("unit","")) == "berserker" and float(e["alert"]) > 0.0:
				var melee_goal: float = float(e.get("last_x",player_x))
				var melee_direction: float = 1.0 if melee_goal>=float(e["x"]) else -1.0
				e["dir"] = int(melee_direction)
				if distance > 24.0:
					e["x"] = clampf(float(e["x"])+melee_direction*float(e["speed"])*1.8*delta,float(e["left"]),float(e["right"]))
			elif float(e["alert"]) > 0.0:
				var goal: float = float(e.get("last_x",player_x))
				var direction: float = 1.0 if goal>=float(e["x"]) else -1.0
				e["dir"] = int(direction)
				if absf(goal-float(e["x"])) > 70.0:
					e["x"] = clampf(float(e["x"])+direction*float(e["speed"])*1.2*delta,float(e["left"]),float(e["right"]))
				elif visible and distance < 52.0:
					e["x"] = clampf(float(e["x"])-direction*float(e["speed"])*0.43*delta,float(e["left"]),float(e["right"]))
			else:
				var next_x: float = float(e["x"])+float(e["dir"])*float(e["speed"])*0.75*delta
				if next_x<float(e["left"]) or next_x>float(e["right"]): e["dir"]=-int(e["dir"])
				else: e["x"]=next_x
		else: e["dir"] = 1 if dx>=0 else -1
		var winding: float = float(e.get("telegraph",0.0))
		if winding > 0.0:
			e["telegraph"] = winding-delta
			if float(e["telegraph"]) <= 0.0:
				_enemy_shoot(e)
				e["telegraph"] = 0.0
				var phase_two: bool = heavy and float(e["hp"])/float(e["max_hp"])<0.5
				e["fire"] = (0.92 if phase_two else 1.32) if e["kind"] == "sentinel" else ((0.8 if phase_two else 1.13) if heavy else (1.45 if fly else (1.4 if e["kind"]=="turret" else 1.55)))
				e["fire"] += randf_range(0.0,0.22)
		elif visible and float(e["fire"]) <= 0.0 and str(e.get("unit","")) != "berserker":
			e["telegraph"] = 0.67 if heavy else (0.4 if fly else (0.52 if e["kind"]=="turret" else 0.43))
			e["aim_x"] = player_x+clampf(vx*0.16,-24.0,24.0)
			e["aim_y"] = player_y-24.0
			if heavy: _play_sound("enemy_warning",-21.0)
		if e["kind"] == "walker" and distance < (31.0 if str(e.get("unit","")) == "berserker" else 22.0) and absf(player_y-float(e["y"]))<37.0: _hurt_player(1)
		if heavy and distance < 55.0 and absf(player_y-float(e["y"]))<68.0: _hurt_player(1)

func _update_bullets(delta: float) -> void:
	for b in bullets:
		b["x"] = float(b["x"]) + float(b["vx"]) * delta
		b["y"] = float(b["y"]) + float(b.get("vy", 0.0)) * delta
		b["life"] = float(b["life"]) - delta
		var bx: float = float(b["x"])
		var by: float = float(b["y"])
		if bx < 0.0 or bx > _sector_width() or by > 270.0 or by < 0.0:
			b["life"] = 0.0
			continue
		for solid in _solid_list():
			if solid.has_point(Vector2(bx, by)):
				b["life"] = 0.0
				break
		if float(b["life"]) <= 0.0:
			continue
		if int(b["team"]) == 1:
			if _player_box(player_x, player_y).grow(1.0).has_point(Vector2(bx, by)):
				b["life"] = 0.0
				_hurt_player(int(b["damage"]))
		else:
			for e in enemies:
				if int(e["hp"]) <= 0:
					continue
				if e["kind"] == "warden" and not boss_awake: continue
				if e["kind"] == "sentinel" and not sentinel_awake: continue
				var half_w: float = 43.0 if e["kind"] in ["warden","sentinel"] else 21.0
				var height: float = 92.0 if e["kind"] in ["warden","sentinel"] else (37.0 if e["kind"] == "drone" else 43.0)
				if Rect2(float(e["x"]) - half_w, float(e["y"]) - height, half_w * 2.0, height).has_point(Vector2(bx, by)):
					e["hp"] = int(e["hp"]) - int(b["damage"])
					b["life"] = 0.0
					_spawn_puff(bx, by, 5, Color("#ff6652"))
					e["hit"] = 0.16
					recoil_shake = maxf(recoil_shake, 1.1)
					if int(e["hp"]) <= 0:
						_kill_enemy(e)
					break
	bullets = bullets.filter(func(b: Dictionary) -> bool: return float(b["life"]) > 0.0)

func _kill_enemy(e: Dictionary) -> void:
	recoil_shake = maxf(recoil_shake,7.0 if e["kind"] in ["warden","sentinel"] else 1.7)
	_spawn_puff(float(e["x"]),float(e["y"])-25.0,50 if e["kind"] in ["warden","sentinel"] else 12,Color("#f17c36"))
	_play_sound("explosion",-3.0 if e["kind"] in ["warden","sentinel"] else -13.0)
	enemies_destroyed += 1
	if e["kind"] == "warden":
		boss_defeated = true
		checkpoint_sector = "main"
		checkpoint_x = 2840.0
		_save_progress()
		orbital_warning = -1.0
		_show_dialogue([
			{"speaker":"MISSION CONTROL","a":"WARDEN NEUTRALIZED. EXTRACTION SIGNAL FOUND.","b":"BUT THE COLONY TRANSPONDER IS STILL ACTIVE."},
			{"speaker":"INTERCEPTED TRANSMISSION","a":"THE SOURCE IS UNDERNEATH THE WARDEN CHAMBER.","b":"FIND THE SEALED LIFT AT THE FAR EASTERN WALL."},
			{"speaker":"ACT II // BELOW THE SILENCE","a":"ENTER THE BLACKSITE. RECOVER THE TRUTH.","b":"THE COLONY IS NOT AS EMPTY AS IT SEEMS."}
		])
	elif e["kind"] == "sentinel":
		sentinel_defeated = true
		_save_progress()
		orbital_warning = -1.0
		_show_dialogue([
			{"speaker":"MISSION CONTROL // PRIORITY BLACK","a":"REACTOR GUARDIAN DESTROYED. SIGNAL UNMASKED.","b":"A SURVIVOR BEACON HAS COME ONLINE."},
			{"speaker":"UNKNOWN TRANSMISSION","a":"IF YOU CAN HEAR THIS... WE ARE STILL HERE.","b":"PLEASE DO NOT TRUST THE EXTRACTION ORDER."},
			{"speaker":"OPERATION DEAD SIGNAL // COMPLETE","a":"THE NEXT OPERATION STARTS WITH A CHOICE.","b":"CONTINUE THE INVESTIGATION IN CHAPTER TWO."}
		],"victory")

func _hurt_player(damage: int) -> void:
	if hurt_timer > 0.0 or mode != "playing":
		return
	health -= damage
	hurt_timer = 1.1
	screen_flash = 0.35
	recoil_shake = maxf(recoil_shake, 3.5)
	_play_sound("hurt", -7.0)
	_spawn_puff(player_x, player_y - 21.0, 9, Color("#ff614f"))
	if health <= 0:
		_respawn()

func _respawn() -> void:
	total_deaths += 1
	if sector != checkpoint_sector: _travel(checkpoint_sector,checkpoint_x,checkpoint_y)
	player_x = checkpoint_x
	player_y = checkpoint_y - 10.0
	vx = 0.0
	vy = 0.0
	grounded = false
	health = max_health
	ammo = MAG_SIZE
	reload_timer = 0.0
	hurt_timer = 1.6
	strat_input = false
	orbital_warning = -1.0
	bullets.clear()
	if sector == "main": enemies = _base_enemies()
	elif sector == "blacksite": enemies = _blacksite_enemies()
	elif sector == "reactor": enemies = _reactor_enemies()
	elif sector == "sublevel": enemies = _side_enemies()
	else: enemies = _archive_enemies()
	sector_enemies[sector] = enemies.duplicate()
	if boss_awake:
		_notify("CHECKPOINT RESTORED // WARDEN RESET", 3.0)
	else:
		_notify("CHECKPOINT RESTORED", 2.5)

func _update_world_events(delta: float) -> void:
	if sector == "main" and checkpoint_index < 1 and player_x > 1380.0:
		checkpoint_index = 1
		checkpoint_x = 1390.0
		checkpoint_sector = "main"
		checkpoint_y = 228.0
		_save_progress()
		_notify("CHECKPOINT SYNCED // REFINERY", 2.5)
		_play_sound("pickup", -10.0)
	if sector == "main" and checkpoint_index < 2 and player_x > 2205.0:
		checkpoint_index = 2
		checkpoint_x = 2220.0
		checkpoint_sector = "main"
		checkpoint_y = 228.0
		_save_progress()
		_notify("CHECKPOINT SYNCED // SECURITY PERIMETER", 2.6)
		_play_sound("pickup", -10.0)
	if sector == "main" and not boss_awake and not boss_defeated and player_x > 2605.0 and comms_restored:
		boss_awake = true
		_show_dialogue([
			{"speaker":"AUTOMATON COMMAND LINK", "a":"UNAUTHORIZED LIFEFORM DETECTED.", "b":"WARDEN UNIT: EXTERMINATION PROTOCOL."}
		])
	if sector == "reactor" and reactor_disabled and not sentinel_awake and not sentinel_defeated and player_x > 840.0:
		sentinel_awake = true
		_show_dialogue([{"speaker":"REACTOR SENTINEL // COMMAND LINK","a":"UNREGISTERED OPERATOR DETECTED.","b":"PURGE ALL INTRUDERS."}])
	if sector == "blacksite" and laser_off <= 0.0:
		for x in [612.0,1110.0]:
			if absf(player_x-x) < 9.0 and player_y > 143.0: _hurt_player(1)
	if orbital_warning >= 0.0:
		orbital_warning -= delta
		if orbital_warning < 0.0:
			_detonate_orbital()
	# Health pickup: once per visit, intentionally simple for the first slice.
	if sector == "main" and not stim_used and health < max_health and _near(608.0, 147.0, 32.0) and not map_open:
		stim_used = true
		health = min(max_health, health + 2)
		_save_progress()
		_play_sound("pickup", -11.0)
		_notify("FIELD STIM // +2 HEALTH", 1.3)

func _detonate_orbital() -> void:
	screen_flash = 0.86
	recoil_shake = maxf(recoil_shake, 8.0)
	_play_sound("explosion", -1.0)
	_spawn_puff(orbital_target, 160.0, 52, Color("#ffb73b"))
	for e in enemies:
		if int(e["hp"]) <= 0:
			continue
		if e["kind"] == "warden" and not boss_awake: continue
		if e["kind"] == "sentinel" and not sentinel_awake: continue
		if absf(float(e["x"]) - orbital_target) < 111.0:
			e["hp"] = int(e["hp"]) - 8
			if int(e["hp"]) <= 0:
				_kill_enemy(e)
	if absf(player_x - orbital_target) < 54.0:
		_hurt_player(1) # An authentic Helldivers hazard: avoid your own blast.

func _spawn_puff(at_x: float, at_y: float, number: int, tint: Color) -> void:
	for i in range(number):
		particles.append({"x": at_x, "y": at_y,
			"vx": randf_range(-95.0, 95.0), "vy": randf_range(-96.0, 30.0),
			"t": randf_range(0.20, 0.75), "c": tint, "size": randi_range(1, 3)})
	if particles.size() > 180:
		particles = particles.slice(particles.size() - 180)

func _update_particles(delta: float) -> void:
	for p in particles:
		p["x"] = float(p["x"]) + float(p["vx"]) * delta
		p["y"] = float(p["y"]) + float(p["vy"]) * delta
		p["vy"] = float(p["vy"]) + 140.0 * delta
		p["t"] = float(p["t"]) - delta
	particles = particles.filter(func(p: Dictionary) -> bool: return float(p["t"]) > 0.0)

func _show_dialogue(pages: Array, new_mode: String = "playing") -> void:
	dialog_pages = pages
	dialog_page = 0
	dialog_age = 0.0
	dialog_resume = new_mode
	mode = "dialogue"
	_play_sound("radio_chirp", -16.0)

func _notify(message: String, duration: float) -> void:
	notify = message
	notify_timer = duration

func _play_sound(which: String, volume: float = -12.0) -> void:
	if not music_enabled:
		return
	var player := AudioStreamPlayer.new()
	player.stream = load("res://audio/%s.wav" % which)
	player.volume_db = volume
	add_child(player)
	player.finished.connect(player.queue_free)
	player.play()

func _process(delta: float) -> void:
	anim_clock += delta if mode != "playing" else 0.0
	if mode == "dialogue": dialog_age += delta
	_update_music(delta)
	queue_redraw()

func _draw() -> void:
	_draw_backdrop()
	if mode == "title":
		_draw_title()
		return
	var offset := Vector2(randf_range(-recoil_shake, recoil_shake), randf_range(-recoil_shake, recoil_shake))
	draw_set_transform(offset)
	_draw_ambience()
	_draw_world_details()
	_draw_automaton_markings()
	_draw_atmospheric_lighting()
	_draw_platforms()
	_draw_objects()
	_draw_enemies()
	_draw_projectiles()
	_draw_player()
	if pulse_fx > 0.0:
		var center := Vector2(player_x-camera_x,player_y-25.0)
		var radius: float = 160.0*(1.0-pulse_fx/0.48)+8.0
		draw_arc(center,radius,0.0,TAU,48,Color(0.45,0.98,0.92,pulse_fx/0.48*0.8),3.0)
	_draw_particles()
	_draw_foreground()
	draw_set_transform(Vector2.ZERO)
	_draw_overlay_haze()
	_draw_hud()
	if mode == "dialogue":
		_draw_dialogue()
	elif mode == "pause":
		_draw_pause()
	elif mode == "victory":
		_draw_victory()
	elif map_open:
		_draw_map()
	if mouse_aim_time > 0.0 and mode == "playing":
		var mp: Vector2 = get_local_mouse_position()
		if mp.x >= 0.0 and mp.y >= 0.0 and mp.x < VIEW_W and mp.y < VIEW_H:
			for sign_dir in [-1.0, 1.0]:
				draw_line(mp + Vector2(sign_dir * 3.0, 0), mp + Vector2(sign_dir * 8.0, 0), Color("#f8d14e"))
				draw_line(mp + Vector2(0, sign_dir * 3.0), mp + Vector2(0, sign_dir * 8.0), Color("#f8d14e"))
	if screen_flash > 0.0:
		draw_rect(Rect2(0, 0, VIEW_W, VIEW_H), Color(1.0, 0.65, 0.35, screen_flash * 0.24))

func _draw_backdrop() -> void:
	# v1.0.1 backgrounds are integrated scenic plates, not a static gameplay screenshot.
	# Entities, camera, collisions, UI and effects are live and rendered separately.
	if sector != "main":
		var concept: Texture2D = concept_rooms.get(sector)
		if concept != null:
			draw_texture_rect(concept, Rect2(0, 0, VIEW_W, VIEW_H), false)
			return
	if concept_main != null:
		var source_x: float = clampf(camera_x * 0.54, 0.0, maxf(0.0, float(concept_main.get_width()) - VIEW_W))
		draw_texture_rect_region(concept_main, Rect2(0, 0, VIEW_W, VIEW_H), Rect2(source_x, 0.0, VIEW_W, VIEW_H))
		return
	# Fallback for missing textures.
	if sky != null:
		_draw_repeat_layer(sky, 0.045)
		_draw_repeat_layer(far, 0.16)
		_draw_repeat_layer(mid, 0.26)
		_draw_repeat_layer(near, 0.37)

func _draw_repeat_layer(tex: Texture2D, factor: float) -> void:
	var width: float = float(tex.get_width())
	var shift: float = fposmod(camera_x * factor, width)
	draw_texture(tex, Vector2(-floorf(shift), 0))
	if shift + VIEW_W > width:
		draw_texture(tex, Vector2(width - floorf(shift), 0))

func _draw_ambience() -> void:
	for i in range(30):
		var x: float = fposmod(i * 113.0 + 41.0 - camera_x * 0.25 + anim_clock * float(i % 3 + 1) * 2.0, 528.0) - 24.0
		var y: float = 64.0 + fposmod(i * 67.0 + anim_clock * float(5 + i % 5), 172.0)
		draw_rect(Rect2(x, y, 1.0, 1.0 if i % 4 else 2.0), Color(0.7, 0.53, 0.44, 0.4))
	for data in [[589.0,196.0,52.0], [1090.0,209.0,65.0], [1580.0,199.0,55.0], [2150.0,216.0,45.0], [2878.0,220.0,65.0]]:
		var x: float = float(data[0]) - camera_x
		if x > -100.0 and x < 550.0:
			draw_rect(Rect2(x, float(data[1]), float(data[2]), 2.0), Color("#af4a21"))

func _draw_atmospheric_lighting() -> void:
	var underground: bool = sector != "main"
	var cold: bool = sector in ["archive","blacksite"]
	var lamps: Array = [70,220,364,468,620,780,947,1085] if underground else [180,425,714,997,1362,1580,1702,2031,2260,2644,2893]
	for i in range(lamps.size()):
		var x: float = float(lamps[i]) - camera_x
		if x < -100.0 or x > VIEW_W + 100.0: continue
		var pulse: float = 0.72 + 0.28 * sin(anim_clock * (1.7 if i % 3 == 0 else 2.5) + i * 1.19)
		var light_color: Color = Color("#63dcd4") if cold else (Color("#f5a35c") if underground else Color("#df7148"))
		var by: float = 59.0 if underground else 73.0
		var beam: Color = light_color
		beam.a = (0.055 if underground else 0.032) * pulse
		draw_colored_polygon(PackedVector2Array([Vector2(x-3.0,by),Vector2(x+5.0,by),Vector2(x+79.0,226.0),Vector2(x-84.0,226.0)]),beam)
		var fixture: Color = light_color
		fixture.a = 0.55 * pulse
		draw_rect(Rect2(x-6.0,by,12,3),fixture)
		fixture.a = 0.83 * pulse
		draw_rect(Rect2(x-2.0,by+1.0,5,2),fixture)
	if underground:
		for i in range(6):
			var x: float = fposmod(i * 139.0 + anim_clock * (4.0 if i % 2 else -3.0) - camera_x * 0.11,590.0) - 55.0
			draw_rect(Rect2(x,217.0 + (i % 3) * 3.0,115,5),Color(0.45,0.79,0.8,0.09) if cold else Color(0.49,0.34,0.42,0.09))
	else:
		for i in range(5):
			var x: float = fposmod(i * 197.0 + anim_clock * (8.0 if i % 2 else -6.0) - camera_x * 0.12,660.0) - 80.0
			draw_rect(Rect2(x,186.0 + (i % 3) * 11.0,145.0,4.0),Color(0.61,0.47,0.56,0.07))

func _draw_foreground() -> void:
	if sector != "main":
		for i in range(5):
			var x: float = float(i * 260 + 90) - camera_x
			draw_rect(Rect2(x,226,39,7),Color("#191321"))
		return
	_draw_repeat_layer(foreground_machines, 0.79)
	for wx in [273.0,768.0,1128.0,1745.0,2130.0,2668.0,3005.0]:
		var x: float = wx - camera_x
		if x > -40.0 and x < 520.0:
			draw_rect(Rect2(x,229.0,42.0,11.0),Color("#100d1b"))
			draw_rect(Rect2(x + 3.0,229.0,36.0,2.0),Color("#4b3854"))
			for j in range(4):
				draw_rect(Rect2(x + 4.0 + j * 9.0,233.0,5.0,1.0),Color("#b27c2e"))

func _draw_title() -> void:
	draw_rect(Rect2(0, 0, VIEW_W, VIEW_H), Color(0.04, 0.025, 0.075, 0.38))
	draw_rect(Rect2(264, 15, 193, 240), Color("#100c1b"))
	draw_texture_rect(ref_art, Rect2(266, 30, 190, 190), false)
	draw_rect(Rect2(264, 15, 193, 2), Color("#f8c314"))
	_txt("SUPER EARTH // SIGNAL LOST", 22, 32, 10, Color("#e4b51b"))
	_txt("HELLDIVERS", 22, 76, 27, Color("#ffdc35"))
	_txt("BEHIND", 22, 100, 18, Color("#f8eac5"))
	_txt("ENEMY LINES", 22, 123, 18, Color("#f8eac5"))
	draw_rect(Rect2(23, 138, 213, 2), Color("#e8b41f"))
	_txt("A 2D METROIDVANIA PROTOTYPE", 23, 158, 10, Color("#c2accb"))
	_txt("OPERATION 01 // DEAD SIGNAL", 23, 176, 10, Color("#8a798f"))
	if int(anim_clock * 2.4) % 2 == 0:
		_txt("[ ENTER ] NEW MISSION", 23, 213, 12, Color("#ffdc35"))
	else:
		_txt("[ ENTER ] NEW MISSION", 23, 213, 12, Color("#b69634"))
	if _has_save(): _txt("[ C ] RESUME CHECKPOINT",23,232,10,Color("#91d9c9"))
	_txt("BUILD 0.6.0  |  CINEMATIC COMBAT", 23, 253, 9, Color("#71677e"))

func _draw_world_details() -> void:
	if sector in ["blacksite","reactor"]:
		for xx in range(140,int(_sector_width()),208):
			var sx: float = float(xx)-camera_x
			draw_rect(Rect2(sx-6,44,21,183),Color("#181521"))
			draw_rect(Rect2(sx,49,5,176),Color("#53485c"))
			draw_rect(Rect2(sx-17,81,43,5),Color("#847186"))
			draw_rect(Rect2(sx+8,87,4,5),Color("#f7c349") if sin(anim_clock*2+xx)>0 else Color("#6a333f"))
		_txt("SITE ZERO // CLASSIFIED" if sector == "blacksite" else "CORE // DANGER",19,104,10,Color("#6ce4d8") if sector == "blacksite" else Color("#ffb858"))
		return
	if sector != "main":
		for x in range(155,int(_sector_width()),265):
			var sx: float = float(x) - camera_x
			draw_rect(Rect2(sx,57,6,166),Color("#27505a") if sector == "archive" else Color("#4b374d"))
			draw_rect(Rect2(sx - 18,70,43,5),Color("#68536c"))
		_txt("SUBLEVEL 06 // MAINTENANCE" if sector == "sublevel" else "ARCHIVE // CLASSIFIED",19,104,10,Color("#70d2d4") if sector == "archive" else Color("#ffba50"))
		return
	# Character of each area comes from large readable silhouettes,
	# red signal lights, angled struts and distant industrial structures.
	for x in [168.0, 420.0, 706.0, 1006.0, 1337.0, 1575.0, 1842.0, 2044.0, 2380.0, 2677.0, 2950.0]:
		var sx: float = floorf(x - camera_x)
		if sx < -45.0 or sx > VIEW_W + 45.0:
			continue
		draw_rect(Rect2(sx - 7, 62, 13, 166), Color("#1b1929"))
		draw_rect(Rect2(sx - 4, 62, 3, 166), Color("#382e44"))
		draw_line(Vector2(sx - 23, 100), Vector2(sx + 18, 155), Color("#2f263c"), 4.0)
		draw_rect(Rect2(sx - 10, 73, 19, 5), Color("#3d303d"))
		var pulse: float = 0.55 + 0.3 * sin(anim_clock * 2.0 + x * 0.1)
		draw_rect(Rect2(sx - 2, 76, 4, 4), Color(1.0, 0.31, 0.19, pulse))
	# Damaged transmission arrays and smoke stacks.
	for x in [587.0, 1060.0, 1722.0, 2260.0, 2821.0]:
		var sx: float = x - camera_x
		if sx < -80 or sx > VIEW_W + 80:
			continue
		draw_rect(Rect2(sx, 94, 17, 133), Color("#26212f"))
		draw_rect(Rect2(sx + 3, 88, 11, 8), Color("#4d3a48"))
		for ring in range(3):
			draw_line(Vector2(sx + 8, 90 - ring * 6 - sin(anim_clock + ring) * 2), Vector2(sx + 14 + ring * 9, 71 - ring * 13), Color(0.34, 0.28, 0.39, 0.20), 3.0)
	# Region banners remain in world space for orientation.
	for marker in [{"x": 175.0, "name": "COLONY PERIMETER"}, {"x": 890.0, "name": "SIEGE WORKS"},
		{"x": 1450.0, "name": "DELTA-9 UPLINK"}, {"x": 2182.0, "name": "RESTRICTED SECTOR"},
		{"x": 2677.0, "name": "WARDEN CHAMBER"}]:
		var m_x: float = float(marker["x"]) - camera_x
		if m_x > -170.0 and m_x < VIEW_W + 50.0:
			draw_rect(Rect2(m_x - 2.0, 86, 130, 15), Color(0.08, 0.07, 0.11, 0.75))
			_txt(str(marker["name"]), m_x + 3.0, 97, 9, Color("#8b788e"))
	# Dark pit openings and hazard warning brackets.
	for span in [[694.0, 762.0], [1297.0, 1343.0], [1848.0, 1907.0], [2502.0, 2565.0]]:
		var left: float = float(span[0]) - camera_x
		var right: float = float(span[1]) - camera_x
		if left < VIEW_W and right > 0:
			draw_rect(Rect2(left, 231, right - left, 39), Color("#090812"))
			for j in range(3):
				draw_line(Vector2(left + 8 + j * 11, 252), Vector2(left + 14 + j * 11, 262), Color("#7f3331"), 1.0)

# The player-supplied four-point SVG is rasterized once to a transparent
# sprite, then reused for every in-world faction banner and comm badge.
func _draw_automaton_markings() -> void:
	if not sprites.has("automaton_emblem"): return
	var layouts: Dictionary = {
		"main": [[208.0,128.0,28.0],[910.0,113.0,30.0],[1530.0,121.0,32.0],[2278.0,110.0,29.0],[2722.0,124.0,36.0]],
		"sublevel": [[336.0,109.0,30.0],[806.0,120.0,30.0]],
		"archive": [[340.0,123.0,25.0]],
		"blacksite": [[274.0,111.0,32.0],[721.0,102.0,34.0],[1187.0,112.0,34.0]],
		"reactor": [[305.0,114.0,32.0],[803.0,119.0,34.0]]
	}
	for item in layouts.get(sector, []):
		var x: float = floorf(float(item[0])-camera_x)
		var y: float = float(item[1])
		var size: float = float(item[2])
		if x < -55.0 or x > VIEW_W+55.0: continue
		var w: float = size+16.0
		var h: float = size+20.0
		draw_rect(Rect2(x-w/2.0-2.0,y-5.0,w+4.0,h+8.0),Color("#160e1b"))
		draw_rect(Rect2(x-w/2.0,y-3.0,w,h),Color("#53222f"))
		draw_rect(Rect2(x-w/2.0+2.0,y-1.0,w-4.0,3.0),Color("#8e303c"))
		draw_colored_polygon(PackedVector2Array([Vector2(x-w/2.0,y+h-3.0),Vector2(x,y+h+8.0),Vector2(x+w/2.0,y+h-3.0)]),Color("#30101f"))
		draw_rect(Rect2(x-w/2.0+4.0,y-2.0,w-8.0,1.0),Color("#c55b5f"))
		draw_texture_rect(sprites["automaton_emblem"],Rect2(x-size/2.0,y+3.0,size,size),false)

func _draw_platforms() -> void:
	for p in world_solids:
		var x: float = floorf(p.position.x - camera_x)
		if x > VIEW_W or x + p.size.x < 0.0:
			continue
		draw_texture_rect(tile, Rect2(x, p.position.y, p.size.x, p.size.y), true)
		draw_rect(Rect2(x, p.position.y, p.size.x, 2), Color("#a18ca1"))
		draw_rect(Rect2(x, p.position.y + 3, p.size.x, 2), Color("#514353"))
		if p.size.y <= 15:
			for t in range(int(p.size.x / 20.0)):
				draw_rect(Rect2(x + 6 + t * 20, p.position.y + 8, 7, 2), Color("#5c495d"))
	if sector == "main" and not comms_restored:
		var gx: float = dynamic_gate.position.x - camera_x
		if gx > -30 and gx < VIEW_W + 30:
			draw_rect(Rect2(gx, 25, 24, 203), Color("#392c3d"))
			for yy in range(28, 226, 22):
				draw_rect(Rect2(gx + 3, yy, 17, 3), Color("#72626b"))
				draw_rect(Rect2(gx + 9, yy + 5, 7, 11), Color("#ee432e"))
			_txt("LOCKED", gx - 13, 21, 8, Color("#ff715b"))

func _draw_objects() -> void:
	for item in [{"room":"main","x":2017.0,"y":168.0},{"room":"blacksite","x":1200.0,"y":155.0}]:
		if sector != str(item["room"]): continue
		var ex: float = float(item["x"])-camera_x
		if ex > -120.0 and ex < VIEW_W+50.0:
			draw_texture(sprites["evidence_terminal"],Vector2(ex-35.0,float(item["y"])-42.0))
	for i in range(LOGS.size()):
		if recovered_logs.has(i):
			continue
		var log: Dictionary = LOGS[i]
		if str(log["room"]) != sector: continue
		var sx: float = float(log["x"]) - camera_x
		var sy: float = float(log["y"]) + sin(anim_clock * 2.0 + i) * 1.5
		if sx > -24.0 and sx < VIEW_W + 24.0:
			draw_rect(Rect2(sx - 9.0, sy - 10.0,19.0,18.0),Color("#49354a"))
			draw_rect(Rect2(sx - 7.0,sy - 8.0,15.0,14.0),Color("#201a28"))
			draw_texture(sprites["icon_intel"],Vector2(sx - 8.0,sy - 9.0))
			draw_rect(Rect2(sx - 8.0,sy + 8.0,16.0,2.0),Color("#e2b43d"))
			if _near(float(log["x"]),float(log["y"]),56.0):
				_text_panel("[ E ] READ BLACK BOX",sx - 58.0,sy - 29.0)
	if sector in ["blacksite","reactor"]:
		var door_x: float = 67.0-camera_x
		draw_rect(Rect2(door_x-18,178,36,50),Color("#2f2c3d"))
		draw_rect(Rect2(door_x-11,186,22,42),Color("#111726"))
		if _near(67.0,205.0,64.0): _text_panel("[ E ] SURFACE LIFT" if sector == "blacksite" else "[ E ] RETURN TO BLACKSITE",door_x-61,155)
		var stations: Array = []
		if sector == "blacksite":
			stations = [{"x":451.0,"y":151.0,"done":junction_a,"name":"POWER JUNCTION ALPHA","icon":"reactor"},
				{"x":850.0,"y":154.0,"done":emp_recovered,"name":"EMP DISRUPTOR","icon":"emp"},
				{"x":1339.0,"y":156.0,"done":junction_b,"name":"POWER JUNCTION BETA","icon":"reactor"}]
		else: stations = [{"x":506.0,"y":144.0,"done":reactor_disabled,"name":"SHUT DOWN COOLANT","icon":"reactor"}]
		for o in stations:
			var sx: float = float(o["x"])-camera_x
			var sy: float = float(o["y"])+sin(anim_clock*2.3)*2.0
			if sx < -42.0 or sx > VIEW_W+42.0: continue
			draw_rect(Rect2(sx-17,sy-17,34,34),Color("#26363b") if bool(o["done"]) else Color("#423448"))
			draw_rect(Rect2(sx-14,sy-14,28,28),Color("#1b1b2b"))
			draw_texture(sprites["icon_"+str(o["icon"])],Vector2(sx-8,sy-8))
			draw_rect(Rect2(sx-12,sy+13,24,2),Color("#6dd0c1") if bool(o["done"]) else Color("#ffc33c"))
			if _near(float(o["x"]),float(o["y"]),69.0): _text_panel("SYSTEM ONLINE" if bool(o["done"]) else "[ E ] "+str(o["name"]),sx-70,sy-41)
		if sector == "blacksite":
			for wx in [612.0,1110.0]:
				var sx: float = wx-camera_x
				if sx < -20.0 or sx > VIEW_W+20.0: continue
				draw_rect(Rect2(sx-7,64,14,9),Color("#705362"))
				draw_rect(Rect2(sx-7,211,14,11),Color("#745465"))
				if laser_off <= 0.0:
					draw_rect(Rect2(sx-2,73,4,140),Color(1,0.35,0.25,0.52+sin(anim_clock*13)*0.2))
				else: draw_rect(Rect2(sx-1,73,2,141),Color("#5d8883"))
			var hx: float = 1555.0-camera_x
			draw_rect(Rect2(hx-18,175,36,53),Color("#2c2638"))
			draw_rect(Rect2(hx-12,185,24,43),Color("#0d1b2a"))
			if _near(1555.0,202.0,65.0): _text_panel("[ E ] DESCEND TO REACTOR" if junction_a and junction_b else "POWER BOTH JUNCTIONS",hx-89,155)
		return
	if sector != "main":
		var door_x: float = 67.0 - camera_x
		draw_rect(Rect2(door_x - 17,177,34,51),Color("#292033"))
		draw_rect(Rect2(door_x - 11,184,22,38),Color("#67536b"))
		draw_rect(Rect2(door_x - 8,193,16,24),Color("#141826"))
		if _near(67.0,205.0,65.0): _text_panel("[ E ] RETURN TO UPLINK",door_x - 68,157)
		if sector == "sublevel" and not arc_cutter:
			var sx: float = 948.0 - camera_x
			draw_rect(Rect2(sx - 15,133,30,31),Color("#69485b"))
			draw_texture(sprites["icon_breach"],Vector2(sx - 8,142))
			if _near(948.0,156.0,64.0): _text_panel("[ E ] RECOVER ARC CUTTER",sx - 81,110)
		if sector == "archive" and not armor_recovered:
			var sx: float = 610.0 - camera_x
			draw_rect(Rect2(sx - 15,146,30,31),Color("#486a72"))
			draw_texture(sprites["icon_armor"],Vector2(sx - 8,154))
			if _near(610.0,172.0,65.0): _text_panel("[ E ] RECOVER ARMOR PLATE",sx - 83,123)
		return
	for portal in [{"x":1490.0,"y":154.0,"kind":"sublevel"},{"x":596.0,"y":141.0,"kind":"archive"},{"x":3025.0,"y":203.0,"kind":"blacksite"}]:
		var sx: float = float(portal["x"]) - camera_x
		var sy: float = float(portal["y"])
		if sx < -50.0 or sx > 530.0: continue
		draw_rect(Rect2(sx - 15,sy - 20,30,44),Color("#453447"))
		draw_rect(Rect2(sx - 11,sy - 16,22,36),Color("#171826"))
		draw_rect(Rect2(sx - 8,sy - 12,16,2),Color("#59bdbe") if portal["kind"] == "archive" else Color("#e6b455"))
		if _near(float(portal["x"]),sy,65.0):
			var prompt: String = "[ E ] ENTER MAINTENANCE" if can_double_jump else "JUMP JETS REQUIRED"
			if portal["kind"] == "archive": prompt = "[ E ] ENTER HIDDEN ARCHIVE" if arc_cutter else "ARCHIVE SEALED // ARC CUTTER"
			if portal["kind"] == "blacksite": prompt = "[ E ] ENTER BLACKSITE ZERO" if boss_defeated else "BLACKSITE SEALED // WARDEN"
			_text_panel(prompt,sx - 78,sy - 39)
	for data in [{"x":1136.0,"y":141.0,"key":"jet","active":not can_double_jump},
		{"x":1708.0,"y":124.0,"key":"terminal","active":not comms_restored}]:
		if not bool(data["active"]):
			continue
		var sx: float = float(data["x"]) - camera_x
		if sx < -40 or sx > VIEW_W + 40:
			continue
		var sy: float = float(data["y"]) - 8.0 + sin(anim_clock * 3.1) * 2.0
		draw_rect(Rect2(sx - 16, sy - 8, 32, 29), Color("#28202f"))
		draw_rect(Rect2(sx - 12, sy - 4, 24, 21), Color("#63526b"))
		draw_rect(Rect2(sx - 9, sy - 1, 18, 16), Color("#2c2639"))
		draw_texture(sprites["icon_" + data["key"]], Vector2(sx - 8, sy - 1))
		draw_rect(Rect2(sx - 12, sy + 20, 24, 2), Color("#d9ac20"))
		if _near(float(data["x"]), float(data["y"]), 62.0):
			_text_panel("[ E ] " + ("RECOVER JUMP JETS" if data["key"] == "jet" else "RESTORE COMMS"), sx - 73, sy - 28)
	# One fixed environmental stim, drawn as a glowing pickup on a raised ledge.
	var med_x: float = 608.0 - camera_x
	if not stim_used and med_x > -20.0 and med_x < VIEW_W + 20.0:
		draw_texture(sprites["icon_health"], Vector2(med_x - 8.0, 143.0 + sin(anim_clock * 3.0) * 2.0))
	# Activating checkpoint terminals.
	for i in range(3):
		var cx: float = [90.0, 1390.0, 2220.0][i] - camera_x
		if cx < -15 or cx > VIEW_W + 15:
			continue
		draw_rect(Rect2(cx - 5, 204, 10, 24), Color("#4c4054"))
		draw_rect(Rect2(cx - 8, 202, 16, 5), Color("#85738b"))
		draw_rect(Rect2(cx - 3, 195, 6, 7), Color("#ffd036") if i <= checkpoint_index else Color("#6d4240"))

func _draw_enemies() -> void:
	for e in enemies:
		if int(e["hp"]) <= 0 or (e["kind"] == "warden" and not boss_awake) or (e["kind"] == "sentinel" and not sentinel_awake):
			continue
		var sx: float = float(e["x"]) - camera_x
		if sx < -115 or sx > VIEW_W + 115:
			continue
		var y: float = float(e["y"])
		if float(e.get("telegraph",0.0)) > 0.0:
			var heavy: bool = e["kind"] in ["warden","sentinel"]
			var origin := Vector2(sx+float(e["dir"])*(45.0 if heavy else (18.0 if e["kind"]=="drone" else 22.0)), y-(0.0 if e["kind"]=="drone" else (60.0 if heavy else 27.0)))
			var target := Vector2(float(e.get("aim_x",player_x))-camera_x,float(e.get("aim_y",player_y-24.0)))
			draw_line(origin,target,Color("#ff653d") if heavy else Color("#fbd16c"),2.0 if heavy else 1.0)
			draw_rect(Rect2(origin.x-6.0,origin.y-11.0,12,3),Color("#ff6352") if heavy else Color("#f4c45a"))
		if e["kind"] in ["warden","sentinel"] and float(e["hp"]) < float(e["max_hp"])*0.5:
			draw_rect(Rect2(sx-23.0,y-106.0,46,3),Color("#fc7731"))
			_txt("OVERDRIVE",sx-26.0,y-123.0,8,Color("#ffb05c"))
		if e["kind"] in ["warden","sentinel"]:
			draw_texture(sprites["sentinel" if e["kind"] == "sentinel" else "warden"], Vector2(floorf(sx - 56), floorf(y - 106)))
			_draw_health_bar(sx - 43.0, y - 117.0, 86.0, float(e["hp"]) / float(e["max_hp"]), Color("#e65d47"))
		elif e["kind"] == "drone":
			var df: int = posmod(int(anim_clock*12.0),4)
			draw_texture(sprites["drone_%d_%s" % [df,"r" if int(e["dir"])>0 else "l"]],Vector2(floorf(sx-26),floorf(y-24)))
		elif e["kind"] == "turret":
			draw_texture(sprites["turret_" + ("r" if int(e["dir"]) > 0 else "l")], Vector2(floorf(sx - 27), floorf(y - 42)))
		else:
			var frame: int = posmod(int(anim_clock * 7.0 + float(e["x"]) / 70.0),4)
			draw_texture(sprites["bot_%s_%d_%s" % [str(e.get("unit","trooper")),frame, "r" if int(e["dir"]) > 0 else "l"]], Vector2(floorf(sx - 26), floorf(y - 48)))
		if float(e.get("hit",0.0)) > 0.0:
			draw_rect(Rect2(sx-20.0,y-43.0,40.0,3.0),Color("#ffcf65"))
			draw_rect(Rect2(sx-18.0,y-35.0,36.0,2.0),Color("#f95740",0.35))
		if e["kind"] not in ["warden","sentinel"] and int(e["hp"]) < int(e["max_hp"]):
			_draw_health_bar(sx - 14.0, y - 52.0, 28.0, float(e["hp"]) / float(e["max_hp"]), Color("#e85b4f"))
		if float(e.get("stun",0.0)) > 0.0:
			draw_rect(Rect2(sx-12,y-64,25,4),Color("#7beee5"))

func _draw_health_bar(x: float, y: float, width: float, fraction: float, tint: Color) -> void:
	draw_rect(Rect2(x, y, width, 4), Color("#0d0b13"))
	draw_rect(Rect2(x + 1, y + 1, (width - 2) * clampf(fraction, 0.0, 1.0), 2), tint)

func _draw_player() -> void:
	if hurt_timer > 0.0 and int(hurt_timer * 12.0) % 2 == 0: return
	var animation: String = "idle"
	var frame: int = 0
	if hurt_timer > 0.56:
		animation = "hurt"
		frame = int(anim_clock * 12.0) % 3
	elif dash_timer > 0.0:
		animation = "dive"
		frame = int(anim_clock * 18.0) % 2
	elif landing_fx > 0.0:
		animation = "land"
		frame = clampi(int((0.24-landing_fx)*4.0/0.24),0,3)
	elif not grounded:
		animation = "jet" if can_double_jump and jump_count >= 2 else "jump"
		frame = int(anim_clock * 12.0) % 4 if animation == "jet" else 0
	elif absf(vx) > 9.0:
		animation = "run"
		frame = int(run_phase * 8.0) % 8
	elif reload_timer > 0.0:
		animation = "reload"
		frame = clampi(int((0.9 - reload_timer) * 3.0 / 0.9), 0, 2)
	elif fire_timer > 0.0:
		animation = "fire"
		frame = int(anim_clock * 25.0) % 3
	else:
		frame = int(anim_clock * 3.5) % 4
	var rifle_info: Dictionary = _rifle_geometry()
	facing = int(rifle_info["face"])
	var key: String = "%s_%d_%s" % [animation, frame, "r" if facing > 0 else "l"]
	var sprite_key: String = "body_" + key
	if not sprites.has(sprite_key): sprite_key = key
	var position := Vector2(floorf(player_x-camera_x-42.0),floorf(player_y-72.0))
	if dash_timer > 0.0:
		draw_texture(sprites[sprite_key],position-Vector2(facing*13.0,0.0),Color(1.0,1.0,1.0,0.12))
	draw_texture(sprites[sprite_key],position)
	if can_double_jump and not grounded and jump_count >= 2:
		var flick: int = int(anim_clock * 24.0) % 4
		draw_rect(Rect2(player_x-camera_x-14,player_y-6+flick,5,10+flick),Color("#ff9a18"))
		draw_rect(Rect2(player_x-camera_x+7,player_y-4+flick,4,10+flick),Color("#ffd82b"))
	var gun_name: String = "hero_gun_r" if facing > 0 else "hero_gun_l"
	if sprites.has(gun_name):
		var pivot: Vector2 = rifle_info["pivot"]
		draw_set_transform(Vector2(pivot.x-camera_x,pivot.y), float(rifle_info["rotation"]), Vector2.ONE)
		draw_texture(sprites[gun_name],Vector2(-float(rifle_info["art_pivot_x"]),-28.0))
		draw_set_transform(Vector2.ZERO)
	if fire_timer > 0.0 and muzzle_effects.size() == 4:
		var shot_frame: int = clampi(int((0.165-fire_timer)/0.041),0,3)
		var muzzle_position: Vector2 = rifle_info["muzzle"]
		var flash: Texture2D = muzzle_effects[shot_frame]
		draw_set_transform(Vector2(muzzle_position.x-camera_x,muzzle_position.y), float(rifle_info["theta"]), Vector2.ONE)
		draw_texture(flash,Vector2(0.0,-flash.get_height()*0.5))
		draw_set_transform(Vector2.ZERO)

func _draw_projectiles() -> void:
	for b in bullets:
		var bx: float = float(b["x"]) - camera_x
		if bx < -15 or bx > VIEW_W + 15:
			continue
		if int(b["team"]) == 0:
			var vector: Vector2 = Vector2(float(b["vx"]),float(b.get("vy",0.0))).normalized()
			draw_line(Vector2(bx,float(b["y"])),Vector2(bx,float(b["y"])) - vector * 8.0,Color("#ffed84"),2.0)
			draw_rect(Rect2(bx,float(b["y"]),2.0,2.0),Color("#fff4bb"))
		elif bool(b.get("rocket",false)):
			draw_rect(Rect2(bx-9,float(b["y"])-2.0,7,4),Color(0.75,0.28,0.13,0.47))
			draw_rect(Rect2(bx-4,float(b["y"])-3.0,9,7),Color("#f05d3b"))
			draw_rect(Rect2(bx,float(b["y"])-1.0,3,3),Color("#ffd09d"))
		else:
			draw_rect(Rect2(bx - 3, float(b["y"]) - 2, 7, 5), Color("#ee4a3a"))
			draw_rect(Rect2(bx - 1, float(b["y"]) - 1, 3, 2), Color("#ffd09d"))
	if orbital_warning >= 0.0:
		var ox: float = orbital_target - camera_x
		var beam: float = absf(sin(anim_clock * 23.0)) * 0.4 + 0.2
		draw_rect(Rect2(ox - 2, 9, 4, 222), Color(1, 0.43, 0.19, beam))
		draw_line(Vector2(ox - 18, 227), Vector2(ox + 18, 227), Color("#ffc21c"), 2.0)
		_txt("INBOUND", ox - 27, 80, 9, Color("#ff6d4f"))

func _draw_particles() -> void:
	for p in particles:
		var sx: float = float(p["x"]) - camera_x
		if sx < 0 or sx > VIEW_W:
			continue
		var c: Color = p["c"]
		c.a = clampf(float(p["t"]) * 2.0, 0.0, 1.0)
		var s: float = float(p["size"])
		draw_rect(Rect2(sx, float(p["y"]), s, s), c)

func _draw_overlay_haze() -> void:
	draw_rect(Rect2(0, 229, VIEW_W, 41), Color(0.16, 0.10, 0.18, 0.16))
	# Horizontal scanline overlays are intentionally sparse for legibility.
	for y in range(43, 260, 9):
		draw_line(Vector2(0, y), Vector2(VIEW_W, y), Color(0.0, 0.0, 0.0, 0.065), 1.0)

func _draw_hud() -> void:
	# Compact live HUD: health, ammo, orbiter status, dynamic mini-map and objective.
	draw_rect(Rect2(3,3,248,39),Color(0.035,0.027,0.07,0.91))
	draw_rect(Rect2(3,3,248,1),Color("#efc038"))
	draw_rect(Rect2(3,3,40,39),Color("#111025"))
	if sprites.has("radio_helldiver"):
		if sprites.has("helldiver_emblem"):
		draw_texture_rect(sprites["helldiver_emblem"],Rect2(6,6,34,34),false)
	elif sprites.has("radio_helldiver"):
		draw_texture_rect(sprites["radio_helldiver"],Rect2(6,6,34,34),false)
	for i in range(max_health):
		var hx: float = 48.0+i*13.0
		var tint: Color = Color("#fbd536") if i<health else Color("#30293e")
		draw_rect(Rect2(hx,7,10,8),tint)
		draw_rect(Rect2(hx+2,5,6,2),tint)
		draw_rect(Rect2(hx+2,15,6,2),tint)
	_txt("AR-23  %02d / %02d" % [ammo,MAG_SIZE],49,30,10,Color("#f3e6da"))
	_txt("RELOAD" if reload_timer>0 else "ASSAULT",158,15,8,Color("#ef895e") if reload_timer>0 else Color("#dfc19e"))
	draw_rect(Rect2(157,22,82,3),Color("#31263d"))
	draw_rect(Rect2(157,22,82*(1.0-reload_timer/0.9 if reload_timer>0 else float(ammo)/MAG_SIZE),3),Color("#edba47"))
	draw_rect(Rect2(257,3,104,24),Color(0.04,0.03,0.09,0.86))
	draw_rect(Rect2(257,3,104,1),Color("#e4b530"))
	var orb: String = "ORBITAL OFFLINE"
	if comms_restored: orb = "ORBITAL %dS" % ceili(strat_cooldown) if strat_cooldown>0 else "ORBITAL READY"
	_txt(orb,263,14,9,Color("#f8c739") if comms_restored else Color("#d7a96a"))
	var emp_text: String = "EMP LOCKED"
	if emp_recovered: emp_text = "EMP %dS" % ceili(pulse_cooldown) if pulse_cooldown>0 else "EMP READY [G]"
	_txt(emp_text,263,23,8,Color("#87e6d8") if emp_recovered else Color("#7d809c"))
	draw_rect(Rect2(365,2,113,56),Color("#edc035"))
	draw_rect(Rect2(368,5,107,50),Color("#110e23"))
	_txt("SECTOR MAP",374,11,7,Color("#d7bf74"))
	for j in range(5):
		var xpos: float = 371+j*19
		draw_rect(Rect2(xpos,31,18,8),Color("#736486") if sector=="main" and player_x/WORLD_END*5.0>=j else Color("#3b314d"))
		draw_rect(Rect2(xpos,31,18,1),Color("#b6a0bd"))
	draw_rect(Rect2(401,45,33,5),Color("#4d8991") if visited_sectors.has("sublevel") else Color("#332c46"))
	draw_rect(Rect2(380,45,17,5),Color("#4b8991") if visited_sectors.has("archive") else Color("#332c46"))
	if sector=="main":
		draw_rect(Rect2(371+clampf(player_x/WORLD_END*95.0,0.0,95.0),28,3,12),Color("#ffcb2d"))
	else:
		draw_rect(Rect2(429,43,4,9),Color("#ffcf41"))
	var mission: String = "RESTORE COMMUNICATIONS"
	if comms_restored: mission = "REACH WARDEN CHAMBER"
	if boss_awake: mission = "DESTROY THE WARDEN"
	if boss_defeated: mission = "ENTER BLACKSITE ZERO"
	if sector=="sublevel": mission = "RECOVER ARC CUTTER"
	if sector=="archive": mission = "RETRIEVE CLASSIFIED EVIDENCE"
	if sector=="blacksite": mission = "ENTER THE REACTOR" if junction_a and junction_b else "RESTORE TWO JUNCTIONS"
	if sector=="reactor": mission = "MISSION COMPLETE" if sentinel_defeated else ("DESTROY SENTINEL" if reactor_disabled else "DISABLE COOLANT REGULATOR")
	draw_rect(Rect2(4,46,minf(255.0,mission.length()*5.9+24.0),25),Color(0.035,0.027,0.07,0.81))
	draw_rect(Rect2(4,46,3,25),Color("#ffc62d"))
	_txt("◆ "+mission,11,57,9,Color("#fff0ca"))
	_txt("OPERATION DEAD SIGNAL" if sector=="main" else "CLASSIFIED // SUBSURFACE",11,67,7,Color("#c1adca"))
	var region: String = "COLONY PERIMETER"
	if player_x>765.0: region="SIEGE WORKS"
	if player_x>1343.0: region="DELTA-9 UPLINK"
	if player_x>1907.0: region="SECURITY PERIMETER"
	if player_x>2565.0: region="WARDEN CHAMBER"
	if sector=="sublevel": region="MAINTENANCE WORKS"
	if sector=="archive": region="HIDDEN ARCHIVE"
	if sector=="blacksite": region="BLACKSITE ZERO"
	if sector=="reactor": region="REACTOR CHAMBER"
	draw_rect(Rect2(4,256,171,12),Color(0.04,0.025,0.095,0.75))
	_txt(region,9,265,8,Color("#e8d0a3"))
	if tutorial_timer>0 and mode=="playing": _text_panel("WASD MOVE  MOUSE FIRE  SPACE JUMP  E USE",35,76)
	if notify_timer>0 and mode=="playing": _text_panel(notify,65,93)
	if strat_input: _draw_stratagem_ui()

func _draw_stratagem_ui() -> void:
	draw_rect(Rect2(133, 76, 215, 94), Color(0.05, 0.04, 0.09, 0.97))
	draw_rect(Rect2(133, 76, 215, 2), Color("#ffcc19"))
	_txt("ORBITAL PRECISION STRIKE", 150, 98, 11, Color("#ffdd54"))
	for i in range(STRAT_CODE.size()):
		var symbol: String = ["^", ">", "v", "^"][i]
		var color: Color = Color("#ffd83b") if i < strat_progress else Color("#75677d")
		draw_rect(Rect2(160 + i * 43, 112, 33, 29), Color("#32293b"))
		_txt(symbol, 172 + i * 43, 132, 17, color)
	_txt("Q CANCEL  //  ENTER CODE", 151, 157, 9, Color("#b9a3c3"))

func _dialogue_portrait(speaker: String) -> String:
	var who: String = speaker.to_upper()
	if "AUTOMATON" in who or "WARDEN" in who or "SENTINEL" in who: return "radio_automaton"
	if "UNKNOWN" in who or "SURVIVOR" in who or "BLACK BOX" in who or "TRACE" in who: return "radio_survivor"
	if "HELLDIVER" in who or "FIELD EQUIPMENT" in who: return "radio_helldiver"
	return "radio_command"

func _draw_dialogue() -> void:
	if dialog_pages.is_empty(): return
	draw_rect(Rect2(0,0,VIEW_W,39),Color("#080610"))
	_txt("PRIORITY SIGNAL // ENCRYPTED",19,31,9,Color("#a997b9"))
	draw_rect(Rect2(0,16,VIEW_W,2),Color("#c19a2f"))
	draw_rect(Rect2(0,255,VIEW_W,15),Color("#070510"))
	draw_rect(Rect2(12,151,456,104),Color("#0b0b19"))
	draw_rect(Rect2(12,151,456,2),Color("#deaf30"))
	draw_rect(Rect2(20,169,72,77),Color("#27263a"))
	var page: Dictionary = dialog_pages[dialog_page]
	var portrait: String = _dialogue_portrait(str(page["speaker"]))
	draw_texture_rect(sprites[portrait],Rect2(24,174,64,64),false)
	if portrait == "radio_automaton":
		draw_rect(Rect2(67,217,23,23),Color("#190d1b"))
		draw_texture_rect(sprites["automaton_emblem"],Rect2(69,219,19,19),false)
	elif radio_portrait(dialog_pages[dialog_index][0]) == "radio_helldiver" and sprites.has("helldiver_emblem"):
		draw_rect(Rect2(67,217,23,23),Color(0.16,0.11,0.03))
		draw_texture_rect(sprites["helldiver_emblem"],Rect2(69,219,19,19),false)
	var cyan: bool = portrait == "radio_survivor"
	var accent: Color = Color("#76e2dc") if cyan else Color("#ffcf48")
	draw_rect(Rect2(100,169,3,68),accent)
	_txt("ENCRYPTED FIELD COMMS",111,167,9,Color("#8b819b"))
	_txt(str(page["speaker"]),112,186,11,accent)
	var one: String = str(page["a"])
	var two: String = str(page["b"])
	var reveal: int = int(dialog_age*55.0)
	_txt(one.substr(0,mini(reveal,one.length())),112,207,9,Color("#efdfca"))
	_txt(two.substr(0,clampi(reveal-one.length(),0,two.length())),112,224,9,Color("#efdfca"))
	for i in range(26):
		var height: int = 2+int(absf(sin(anim_clock*6.0+float(i)*1.8))*float((i*7)%7+2))
		draw_rect(Rect2(114+i*5,242-height,2,height),Color("#78d6d5") if cyan else Color("#d9a13d"))
	_txt("[ ENTER ] CONTINUE  %d/%d" % [dialog_page+1,dialog_pages.size()],318,246,9,Color("#c4b2c9"))

func _draw_pause() -> void:
	draw_rect(Rect2(0, 0, VIEW_W, VIEW_H), Color(0.04, 0.03, 0.08, 0.75))
	_draw_center("MISSION PAUSED", 108, 23, Color("#ffcd30"))
	_draw_center("ESC / P TO RESUME", 137, 11, Color("#f2e4d3"))
	_draw_center("A/D  |  SPACE  |  MOUSE / F  |  E  |  Q  |  M", 158, 9, Color("#b3a8bc"))

func _draw_map() -> void:
	draw_rect(Rect2(23,54,434,163),Color(0.045,0.037,0.08,0.97))
	draw_rect(Rect2(23,54,434,2),Color("#e7b329"))
	_txt("SECTOR TOPOLOGY // DELTA-9",37,72,12,Color("#f5d162"))
	var starts: Array = [0.0,765.0,1343.0,1907.0,2565.0]
	var ends: Array = [694.0,1297.0,1848.0,2502.0,3100.0]
	var labels: Array = ["DROP","SIEGE","RELAY","GATE","WARDEN"]
	for i in range(starts.size()):
		var x: float = 39.0 + float(starts[i]) / WORLD_END * 380.0
		var width: float = (float(ends[i]) - float(starts[i])) / WORLD_END * 380.0
		draw_rect(Rect2(x,94,width,25),Color("#4d3c4c") if sector == "main" and player_x >= float(starts[i]) else Color("#272332"))
		draw_rect(Rect2(x,92,width,2),Color("#a79078"))
		_txt(str(labels[i]),x + 3,111,8,Color("#e0cda8"))
	if sector == "main": draw_rect(Rect2(39 + player_x / WORLD_END * 380.0 - 2,88,4,35),Color("#ffcb19"))
	if not comms_restored: draw_rect(Rect2(39 + 2420.0 / WORLD_END * 380.0,90,3,31),Color("#d94f45"))
	draw_rect(Rect2(185,119,2,14),Color("#b7975c"))
	draw_rect(Rect2(125,134,143,26),Color("#43566a") if visited_sectors.has("sublevel") else Color("#28313c"))
	draw_rect(Rect2(109,118,2,43),Color("#8cd5d2") if arc_cutter else Color("#b7975c"))
	draw_rect(Rect2(73,166,104,24),Color("#37636b") if visited_sectors.has("archive") else Color("#27333c"))
	if sector == "sublevel": draw_rect(Rect2(126,133,4,28),Color("#fbc927"))
	if sector == "archive": draw_rect(Rect2(75,165,4,26),Color("#fbc927"))
	_txt("MAINTENANCE",136,152,9,Color("#7de5cd") if arc_cutter else Color("#b1b0c1"))
	_txt("ARCHIVE",91,182,9,Color("#8bedda") if armor_recovered else Color("#b3a6c1"))
	_txt("JETS %s  //  CUTTER %s  //  ARMOR %s" % ["ONLINE" if can_double_jump else "OFFLINE","RECOVERED" if arc_cutter else "MISSING","REINFORCED" if armor_recovered else "STANDARD"],36,203,9,Color("#e9d19a"))
	draw_rect(Rect2(297,144,126,19),Color("#28505b") if visited_sectors.has("blacksite") else Color("#272f38"))
	_txt("BLACKSITE ZERO",302,157,9,Color("#80e6dd") if emp_recovered else Color("#a4a2ba"))
	draw_rect(Rect2(323,170,100,18),Color("#654252") if visited_sectors.has("reactor") else Color("#322734"))
	_txt("REACTOR CORE",328,182,9,Color("#ffcf72") if reactor_disabled else Color("#aca1af"))
	if sector == "blacksite": draw_rect(Rect2(297,144,4,19),Color("#ffd641"))
	if sector == "reactor": draw_rect(Rect2(323,170,4,18),Color("#ffd641"))
	_txt("YELLOW: POSITION  |  M: CLOSE",278,213,8,Color("#ad9db9"))

func _draw_victory() -> void:
	draw_rect(Rect2(0, 0, VIEW_W, VIEW_H), Color(0.04, 0.03, 0.08, 0.87))
	draw_rect(Rect2(36, 43, 407, 2), Color("#e9b626"))
	_draw_center("OPERATION COMPLETE", 87, 27, Color("#ffdb4c"))
	_draw_center("DEAD SIGNAL // ACT II", 111, 13, Color("#f0e4c7"))
	_draw_center("REACTOR SENTINEL ELIMINATED", 134, 11, Color("#b7aabe"))
	_draw_center("HOSTILES   %d   |   REDEPLOYS   %d" % [enemies_destroyed, total_deaths], 155, 11, Color("#dccb88"))
	_draw_center("NEXT // THE SURVIVORS BELOW", 185, 10, Color("#a69ab0"))
	_draw_center("[ ENTER ] REDEPLOY", 218, 13, Color("#fbc82e"))

func _text_panel(content: String, x: float, y: float) -> void:
	var w: float = minf(400.0, hud_font.get_string_size(content, HORIZONTAL_ALIGNMENT_LEFT, -1, 9).x + 17.0)
	x = clampf(x, 4.0, VIEW_W - w - 4.0)
	draw_rect(Rect2(x, y, w, 17), Color(0.09, 0.075, 0.14, 0.95))
	draw_rect(Rect2(x, y, 2, 17), Color("#ffcb23"))
	_txt(content, x + 8.0, y + 12.0, 9, Color("#f7deb0"))

func _txt(content: String, x: float, y: float, font_size: int, color: Color) -> void:
	if hud_font != null:
		draw_string(hud_font, Vector2(floorf(x), floorf(y)), content,
			HORIZONTAL_ALIGNMENT_LEFT, -1.0, font_size, color)

func _draw_center(content: String, y: float, font_size: int, color: Color) -> void:
	var width: float = hud_font.get_string_size(content, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
	_txt(content, (VIEW_W - width) * 0.5, y, font_size, color)
