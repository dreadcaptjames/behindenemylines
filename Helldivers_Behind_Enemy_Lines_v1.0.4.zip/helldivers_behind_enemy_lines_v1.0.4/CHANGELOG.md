# v1.0.4 — Dynamic Depth & iPad Gesture Fix

- Fixed late-stage scenery cables and foreground machinery that intersected the player.
- Removed full-screen scanline and ground-darkening overlays.
- Added varied multi-plane industrial building silhouettes, fans, window lighting and slow-moving haze.
- Added iPad Safari touch gesture cancellation for play surface and control buttons (scoped, nonpassive).
- Prevented native text selection, double-tap zoom, context menus and accidental scrolling in touch play.
- Preserved version 1.0.3 gait and barrel alignment, touchscreen actions, campaign and saved checkpoints.
