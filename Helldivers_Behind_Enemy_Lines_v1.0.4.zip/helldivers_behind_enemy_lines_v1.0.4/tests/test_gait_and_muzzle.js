const fs=require('fs'),path=require('path'),vm=require('vm');
const {Canvas,Image}=require('skia-canvas');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'browser-demo/index.html'),'utf8');
const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const canvas=new Canvas(960,540);
canvas.focus=()=>{};canvas.addEventListener=()=>{};canvas.getBoundingClientRect=()=>({left:0,top:0,width:960,height:540});
const el=()=>({hidden:true,innerHTML:'',append(){},addEventListener(){},setAttribute(){},focus(){}});
const elements={game:canvas,controlsPanel:el()};
const document={body:{classList:{contains(){return false}}},getElementById:name=>elements[name]||(elements[name]=el()),createElement:el};
class Img extends Image{set src(url){super.src=path.resolve(root,'browser-demo',url)}get naturalWidth(){return this.width}}
class Audio{constructor(){this.volume=0}play(){return Promise.resolve()}cloneNode(){return this}}
const localStorage={getItem(){return null},setItem(){},removeItem(){}};
const ctx=vm.createContext({console,Math,Set,Map,Image:Img,Audio,document,window:{addEventListener(){}},navigator:{getGamepads:()=>[]},localStorage,requestAnimationFrame:()=>{},performance:{now:()=>0},Date});
vm.runInContext(script,ctx);
const run=code=>vm.runInContext(code,ctx);
const check=(ok,description)=>{if(!ok)throw new Error(description)};
(async()=>{
 await new Promise(resolve=>setTimeout(resolve,950));
 check(run('assets.filter(x=>art[x]?.naturalWidth).length')===244,'244 loaded assets');
 run('reset();state="playing";p.x=220;p.y=228;p.ground=true;p.fire=0;p.reload=0;camera=0;bullets=[]');
 const cases=[
   {name:'right keyboard',mouse:false,face:1},
   {name:'left keyboard',mouse:false,face:-1},
   {name:'right/up mouse',mouse:true,x:370,y:121},
   {name:'right/down mouse',mouse:true,x:360,y:224},
   {name:'left/up mouse',mouse:true,x:95,y:123},
   {name:'left/down mouse',mouse:true,x:110,y:210},
   {name:'touch-style right/up aim',mouse:true,x:355,y:120},
 ];
 for(const t of cases){
   run(`p.x=220;p.y=228;p.face=${t.face||1};p.fire=0;p.reload=0;p.ammo=18;bullets=[];mouseDown=${!!t.mouse};mouseSeen=clock+5;${t.mouse?`mouseX=${t.x};mouseY=${t.y};`:''}shoot();`);
   const b=run('bullets[0]');const gun=run('rifleGeometry()');
   check(!!b,`${t.name}: bullet not fired`);
   check(Math.hypot(b.x-gun.muzzleX,b.y-gun.muzzleY)<.01,`${t.name}: shot not on visual muzzle`);
   check(Math.abs(Math.hypot(b.vx,b.vy)-460)<.1,`${t.name}: speed changed`);
   check(Math.sign(b.vx)===gun.facing,`${t.name}: wrong gun direction`);
   run('render()');
   if(t.mouse){
     const tx=t.x-b.x,ty=t.y-b.y;
     const dot=(tx*b.vx+ty*b.vy)/(Math.hypot(tx,ty)*Math.hypot(b.vx,b.vy));
     check(dot>.999,`${t.name}: bullet does not follow cursor`);
   }
   console.log('PASS muzzle: '+t.name, 'exit=',[b.x.toFixed(1),b.y.toFixed(1)],'angle=',gun.theta.toFixed(2));
 }
 // Movement must advance discrete gait poses using world distance, even during firing.
 run('p.x=220;p.y=228;p.ground=true;p.vx=0;p.stride=0;p.fire=0;mouseDown=false;keys.add("d");');
 const frames=new Set();
 for(let i=0;i<42;i++){run('update(.016)');frames.add(run('Math.floor(p.stride*8)%8'));}
 run('keys.delete("d");');
 check(frames.size>=7,'Gait failed to cycle all eight poses');
 run('p.fire=.13;p.vx=143;p.ground=true;render()');
 check(run('Math.floor(p.stride*8)%8')>=0,'Run animation lost while firing');
 // Save a real frame with gun and shot aligned (game is still responsive).
 run('p.x=210;p.y=228;camera=0;p.ground=true;p.fire=0;p.reload=0;mouseDown=true;mouseSeen=clock+5;mouseX=355;mouseY=136;bullets=[];shoot();render();');
 await fs.promises.writeFile(path.join(root,'SCREENSHOT_RIFLE_ALIGNMENT.png'),await canvas.toBuffer('png'));
 console.log('PASS: eight-pose locomotion, all rifle directions, projectile/barrel alignment.');
})().catch(e=>{console.error(e);process.exitCode=1});
