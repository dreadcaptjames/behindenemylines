# v1.0.3 — Character Mechanics

**Locomotion:** hip centers are kept near the torso. Knees articulate in a narrower range, feet alternate between planted stance and lifted recovery, and the eight-frame cycle advances by actual horizontal travel. Upper body and cape remain coherent.

**Weapon:** the rifle source pixels are preserved as a separate transparent part. Aim rotates the gun about the shoulder pivot. The visible rifle tip, muzzle flash, and fired projectile share an identical transform, avoiding screen-space guesses. All input methods use the same weapon geometry.

**Readability:** no oval cast shadow is drawn, and no wide shadow remains baked into character frames.
