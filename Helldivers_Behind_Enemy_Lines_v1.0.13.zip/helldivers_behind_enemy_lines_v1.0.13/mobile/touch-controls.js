/* Behind Enemy Lines — mobile touch controller, version 1.0.13.
   This script is deliberately separate from the game so the desktop runtime and
   older archived ZIP releases remain intact. Loaded AFTER the game's script. */
(() => {
  'use strict';
  const shell = document.getElementById('shell');
  const canvas = document.getElementById('game');
  if (!shell || !canvas) return;
  const params = new URLSearchParams(location.search);
  const force = params.get('touch') === '1';
  const touchCapable = force || (navigator.maxTouchPoints || 0) > 0 || matchMedia('(pointer:coarse)').matches;
  if (!touchCapable) return;

  document.body.classList.add('bel-touch-available');
  const toolbar = document.createElement('section');
  toolbar.id = 'belTouchControls';
  toolbar.setAttribute('aria-label', 'Mobile game controls');
  toolbar.innerHTML = `
    <div class="tc-layer tc-toolbar" id="tcTools" role="group" aria-label="Equipment and mission controls">
      <button type="button" data-action="reload" aria-label="Reload rifle">RLD</button>
      <button type="button" data-action="stratagem" aria-label="Enter orbital stratagem code">STRAT</button>
      <button type="button" data-action="pulse" aria-label="Activate EMP">EMP</button>
      <button type="button" data-action="map" aria-label="Toggle sector map">MAP</button>
      <button type="button" data-key="escape" aria-label="Pause or resume game">PAUSE</button>
    </div>
    <div class="tc-layer tc-dpad" id="tcDpad" role="group" aria-label="Movement and directional stratagem pad">
      <button type="button" data-key="arrowup" aria-label="Direction up">▲</button>
      <button type="button" data-key="arrowleft" aria-label="Move left">◀</button>
      <div class="tc-dpad-center">MOVE<br>CODE</div>
      <button type="button" data-key="arrowright" aria-label="Move right">▶</button>
      <button type="button" data-key="arrowdown" aria-label="Direction down">▼</button>
    </div>
    <div class="tc-layer tc-actions" id="tcActions" role="group" aria-label="Movement and interaction actions">
      <button type="button" data-action="interact" aria-label="Interact with object">USE</button>
      <button type="button" data-action="dive" aria-label="Tactical dive">DIVE</button>
      <button type="button" data-action="jump" aria-label="Jump or use jump jets">JUMP</button>
    </div>
    <div class="tc-layer tc-aim" id="tcAim" role="application" aria-label="Drag to aim and automatically fire">
      <div class="tc-aim-ring"></div><div class="tc-aim-knob" id="tcAimKnob"></div>
      <div class="tc-aim-label">AIM + FIRE</div>
    </div>
    <div class="tc-center-stage" id="tcStage" hidden>
      <button type="button" data-key="enter" id="tcAdvance" aria-label="Start mission or continue dialogue">DEPLOY</button>
      <button type="button" data-key="c" id="tcResumeSave" class="tc-secondary" aria-label="Resume saved checkpoint">RESUME CHECKPOINT</button>
    </div>
    <div class="tc-strat-hint" id="tcStratHint" hidden>STRATAGEM CODE: ▲ ▶ ▼ ▲</div>
    <div class="tc-portrait-advice" role="status">⟳ ROTATE TO LANDSCAPE FOR COMFORTABLE CONTROLS</div>`;
  shell.appendChild(toolbar);

  const topButton = document.createElement('button');
  topButton.id = 'belTouchToggle';
  topButton.type = 'button';
  topButton.setAttribute('aria-pressed','true');
  document.querySelector('header')?.append(topButton);
  const tools = toolbar.querySelector('#tcTools');
  // Keep secondary actions in the header rather than over the in-game HUD.
  document.querySelector('header')?.appendChild(tools);
  const dpad = toolbar.querySelector('#tcDpad');
  const actions = toolbar.querySelector('#tcActions');
  const aim = toolbar.querySelector('#tcAim');
  const aimKnob = toolbar.querySelector('#tcAimKnob');
  const stage = toolbar.querySelector('#tcStage');
  const advance = toolbar.querySelector('#tcAdvance');
  const resume = toolbar.querySelector('#tcResumeSave');
  const hint = toolbar.querySelector('#tcStratHint');

  let enabled = true;
  try { enabled = localStorage.getItem('bel_touch_enabled') !== 'off'; } catch (_) {}
  // Settings intentionally remain local to this device and have safe defaults.
  const mobileDefaults={hand:'right',size:100,opacity:90,haptics:false,savePower:false};
  let mobilePrefs={...mobileDefaults};
  try{
    const saved=JSON.parse(localStorage.getItem('bel_mobile_layout_v1')||'null');
    if(saved && typeof saved==='object'){
      mobilePrefs.hand=saved.hand==='left'?'left':'right';
      mobilePrefs.size=[85,100,115].includes(saved.size)?saved.size:100;
      mobilePrefs.opacity=[65,80,90,100].includes(saved.opacity)?saved.opacity:90;
      mobilePrefs.haptics=saved.haptics===true;
      mobilePrefs.savePower=saved.savePower===true;
    }
  }catch(_){}
  const controlsPanel=document.getElementById('controlsPanel');
  const touchSettings=document.createElement('div');
  touchSettings.id='belMobileSettings';
  touchSettings.innerHTML=`
    <h3>TACTICAL TOUCH CONFIGURATION</h3>
    <p class="tc-settings-note">Adjust your controls for your grip and screen. Changes apply immediately and are saved on this device.</p>
    <div class="tc-settings-grid">
      <label>THUMB LAYOUT <select id="tcHand"><option value="right">Move left · Aim right</option><option value="left">Aim left · Move right</option></select></label>
      <label>CONTROL SIZE <select id="tcSize"><option value="85">Compact</option><option value="100">Standard</option><option value="115">Large</option></select></label>
      <label>CONTROL VISIBILITY <select id="tcOpacity"><option value="65">Subtle</option><option value="80">Balanced</option><option value="90">High</option><option value="100">Maximum</option></select></label>
      <label class="tc-check"><input id="tcHaptics" type="checkbox"> Haptics on compatible devices</label>
      <label class="tc-check"><input id="tcSavePower" type="checkbox"> Battery saver · 30 FPS</label>
      <label class="tc-music-control">MUSIC VOLUME <input type="range" id="tcMusicLevel" min="0" max="100" step="5" aria-label="Soundtrack volume on touch devices"></label>
    </div>
    <div class="tc-settings-bottom"><button type="button" id="tcResetMobile">RESTORE DEFAULTS</button><button type="button" id="tcSettingsDone">DONE · RETURN TO MISSION</button><span>Slide on the movement pad to steer. Hold AIM + FIRE to shoot.</span></div>`;
  // This panel is scrollable: Safari native gestures remain available inside it.
  controlsPanel?.querySelector('.panel-actions')?.before(touchSettings);
  const touchConfigBtn=document.createElement('button');
  touchConfigBtn.id='tcSettingsBtn';touchConfigBtn.type='button';
  touchConfigBtn.textContent='⚙ LAYOUT';
  touchConfigBtn.setAttribute('aria-label','Adjust touch control size, handedness and performance');
  tools.appendChild(touchConfigBtn);
  function applyMobilePrefs(){
    document.body.classList.toggle('bel-touch-lefty',mobilePrefs.hand==='left');
    document.body.style.setProperty('--tc-control-scale',String(mobilePrefs.size/100));
    document.body.style.setProperty('--tc-overlay-opacity',String(mobilePrefs.opacity/100));
    window.belMobilePowerSave=mobilePrefs.savePower;
    for(const [id,value] of Object.entries({tcHand:mobilePrefs.hand,tcSize:String(mobilePrefs.size),tcOpacity:String(mobilePrefs.opacity)})){
      const el=touchSettings.querySelector('#'+id);if(el)el.value=value;
    }
    touchSettings.querySelector('#tcHaptics').checked=mobilePrefs.haptics;
    touchSettings.querySelector('#tcSavePower').checked=mobilePrefs.savePower;
    try{localStorage.setItem('bel_mobile_layout_v1',JSON.stringify(mobilePrefs))}catch(_){}
  }
  const configEvents={tcHand:['hand',v=>v],tcSize:['size',v=>Number(v)],tcOpacity:['opacity',v=>Number(v)],tcHaptics:['haptics',v=>v],tcSavePower:['savePower',v=>v]};
  for(const [id,[field,convert]] of Object.entries(configEvents)){
    const el=touchSettings.querySelector('#'+id);
    el.addEventListener('change',()=>{mobilePrefs[field]=convert(el.type==='checkbox'?el.checked:el.value);applyMobilePrefs()});
  }
  // Browser header volume control is deliberately hidden on compact touch
  // screens. Mirror it here so the soundtrack stays fully adjustable.
  const mainMusicVolume=document.getElementById('musicVolume');
  const touchMusicVolume=touchSettings.querySelector('#tcMusicLevel');
  if(mainMusicVolume){
    touchMusicVolume.value=mainMusicVolume.value;
    touchMusicVolume.addEventListener('input',()=>{
      mainMusicVolume.value=touchMusicVolume.value;
      mainMusicVolume.dispatchEvent(new Event('input',{bubbles:true}));
    });
    mainMusicVolume.addEventListener('input',()=>{touchMusicVolume.value=mainMusicVolume.value});
  }
  touchSettings.querySelector('#tcResetMobile').addEventListener('click',()=>{mobilePrefs={...mobileDefaults};applyMobilePrefs()});
  touchSettings.querySelector('#tcSettingsDone').addEventListener('click',()=>document.getElementById('closeBindings')?.click());
  const openTouchSettings=()=>{
    const opener=document.getElementById('controlsToggle');
    if(controlsPanel?.hidden)opener?.click();
    touchSettings.scrollIntoView({block:'nearest',behavior:'auto'});
  };
  touchConfigBtn.addEventListener('pointerdown',event=>{
    if(event.pointerType==='touch'){
      event.preventDefault();event.stopPropagation();openTouchSettings();
    }
  });
  touchConfigBtn.addEventListener('click',openTouchSettings);
  applyMobilePrefs();
  function haptic(ms=8){
    if(mobilePrefs.haptics && navigator.vibrate)try{navigator.vibrate(ms)}catch(_){}
  }
  const heldPointers = new Map();
  const activeKeys = new Map();
  const dpadPointers = new Set();
  const aimState = { pointer: null, x: 1, y: 0 };
  let lastView = '';

  function sendKey(key, down) {
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { key, bubbles:true, cancelable:true }));
  }
  function keyFor(button) {
    const action = button.dataset.action;
    if (action) {
      try { if (typeof bindings !== 'undefined' && bindings[action]) return bindings[action]; } catch (_) {}
    }
    return button.dataset.key || '';
  }
  function takeKey(pointer, button) {
    const key = keyFor(button);
    if (!key || heldPointers.has(pointer)) return;
    heldPointers.set(pointer, { button, key });
    activeKeys.set(key, (activeKeys.get(key)||0)+1);
    if (activeKeys.get(key) === 1) sendKey(key, true);
    button.classList.add('pressed');
    haptic(7);
  }
  function dropKey(pointer) {
    const held = heldPointers.get(pointer);
    if (!held) return;
    heldPointers.delete(pointer);
    held.button.classList.remove('pressed');
    const count = (activeKeys.get(held.key)||1)-1;
    if (count <= 0) { activeKeys.delete(held.key); sendKey(held.key, false); }
    else activeKeys.set(held.key, count);
  }
  function resetControls() {
    for (const pointer of [...heldPointers.keys()]) dropKey(pointer);
    dpadPointers.clear();
    if (aimState.pointer != null) stopAim(aimState.pointer);
  }
  function setEnabled(on) {
    enabled = on;
    toolbar.hidden = !on;
    tools.hidden = !on;
    document.body.classList.toggle('bel-touch-active', on);
    topButton.textContent = on ? '✥ TOUCH ON' : '✥ TOUCH OFF';
    topButton.setAttribute('aria-pressed',String(on));
    if (!on) resetControls();
    try { localStorage.setItem('bel_touch_enabled',on?'on':'off'); } catch (_) {}
  }
  topButton.addEventListener('click', () => setEnabled(!enabled));

  // Safari sometimes treats repeated touch and long presses as zoom or selection.
  // Only suppress native gestures while TOUCH mode is enabled *on game controls*.
  // Leave browser chrome and the editable bindings modal alone.
  const isPlayTarget = target => {
    if (!enabled || !target || !target.closest) return false;
    if (target.closest('#controlsPanel')) return false;
    return !!target.closest('#shell, #tcTools');
  };
  const cancelNativeGameGesture = event => {
    if (isPlayTarget(event.target) && event.cancelable) event.preventDefault();
  };
  for(const type of ['touchstart','touchmove','touchend','touchcancel']) {
    document.addEventListener(type,cancelNativeGameGesture,{capture:true,passive:false});
  }
  document.addEventListener('selectstart',cancelNativeGameGesture,{capture:true});
  document.addEventListener('dragstart',cancelNativeGameGesture,{capture:true});
  document.addEventListener('contextmenu',cancelNativeGameGesture,{capture:true});
  document.addEventListener('dblclick',cancelNativeGameGesture,{capture:true});
  // iOS Safari's proprietary pinch gestures bypass touch-action in some versions.
  for(const type of ['gesturestart','gesturechange','gestureend']) {
    document.addEventListener(type,cancelNativeGameGesture,{capture:true,passive:false});
  }
  document.addEventListener('pointerdown',event=>{
    if (!isPlayTarget(event.target)) return;
    if (event.pointerType==='touch' && event.cancelable) event.preventDefault();
  },{capture:true,passive:false});


  // Buttons create the same keyboard actions that desktop uses. Pointer capture
  // and a per-pointer key count allow two thumbs (and overlapping actions) safely.
  [...toolbar.querySelectorAll('button[data-action],button[data-key]'), ...tools.querySelectorAll('button[data-action],button[data-key]')].forEach(button => {
    button.addEventListener('pointerdown', event => {
      if (!enabled || event.button !== 0) return;
      event.preventDefault(); event.stopPropagation();
      if (button.disabled) return;
      try { button.setPointerCapture(event.pointerId); } catch (_) {}
      if (typeof musicOn !== 'undefined' && musicOn && typeof startMusic === 'function') startMusic();
      takeKey(event.pointerId, button);
      if(button.closest('#tcDpad')) dpadPointers.add(event.pointerId);
    });
    for (const type of ['pointerup','pointercancel','lostpointercapture']) {
      button.addEventListener(type, event => {
        event.preventDefault(); event.stopPropagation(); dropKey(event.pointerId);
        if(button.closest('#tcDpad')) dpadPointers.delete(event.pointerId);
      });
    }
    button.addEventListener('contextmenu', event => event.preventDefault());
  });

  // Smooth D-pad transitions: a thumb can slide from LEFT to RIGHT without
  // lifting. The same real directional keys remain available for stratagems.
  const dpadTargets={up:dpad.querySelector('[data-key="arrowup"]'),left:dpad.querySelector('[data-key="arrowleft"]'),right:dpad.querySelector('[data-key="arrowright"]'),down:dpad.querySelector('[data-key="arrowdown"]')};
  function steerDpad(event){
    if(!dpadPointers.has(event.pointerId))return;
    const r=dpad.getBoundingClientRect();
    const dx=event.clientX-r.left-r.width/2,dy=event.clientY-r.top-r.height/2;
    let btn=null;
    if(Math.hypot(dx,dy)>Math.min(r.width,r.height)*.18){
      btn=Math.abs(dx)>Math.abs(dy)?dpadTargets[dx<0?'left':'right']:dpadTargets[dy<0?'up':'down'];
    }
    if(heldPointers.get(event.pointerId)?.button!==btn){
      dropKey(event.pointerId);
      if(btn)takeKey(event.pointerId,btn);
    }
  }
  dpad.addEventListener('pointerdown',event=>{
    if(!enabled||event.button!==0||event.target.closest('button'))return;
    event.preventDefault();event.stopPropagation();
    dpadPointers.add(event.pointerId);
    try{dpad.setPointerCapture(event.pointerId)}catch(_){}
    steerDpad(event);
  });
  dpad.addEventListener('pointermove',event=>{
    if(!dpadPointers.has(event.pointerId))return;
    event.preventDefault();steerDpad(event);
  });
  for(const evt of ['pointerup','pointercancel','lostpointercapture'])dpad.addEventListener(evt,event=>{
    dpadPointers.delete(event.pointerId);dropKey(event.pointerId);
  });

  function moveAim(event) {
    const box = aim.getBoundingClientRect();
    const dx = event.clientX-(box.left+box.width/2), dy=event.clientY-(box.top+box.height/2);
    const r = Math.hypot(dx,dy);
    if (r > 9) { aimState.x=dx/r; aimState.y=dy/r; }
    const lim = Math.min(r,box.width*.31);
    const px = r > 0 ? dx/r*lim : 0, py = r > 0 ? dy/r*lim : 0;
    aimKnob.style.transform=`translate(${px}px,${py}px)`;
    aim.classList.add('is-aiming');
    applyAim();
  }
  function applyAim() {
    // The gameplay engine already uses mouseX/Y and mouseDown to aim at world
    // coordinates. Reuse it, rather than creating an incompatible projectile path.
    try {
      if (!enabled || aimState.pointer === null || typeof state === 'undefined' || state !== 'playing' || !p) return;
      mouseDown = true;
      mouseX = p.x-camera + aimState.x*135;
      mouseY = p.y-44 + aimState.y*135;
      mouseSeen = clock + 5;
    } catch (_) {}
  }
  function stopAim(pointer) {
    if (aimState.pointer !== pointer) return;
    aimState.pointer = null;
    aim.classList.remove('is-aiming');
    aimKnob.style.transform = 'translate(0,0)';
    try { mouseDown = false; } catch (_) {}
  }
  aim.addEventListener('pointerdown', event => {
    if (!enabled || event.button !== 0 || aimState.pointer !== null) return;
    event.preventDefault(); event.stopPropagation();
    aimState.pointer=event.pointerId;
    haptic(10);
    aimState.x=1;aimState.y=0;
    try { aim.setPointerCapture(event.pointerId); } catch (_) {}
    if (typeof musicOn !== 'undefined' && musicOn && typeof startMusic === 'function') startMusic();
    moveAim(event);
  });
  aim.addEventListener('pointermove', event => {
    if (aimState.pointer !== event.pointerId) return;
    event.preventDefault(); event.stopPropagation(); moveAim(event);
  });
  for (const name of ['pointerup','pointercancel','lostpointercapture']) aim.addEventListener(name, event=> {
    if (aimState.pointer === event.pointerId) { event.preventDefault(); event.stopPropagation(); stopAim(event.pointerId); }
  });
  aim.addEventListener('contextmenu', e=>e.preventDefault());
  window.addEventListener('blur',resetControls);
  document.addEventListener('visibilitychange',()=>{ if(document.hidden) resetControls(); });

  function refresh() {
    if (enabled) {
      const s = typeof state !== 'undefined' ? state : 'title';
      const playing = s === 'playing' && !(typeof mapOpen !== 'undefined' && mapOpen) && (!controlsPanel || controlsPanel.hidden);
      const dialog = s === 'dialogue';
      const title = s === 'title';
      const pause = s === 'pause';
      const victory = s === 'victory';
      document.body.classList.toggle('bel-ui-paused',pause);
      document.body.classList.toggle('bel-ui-dialogue',dialog);
      const showStage = title||dialog||pause||victory;
      stage.hidden = !showStage;
      tools.hidden = !playing && !pause;
      if(controlsPanel && !controlsPanel.hidden)tools.hidden=true;
      dpad.hidden = !playing;
      actions.hidden = !playing;
      aim.hidden = !playing;
      hint.hidden = !playing || typeof stratMode === 'undefined' || !stratMode;
      advance.textContent = title ? (typeof confirmNewMission !== 'undefined' && confirmNewMission?'CONFIRM NEW':'DEPLOY') : dialog ? 'CONTINUE ▸' : pause ? 'RESUME GAME' : 'REDEPLOY';
      advance.dataset.key = pause ? 'escape' : 'enter';
      resume.hidden = !title || typeof hasSave !== 'function' || (!hasSave() && !(typeof confirmNewMission!=='undefined' && confirmNewMission));
      resume.textContent = typeof confirmNewMission!=='undefined' && confirmNewMission?'CANCEL':'RESUME CHECKPOINT';
      resume.dataset.key = typeof confirmNewMission!=='undefined' && confirmNewMission?'escape':'c';
      if (!playing && aimState.pointer !== null) stopAim(aimState.pointer);
      const empButton = tools.querySelector('[data-action="pulse"]');
      const stratButton = tools.querySelector('[data-action="stratagem"]');
      if (empButton) empButton.classList.toggle('tc-locked', typeof emp !== 'undefined' && !emp);
      if (stratButton) stratButton.classList.toggle('tc-locked', typeof comms !== 'undefined' && !comms);
      if (playing) applyAim();
    }
    requestAnimationFrame(refresh);
  }
  setEnabled(enabled);
  refresh();
})();
