# v1.0.5 — Movement and Automaton Scale

- Added 4 painted jump keyframes, improved jump-jet posing, and 4 dedicated dive keyframes for right/left facings.
- Dive action now has crouch, airborne launch, travel, recovery, and matching horizontal/vertical momentum.
- Replaced the old dive's upright sprite/shifting behavior with a horizontal prone pose and dynamic collision box.
- Scaled 7 Automaton ground-unit variants and coordinated enemy hitboxes, threat detection, optics, firing positions and melee ranges.
- Kept drones and turrets smaller by design and preserved existing Hulk-class bosses.
- Preserved browser touch controls, save compatibility, two-act progression, character rifle aim and environmental depth fixes.
- Updated editable Godot companion; engine execution remains unverified.
