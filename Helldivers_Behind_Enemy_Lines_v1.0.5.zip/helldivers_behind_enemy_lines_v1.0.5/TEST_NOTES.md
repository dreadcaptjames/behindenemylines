# v1.0.5 verification notes

Browser tests executed successfully:
- `node tests/test_headless_canvas.js` — 254/254 registered browser assets; original mission progression; all sectors; boss progression; save/load; enemy-scale assertions; dive startup/launch/recovery; jump poses; screenshots.
- `node tests/test_gait_and_muzzle.js` — eight-frame gait and seven muzzle/aim checks including touch-style aiming.
- `python tests/test_hero_art.py` — 4 airborne poses, 4 dive poses, shadow-free frames, intact animated sprites.
- `python tests/test_mobile_gestures.py` — multitouch movement with held keys and gesture suppression in browser emulation.

Generated in-renderer screenshots: `SCREENSHOT_SCALE.png`, `SCREENSHOT_JUMP.png`, `SCREENSHOT_DIVE.png`, `SCREENSHOT_GAMEPLAY.png`.

The Godot source and assets were updated for parity but were **not run-tested** in the Godot engine.
Physical iPad Safari testing remains to be done.
