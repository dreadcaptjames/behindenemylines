/* Behind Enemy Lines — mobile touch controller, version 1.0.5.
   This script is deliberately separate from the game so the desktop runtime and
   older archived ZIP releases remain intact. Loaded AFTER the game's script. */
(() => {
  'use strict';
  const shell = document.getElementById('shell');
  const canvas = document.getElementById('game');
  if (!shell || !canvas) return;
  const params = new URLSearchParams(location.search);
  const force = params.get('touch') === '1';
  const touchCapable = force || (navigator.maxTouchPoints || 0) > 0 || matchMedia('(pointer:coarse)').matches;
  if (!touchCapable) return;

  document.body.classList.add('bel-touch-available');
  const toolbar = document.createElement('section');
  toolbar.id = 'belTouchControls';
  toolbar.setAttribute('aria-label', 'Mobile game controls');
  toolbar.innerHTML = `
    <div class="tc-layer tc-toolbar" id="tcTools" role="group" aria-label="Equipment and mission controls">
      <button type="button" data-action="reload" aria-label="Reload rifle">RLD</button>
      <button type="button" data-action="stratagem" aria-label="Enter orbital stratagem code">STRAT</button>
      <button type="button" data-action="pulse" aria-label="Activate EMP">EMP</button>
      <button type="button" data-action="map" aria-label="Toggle sector map">MAP</button>
      <button type="button" data-key="escape" aria-label="Pause or resume game">PAUSE</button>
    </div>
    <div class="tc-layer tc-dpad" id="tcDpad" role="group" aria-label="Movement and directional stratagem pad">
      <button type="button" data-key="arrowup" aria-label="Direction up">▲</button>
      <button type="button" data-key="arrowleft" aria-label="Move left">◀</button>
      <div class="tc-dpad-center">MOVE<br>CODE</div>
      <button type="button" data-key="arrowright" aria-label="Move right">▶</button>
      <button type="button" data-key="arrowdown" aria-label="Direction down">▼</button>
    </div>
    <div class="tc-layer tc-actions" id="tcActions" role="group" aria-label="Movement and interaction actions">
      <button type="button" data-action="interact" aria-label="Interact with object">USE</button>
      <button type="button" data-action="dive" aria-label="Tactical dive">DIVE</button>
      <button type="button" data-action="jump" aria-label="Jump or use jump jets">JUMP</button>
    </div>
    <div class="tc-layer tc-aim" id="tcAim" role="application" aria-label="Drag to aim and automatically fire">
      <div class="tc-aim-ring"></div><div class="tc-aim-knob" id="tcAimKnob"></div>
      <div class="tc-aim-label">AIM + FIRE</div>
    </div>
    <div class="tc-center-stage" id="tcStage" hidden>
      <button type="button" data-key="enter" id="tcAdvance" aria-label="Start mission or continue dialogue">DEPLOY</button>
      <button type="button" data-key="c" id="tcResumeSave" class="tc-secondary" aria-label="Resume saved checkpoint">RESUME CHECKPOINT</button>
    </div>
    <div class="tc-strat-hint" id="tcStratHint" hidden>STRATAGEM CODE: ▲ ▶ ▼ ▲</div>
    <div class="tc-portrait-advice">ROTATE FOR BETTER VISIBILITY</div>`;
  shell.appendChild(toolbar);

  const topButton = document.createElement('button');
  topButton.id = 'belTouchToggle';
  topButton.type = 'button';
  topButton.setAttribute('aria-pressed','true');
  document.querySelector('header')?.append(topButton);
  const tools = toolbar.querySelector('#tcTools');
  // Keep secondary actions in the header rather than over the in-game HUD.
  document.querySelector('header')?.appendChild(tools);
  const dpad = toolbar.querySelector('#tcDpad');
  const actions = toolbar.querySelector('#tcActions');
  const aim = toolbar.querySelector('#tcAim');
  const aimKnob = toolbar.querySelector('#tcAimKnob');
  const stage = toolbar.querySelector('#tcStage');
  const advance = toolbar.querySelector('#tcAdvance');
  const resume = toolbar.querySelector('#tcResumeSave');
  const hint = toolbar.querySelector('#tcStratHint');

  let enabled = true;
  try { enabled = localStorage.getItem('bel_touch_enabled') !== 'off'; } catch (_) {}
  const heldPointers = new Map();
  const activeKeys = new Map();
  const aimState = { pointer: null, x: 1, y: 0 };
  let lastView = '';

  function sendKey(key, down) {
    window.dispatchEvent(new KeyboardEvent(down ? 'keydown' : 'keyup', { key, bubbles:true, cancelable:true }));
  }
  function keyFor(button) {
    const action = button.dataset.action;
    if (action) {
      try { if (typeof bindings !== 'undefined' && bindings[action]) return bindings[action]; } catch (_) {}
    }
    return button.dataset.key || '';
  }
  function takeKey(pointer, button) {
    const key = keyFor(button);
    if (!key || heldPointers.has(pointer)) return;
    heldPointers.set(pointer, { button, key });
    activeKeys.set(key, (activeKeys.get(key)||0)+1);
    if (activeKeys.get(key) === 1) sendKey(key, true);
    button.classList.add('pressed');
  }
  function dropKey(pointer) {
    const held = heldPointers.get(pointer);
    if (!held) return;
    heldPointers.delete(pointer);
    held.button.classList.remove('pressed');
    const count = (activeKeys.get(held.key)||1)-1;
    if (count <= 0) { activeKeys.delete(held.key); sendKey(held.key, false); }
    else activeKeys.set(held.key, count);
  }
  function resetControls() {
    for (const pointer of [...heldPointers.keys()]) dropKey(pointer);
    if (aimState.pointer != null) stopAim(aimState.pointer);
  }
  function setEnabled(on) {
    enabled = on;
    toolbar.hidden = !on;
    tools.hidden = !on;
    document.body.classList.toggle('bel-touch-active', on);
    topButton.textContent = on ? '✥ TOUCH ON' : '✥ TOUCH OFF';
    topButton.setAttribute('aria-pressed',String(on));
    if (!on) resetControls();
    try { localStorage.setItem('bel_touch_enabled',on?'on':'off'); } catch (_) {}
  }
  topButton.addEventListener('click', () => setEnabled(!enabled));

  // Safari sometimes treats repeated touch and long presses as zoom or selection.
  // Only suppress native gestures while TOUCH mode is enabled *on game controls*.
  // Leave browser chrome and the editable bindings modal alone.
  const isPlayTarget = target => {
    if (!enabled || !target || !target.closest) return false;
    if (target.closest('#controlsPanel')) return false;
    return !!target.closest('#shell, #tcTools');
  };
  const cancelNativeGameGesture = event => {
    if (isPlayTarget(event.target) && event.cancelable) event.preventDefault();
  };
  for(const type of ['touchstart','touchmove','touchend','touchcancel']) {
    document.addEventListener(type,cancelNativeGameGesture,{capture:true,passive:false});
  }
  document.addEventListener('selectstart',cancelNativeGameGesture,{capture:true});
  document.addEventListener('dragstart',cancelNativeGameGesture,{capture:true});
  document.addEventListener('contextmenu',cancelNativeGameGesture,{capture:true});
  document.addEventListener('dblclick',cancelNativeGameGesture,{capture:true});
  // iOS Safari's proprietary pinch gestures bypass touch-action in some versions.
  for(const type of ['gesturestart','gesturechange','gestureend']) {
    document.addEventListener(type,cancelNativeGameGesture,{capture:true,passive:false});
  }
  document.addEventListener('pointerdown',event=>{
    if (!isPlayTarget(event.target)) return;
    if (event.pointerType==='touch' && event.cancelable) event.preventDefault();
  },{capture:true,passive:false});


  // Buttons create the same keyboard actions that desktop uses. Pointer capture
  // and a per-pointer key count allow two thumbs (and overlapping actions) safely.
  [...toolbar.querySelectorAll('button[data-action],button[data-key]'), ...tools.querySelectorAll('button[data-action],button[data-key]')].forEach(button => {
    button.addEventListener('pointerdown', event => {
      if (!enabled || event.button !== 0) return;
      event.preventDefault(); event.stopPropagation();
      if (button.disabled) return;
      try { button.setPointerCapture(event.pointerId); } catch (_) {}
      if (typeof musicOn !== 'undefined' && musicOn && typeof startMusic === 'function') startMusic();
      takeKey(event.pointerId, button);
    });
    for (const type of ['pointerup','pointercancel','lostpointercapture']) {
      button.addEventListener(type, event => {
        event.preventDefault(); event.stopPropagation(); dropKey(event.pointerId);
      });
    }
    button.addEventListener('contextmenu', event => event.preventDefault());
  });

  function moveAim(event) {
    const box = aim.getBoundingClientRect();
    const dx = event.clientX-(box.left+box.width/2), dy=event.clientY-(box.top+box.height/2);
    const r = Math.hypot(dx,dy);
    if (r > 9) { aimState.x=dx/r; aimState.y=dy/r; }
    const lim = Math.min(r,box.width*.31);
    const px = r > 0 ? dx/r*lim : 0, py = r > 0 ? dy/r*lim : 0;
    aimKnob.style.transform=`translate(${px}px,${py}px)`;
    aim.classList.add('is-aiming');
    applyAim();
  }
  function applyAim() {
    // The gameplay engine already uses mouseX/Y and mouseDown to aim at world
    // coordinates. Reuse it, rather than creating an incompatible projectile path.
    try {
      if (!enabled || aimState.pointer === null || typeof state === 'undefined' || state !== 'playing' || !p) return;
      mouseDown = true;
      mouseX = p.x-camera + aimState.x*135;
      mouseY = p.y-44 + aimState.y*135;
      mouseSeen = clock + 5;
    } catch (_) {}
  }
  function stopAim(pointer) {
    if (aimState.pointer !== pointer) return;
    aimState.pointer = null;
    aim.classList.remove('is-aiming');
    aimKnob.style.transform = 'translate(0,0)';
    try { mouseDown = false; } catch (_) {}
  }
  aim.addEventListener('pointerdown', event => {
    if (!enabled || event.button !== 0 || aimState.pointer !== null) return;
    event.preventDefault(); event.stopPropagation();
    aimState.pointer=event.pointerId;
    aimState.x=1;aimState.y=0;
    try { aim.setPointerCapture(event.pointerId); } catch (_) {}
    if (typeof musicOn !== 'undefined' && musicOn && typeof startMusic === 'function') startMusic();
    moveAim(event);
  });
  aim.addEventListener('pointermove', event => {
    if (aimState.pointer !== event.pointerId) return;
    event.preventDefault(); event.stopPropagation(); moveAim(event);
  });
  for (const name of ['pointerup','pointercancel','lostpointercapture']) aim.addEventListener(name, event=> {
    if (aimState.pointer === event.pointerId) { event.preventDefault(); event.stopPropagation(); stopAim(event.pointerId); }
  });
  aim.addEventListener('contextmenu', e=>e.preventDefault());
  window.addEventListener('blur',resetControls);
  document.addEventListener('visibilitychange',()=>{ if(document.hidden) resetControls(); });

  function refresh() {
    if (enabled) {
      const s = typeof state !== 'undefined' ? state : 'title';
      const playing = s === 'playing';
      const dialog = s === 'dialogue';
      const title = s === 'title';
      const pause = s === 'pause';
      const victory = s === 'victory';
      const showStage = title||dialog||pause||victory;
      stage.hidden = !showStage;
      tools.hidden = !playing && !pause;
      dpad.hidden = !playing;
      actions.hidden = !playing;
      aim.hidden = !playing;
      hint.hidden = !playing || typeof stratMode === 'undefined' || !stratMode;
      advance.textContent = title ? 'DEPLOY' : dialog ? 'CONTINUE ▸' : pause ? 'RESUME GAME' : 'REDEPLOY';
      advance.dataset.key = pause ? 'escape' : 'enter';
      resume.hidden = !title || typeof hasSave !== 'function' || !hasSave();
      if (!playing && aimState.pointer !== null) stopAim(aimState.pointer);
      const empButton = tools.querySelector('[data-action="pulse"]');
      const stratButton = tools.querySelector('[data-action="stratagem"]');
      if (empButton) empButton.classList.toggle('tc-locked', typeof emp !== 'undefined' && !emp);
      if (stratButton) stratButton.classList.toggle('tc-locked', typeof comms !== 'undefined' && !comms);
      if (playing) applyAim();
    }
    requestAnimationFrame(refresh);
  }
  setEnabled(enabled);
  refresh();
})();
