# v1.0.3 — Character Mechanics

**Locomotion:** hip centers are kept near the torso. Knees articulate in a narrower range, feet alternate between planted stance and lifted recovery, and the eight-frame cycle advances by actual horizontal travel. Upper body and cape remain coherent.

**Weapon:** the rifle source pixels are preserved as a separate transparent part. Aim rotates the gun about the shoulder pivot. The visible rifle tip, muzzle flash, and fired projectile share an identical transform, avoiding screen-space guesses. All input methods use the same weapon geometry.

**Readability:** no oval cast shadow is drawn, and no wide shadow remains baked into character frames.

## v1.0.5 — Motion and enemy proportions

The character's legs must remain tucked/grounded within the armor silhouette in ascent and apex rather than the prior exaggerated V-shaped spread. Dive is a committed forward evasion: crouch, ballistic launch, extended flight, recovery. The player's horizontal/prone collision shape changes during the dive. Existing rifle alignment remains intact.

Automatons: Troopers/Marauders visually match the Helldiver; Devastators are markedly taller and bulkier; Striders are tallest among common units. Enemy art, optics, damage areas, projectile positions and melee reach are coordinated using class profiles. Drones and fixed emplacements are exempt from the humanoid scale guideline.
