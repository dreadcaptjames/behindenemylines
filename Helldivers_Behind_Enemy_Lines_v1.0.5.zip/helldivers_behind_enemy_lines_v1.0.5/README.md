# HELLDIVERS: BEHIND ENEMY LINES — v1.0.5

**Movement & Automaton Scale Pass** | Unofficial fan-made prototype.

## Changes in this release

- Four new painted jump poses, selected by ascent, apex, descent and fall velocity; jump-jet art shares the corrected, tighter leg pose.
- Tactical dive is now a proper movement sequence: crouch, launch, airborne travel and recovery, with real horizontal and vertical velocity and a lower collision silhouette while airborne.
- Bigger, class-specific Automaton bodies. Troopers and Marauders are roughly Helldiver-height; Devastators, Berserkers and Scout Striders are taller. Fixed turrets and drones deliberately retain their smaller specialist silhouettes.
- Enemy hitboxes, optics, line-of-sight checks, projectile origins and melee reach use matching scale profiles, avoiding oversized art with tiny hitboxes.
- The existing v1.0.4 atmosphere, corrected rifle muzzle alignment, iPad controls, music toggle, saves, and two-act campaign remain intact.

## Launch

Extract the ZIP, then open `browser-demo/index.html` in a modern browser. On touchscreen devices, rotate to landscape for easier two-thumb controls. Touch controls are in `mobile/`.

Keyboard: A/D move, Space jump, Shift dive, mouse aim + fire, F fire, E interact, R reload, Q stratagem, G EMP, M map.

## Testing

Verified here: browser Canvas campaign and rendering tests, state-based dive trajectory tests, four-stage airborne sprite loading, hitbox/scale tests, rifle muzzle tests, artwork checks and touch gesture tests. The Godot companion (`project.godot`) has been updated to use matching sprites, animation states and sizes, but **has not been executed in Godot** in this environment.

## Public deployment

The full release ZIP is designed for your repository `dreadcaptjames/behindenemylines`; uploading this ZIP intact to the repository root and committing to `main` makes it a deployment candidate for the configured GitHub Pages workflow. It is **not automatically uploaded or deployed** by generating this package.

This fan project is not affiliated with Arrowhead or Sony. Public use of the Helldivers setting and marks may require permission.
