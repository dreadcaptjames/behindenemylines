// Source-to-portrait identity and real canvas render regression for v1.0.17.
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm'),crypto=require('node:crypto');
const {Canvas,Image}=require('skia-canvas');
const root=path.resolve(__dirname,'..');
const html=fs.readFileSync(path.join(root,'browser-demo/index.html'),'utf8');
const js=html.match(/<script>([\s\S]*?)<\/script>/)[1];
const cv=new Canvas(960,540);cv.focus=()=>{};cv.addEventListener=()=>{};cv.getBoundingClientRect=()=>({left:0,top:0,width:480,height:270});
const make=()=>({hidden:true,checked:false,innerHTML:'',append(){},setAttribute(){},addEventListener(){},focus(){},textContent:''});
const elements={game:cv,controlsPanel:make()};const document={body:{classList:{contains:()=>false}},getElementById:k=>elements[k]||(elements[k]=make()),createElement:make};
class LocalImage extends Image{set src(url){super.src=path.resolve(root,'browser-demo',url)}get naturalWidth(){return this.width}get naturalHeight(){return this.height}}
class Audio{constructor(){this.volume=0;this.loop=false}cloneNode(){return this}play(){return Promise.resolve()}}
const storage=new Map(),localStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
const context=vm.createContext({console,Math,Set,Map,Audio,Image:LocalImage,document,window:{addEventListener(){}},navigator:{getGamepads:()=>[]},localStorage,requestAnimationFrame(){},Date,performance:{now:()=>0}});
vm.runInContext(js,context,{filename:'browser-demo/index.html'});
const run=s=>vm.runInContext(s,context);
const examples=[
 ['MISSION CONTROL','radio_command'],['SES JUDGMENT OF DAWN','radio_command'],
 ['HELLDIVER // FIELD LOG 015','radio_helldiver'],
 ['SURVIVOR // SHELTER TWELVE','radio_survivor'],['UNKNOWN TRANSMISSION // SHELTER 12','radio_unknown'],
 ['AUTOMATON COMMAND LINK','radio_automaton'],['WARDEN // COMMAND LINK','radio_warden'],
 ['REACTOR SENTINEL // COMMAND LINK','radio_sentinel'],
 ['COOLANT REGULATOR // DISABLED','radio_technician'],
 ['ACT III // THE SURVIVORS BELOW','radio_command']
];
(async()=>{
 await new Promise(r=>setTimeout(r,750));
 const portraitKeys=['radio_command','radio_helldiver','radio_survivor','radio_unknown','radio_automaton','radio_warden','radio_sentinel','radio_technician'];
 const fingerprints=[];
 for(const key of portraitKeys){
  assert.equal(run(`art.${key}.naturalWidth`),64,key+' width');
  assert.equal(run(`art.${key}.naturalHeight`),64,key+' height');
  fingerprints.push(crypto.createHash('sha256').update(fs.readFileSync(path.join(root,'art',key+'.png'))).digest('hex'));
 }
 assert.equal(new Set(fingerprints).size,8,'eight unique portrait artworks');
 for(const [speaker,key] of examples){
  assert.equal(run('radioPortrait('+JSON.stringify(speaker)+')'),key,'matching sender '+speaker);
 }
 run('reset(); state="playing"; tutorial=0; notifyCd=0;enem=[];');
 const samples=[
  ['MISSION CONTROL','RADIO CHECK COMPLETE','PREPARE FOR DEPLOYMENT'],
  ['HELLDIVER // SECURE CHANNEL','NEGATIVE. THESE PEOPLE ARE THE MISSION.','SENDING OUR EVIDENCE TO EVERY DESTROYER.'],
  ['SURVIVOR // SHELTER TWELVE','WE WERE TOLD YOU ABANDONED US.','WE NEVER STOPPED LISTENING.'],
  ['AUTOMATON COMMAND LINK','UNAUTHORIZED LIFEFORM DETECTED.','EXTERMINATION PROTOCOL.'],
  ['WARDEN // COMMAND LINK','WARDEN UNIT IS ONLINE.','ENEMY CONTACT CONFIRMED.'],
  ['REACTOR SENTINEL // COMMAND LINK','UNREGISTERED OPERATOR DETECTED.','PURGE ALL INTRUDERS.'],
  ['PUMP ALPHA // STABILIZED','FIRST FLOOD CHANNEL DISCHARGED.','LIFE SUPPORT CONTINUES.'],
  ['UNKNOWN TRANSMISSION','IF YOU CAN HEAR THIS ...','WE ARE STILL HERE.'],
 ];
 const collage=new Canvas(2*480,4*129),cc=collage.getContext('2d');cc.fillStyle='#10131c';cc.fillRect(0,0,960,516);
 for(let i=0;i<samples.length;i++){
  const sample=samples[i];run('say('+JSON.stringify([sample])+');dialogAge=9;');
  run('render()');
  const snap=await cv.toBuffer('png');
  const im=new Image();im.src=snap;
  const dstX=(i%2)*480,dstY=Math.floor(i/2)*129;
  cc.drawImage(im,0,296,960,218,dstX,dstY,480,109);
  cc.fillStyle='#141d27';cc.fillRect(dstX,dstY+109,480,20);
  cc.font='bold 12px sans-serif';cc.fillStyle='#e4d6b1';cc.fillText(sample[0],dstX+12,dstY+124);
 }
 const preview=path.resolve(root,'RADIO_PORTRAITS_GAMEPLAY.png');
 await fs.promises.writeFile(preview,await collage.toBuffer('png'));
 console.log('PASS: eight original pixel portraits, speaker mapping, and canvas dialogue render');
 console.log('PREVIEW:',preview);
})().catch(err=>{console.error(err);process.exitCode=1});
