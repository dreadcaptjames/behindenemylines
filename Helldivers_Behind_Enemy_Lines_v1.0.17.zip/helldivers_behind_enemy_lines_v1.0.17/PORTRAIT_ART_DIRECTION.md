# Character portraits — v1.0.17

Native format: 64 × 64 PNG at a reduced 56-color palette, displayed with nearest-neighbor pixel-art scaling. The original artwork is bespoke and each portrait maps to a recurring sender class.

- `radio_command.png`: Super Earth fleet officer; Mission Control and campaign orders.
- `radio_helldiver.png`: anonymous deployed Helldiver; field logs and secure responses.
- `radio_survivor.png`: Shelter Twelve survivor representative; confirmed civilian calls.
- `radio_unknown.png`: anonymous hooded transmission source; intercepted and unidentified channels. The artwork deliberately avoids confirming identity.
- `radio_automaton.png`: Automaton command uplink; hostile command traffic.
- `radio_warden.png`: Warden boss communications.
- `radio_sentinel.png`: Reactor Sentinel boss communications.
- `radio_technician.png`: operator portrait representing technical and recovered archive feeds.

These character designs represent visual interpretations for the existing anonymous dialogue roles; they do not assign previously unspecified canonical names, genders or identities. Future narrative updates can introduce named character portraits without changing the dialogue component API.
