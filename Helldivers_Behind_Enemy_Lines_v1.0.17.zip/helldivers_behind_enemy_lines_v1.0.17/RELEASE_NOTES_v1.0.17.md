# v1.0.17 — Radio Portrait Upgrade

- Eight new native 64×64, reduced-palette 16-bit-style portraits for Mission Control, the playable Helldiver, Shelter Twelve's survivor representative, Automaton command, the Warden, the Reactor Sentinel, shipboard technical/archival feeds, and anonymous intercepted broadcasts.
- Portrait selection follows dialogue speaker identity rather than showing one generic faction icon; unconfirmed intercepted transmissions remain visually unidentified until the story reveals their source.
- Rebuilt the left radio card with the character's face, source-specific accent and channel identification.
- Gameplay, campaign route, original soundtrack, mobile controls and save data unchanged.
- Artwork generated specifically for this project's game; source sprite sheet not included in compact release.
